-- =====================================================================
-- FormPilot AI - Cloud Database Schema with Row-Level Security (RLS)
-- Enables secure cross-device synchronization for authenticated accounts
-- =====================================================================

-- 1. User Profiles Table
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL DEFAULT 'Default Profile',
    data JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Job Applications Tracker Table
CREATE TABLE IF NOT EXISTS public.job_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    company TEXT NOT NULL,
    job_title TEXT NOT NULL,
    application_link TEXT,
    status TEXT NOT NULL DEFAULT 'Applied',
    date_applied DATE NOT NULL DEFAULT CURRENT_DATE,
    notes TEXT,
    data JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. Learned Form Mappings Table
CREATE TABLE IF NOT EXISTS public.learned_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    domain TEXT NOT NULL,
    form_signature TEXT,
    field_label TEXT NOT NULL,
    normalized_pattern TEXT,
    field_path TEXT,
    target_property TEXT NOT NULL,
    confidence NUMERIC(3, 2) NOT NULL DEFAULT 1.0,
    times_applied INTEGER NOT NULL DEFAULT 1,
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. User AI Settings Table
CREATE TABLE IF NOT EXISTS public.user_ai_settings (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL DEFAULT 'rule-based',
    api_key_encrypted TEXT,
    enabled BOOLEAN NOT NULL DEFAULT true,
    custom_system_prompt TEXT,
    temperature NUMERIC(2, 1) DEFAULT 0.7,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- =====================================================================
-- Performance Indexes
-- =====================================================================
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON public.user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_user_id ON public.job_applications(user_id);
CREATE INDEX IF NOT EXISTS idx_learned_mappings_user_id ON public.learned_mappings(user_id);
CREATE INDEX IF NOT EXISTS idx_learned_mappings_domain ON public.learned_mappings(domain);

-- =====================================================================
-- Enable Row Level Security (RLS) on all tables
-- Ensures strict account isolation: User A cannot read or write User B's data
-- =====================================================================
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learned_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_ai_settings ENABLE ROW LEVEL SECURITY;

-- 1. Policies for user_profiles
CREATE POLICY "Users can select own profiles"
    ON public.user_profiles FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profiles"
    ON public.user_profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profiles"
    ON public.user_profiles FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own profiles"
    ON public.user_profiles FOR DELETE
    USING (auth.uid() = user_id);

-- 2. Policies for job_applications
CREATE POLICY "Users can select own applications"
    ON public.job_applications FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own applications"
    ON public.job_applications FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own applications"
    ON public.job_applications FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own applications"
    ON public.job_applications FOR DELETE
    USING (auth.uid() = user_id);

-- 3. Policies for learned_mappings
CREATE POLICY "Users can select own learned mappings"
    ON public.learned_mappings FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own learned mappings"
    ON public.learned_mappings FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own learned mappings"
    ON public.learned_mappings FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own learned mappings"
    ON public.learned_mappings FOR DELETE
    USING (auth.uid() = user_id);

-- 4. Policies for user_ai_settings
CREATE POLICY "Users can select own AI settings"
    ON public.user_ai_settings FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own AI settings"
    ON public.user_ai_settings FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own AI settings"
    ON public.user_ai_settings FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own AI settings"
    ON public.user_ai_settings FOR DELETE
    USING (auth.uid() = user_id);
