/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./popup.html",
    "./options.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#F8FAFC',
        card: '#FFFFFF',
        primary: {
          DEFAULT: '#3B82F6',
          hover: '#2563EB',
          light: '#DBEAFE',
          dark: '#1D4ED8'
        },
        slate: {
          850: '#151f32',
          900: '#0F172A'
        },
        text: {
          primary: '#1E293B',
          secondary: '#64748B',
          muted: '#94A3B8'
        },
        border: '#E2E8F0',
        success: '#16A34A',
        warning: '#D97706',
        error: '#DC2626'
      }
    },
  },
  plugins: [],
}
