# FormPilot AI — Smart Form Autofill & Application Assistant

FormPilot AI is a production-ready Chrome Extension (Manifest V3) that helps candidates accurately, quickly, and securely complete online job applications, college entrance forms, government recruitment portals (SSC, GATE), and Google Forms.

Built with **React 19**, **TypeScript**, **Tailwind CSS**, and **Vite**, FormPilot AI blends intelligent DOM form detection, context-aware profile mapping, client-side PDF/DOCX resume extraction, an on-demand AI field explainer, and a full job application tracking dashboard.

---

## 🚀 Key Highlights & Capabilities

- **Manifest V3 Architecture:** Built following Google Chrome's Manifest V3 security model with a background service worker, secure in-page content scripts, and local Chrome Storage API persistence.
- **Strict Educational Disambiguation:**
  - Class 10 Percentage & Passing Year are strictly isolated from Class 12 and Degree marks.
  - Class 12 vs. Diploma discriminator correctly identifies and selects standard 12th vs. polytechnic qualifications.
  - Exactly **one B.Tech section** maintaining PRN (Permanent Registration Number), Degree, Branch, CGPA, and Backlogs.
  - Extensible **Higher Education** support (M.Tech, MBA, MCA, M.Sc., PhD).
- **Dedicated Google Forms Engine:**
  - Scans Google Forms question containers (`[role="listitem"]`, `.geS5n`, `.Qr7O8`).
  - Interacts with Google Forms radio buttons (`[role="radio"]`), checkboxes, and text inputs using authentic pointer and mouse event dispatch cycles.
  - Automatically verifies resulting `aria-checked` and DOM value states.
  - **Never automatically submits forms** — final review and submission remain strictly under user control.
- **Recruitment & Job Portal Adapters:**
  - Specialized adapters for government portals (SSC, GATE, UPSC) and enterprise applicant tracking systems (Greenhouse, Lever, Workday).
  - Explicit CAPTCHA protection: never bypasses CAPTCHAs, authentication, or website security controls.
- **Browser-Compatible Resume Import & Extraction:**
  - Upload **PDF** or **DOCX** files, or paste raw resume text.
  - Extracts contact details, education hierarchy, skills, projects, and work experience locally in your browser.
  - Detects scanned PDFs without extractable text and warns the user when OCR is required.
  - **Review Before Saving Interface:** Displays extracted entities with uncertainty highlights and confirmation modals to avoid accidental overwrites.
- **Application Tracker:**
  - Complete dashboard to manage job applications with statuses: *Interested*, *To Apply*, *In Progress*, *Applied*, *Assessment*, *Interview*, *Selected*, and *Rejected*.
  - Full search, status filtering, notes, and deadline management.
- **Form Learning:**
  - Remembers user corrections to field mappings scoped by field label and website domain.
  - Users can review, manage, or delete learned mapping rules at any time.
- **On-Demand AI Field Helper:**
  - Hidden by default. Opens **only** when the user explicitly clicks the help icon (`?`).
  - Provides concise, 1–2 sentence explanations for complex form fields (e.g. PRN, 10th Percentage, B.Tech CGPA).
  - **Never modifies form values, never suggests saved profile values, and never auto-fills.**
- **Truthful AI Answer Generator:**
  - Generates tailored answers for common behavioral questions (*"Why should we hire you?"*, *"Describe your project"*, *"Strengths"*, *"Internship experience"*).
  - Built-in rule-based offline template engine guarantees zero fabrication of credentials.
  - Optional Gemini or OpenAI integration using user-supplied API keys stored safely in local extension storage.

---

## 📁 Project Structure

```
Extension 2/
├── dist/                          # Production unpacked extension (Ready to load in Chrome)
│   ├── manifest.json              # Chrome Manifest V3 configuration
│   ├── background.js              # Background service worker (ES module)
│   ├── content.js                 # In-page content script (IIFE bundle)
│   ├── content.css                # Scoped in-page floating UI & field helper styles
│   ├── popup.html                 # Extension action popup
│   ├── options.html               # Full-page Dashboard & Control Center
│   ├── icons/                     # 16px, 48px, 128px PNG extension icons
│   └── assets/                    # Bundled React UI components & PDF parser
├── src/
│   ├── background/
│   │   └── background.ts          # Extension service worker (context menus, lifecycle)
│   ├── content/
│   │   ├── content.ts             # In-page detector, floating FormPilot pill, verification
│   │   └── content.css            # Scoped styles for in-page widgets
│   ├── dashboard/
│   │   ├── Dashboard.tsx          # Full-featured tabbed management dashboard
│   │   └── index.tsx              # Dashboard entrypoint
│   ├── popup/
│   │   ├── Popup.tsx              # Clean light-theme popup UI
│   │   └── index.tsx              # Popup entrypoint
│   ├── services/
│   │   ├── mappingEngine.ts       # Context-aware field mapping & strict disambiguation
│   │   ├── googleFormsAdapter.ts  # Specialized Google Forms DOM detector & verifier
│   │   ├── formDetector.ts        # Generic HTML form detector & React value setter
│   │   ├── recruitmentAdapters.ts # SSC, GATE, Workday, Greenhouse adapters
│   │   ├── resumeParser.ts        # Browser PDF/DOCX extractor & entity parser
│   │   ├── fieldHelper.ts         # On-demand 1-2 sentence field explainer
│   │   ├── aiAnswerGenerator.ts   # Truthful AI answer generator with offline fallback
│   │   └── formLearner.ts         # Mapping correction learner
│   ├── storage/
│   │   └── storage.ts             # Chrome Storage API abstraction with fallback
│   ├── types/                     # TypeScript interfaces (profile, form, tracker, ai)
│   └── tests/                     # Automated Vitest test suite
├── scripts/
│   ├── build.js                   # Unified Vite multi-target production build script
│   └── generateIcons.js           # PNG extension icon generator
├── manifest.json                  # Source manifest template
├── vite.config.ts                 # Vite & Vitest configuration
└── package.json                   # Project scripts and dependencies
```

---

## 🛠️ Installation Instructions (Load Unpacked Extension in Chrome)

To load FormPilot AI on your computer or any Windows / Mac / Linux machine:

1. Open **Google Chrome**.
2. Navigate to `chrome://extensions` in the address bar.
3. In the top-right corner, turn on **Developer mode** toggle.
4. Click the **Load unpacked** button in the top-left toolbar.
5. In the file picker dialog, select the **`dist`** folder located at:
   ```
   c:\Users\pande\OneDrive\Desktop\All projects\Extension 2\dist
   ```
6. The **FormPilot AI** extension will now appear in your extensions list and can be pinned to your toolbar!

---

## 💻 Development & Build Commands

All build scripts run using standard Node.js:

```bash
# Install dependencies
npm install

# Run automated test suite (Vitest)
npm test

# Build production extension to /dist
npm run build

# Generate high-resolution icons (16, 48, 128)
npm run generate-icons
```

---

## 🧪 Automated Test Verification

The codebase includes comprehensive automated tests covering all 18 core scenarios specified in the requirements:

| Test Suite | Scenarios Tested | Status |
| :--- | :--- | :--- |
| `src/tests/mappingEngine.test.ts` | **Scenarios 1–7**: 10th vs 12th percentage separation; passing year isolation; Full Name matching; PRN preservation; 12th/Diploma radio discrimination; unselected ambiguous qualification handling | ✅ **PASS** |
| `src/tests/googleForms.test.ts` | **Scenario 8**: Google Forms container discovery, real DOM pointer/mouse event firing, `aria-checked` verification, and multi-field regression | ✅ **PASS** |
| `src/tests/resumeParser.test.ts` | **Scenarios 9–11**: Multi-line entity segmentation, contact/education parsing, uncertain fields flagging, review before save, non-destructive merge | ✅ **PASS** |
| `src/tests/fieldHelperAndAi.test.ts` | **Scenarios 12–13**: Field helper dormancy until clicked; zero form/profile mutation; truthful AI answer generation | ✅ **PASS** |
| `src/tests/trackerAndLearning.test.ts` | **Scenarios 14–15**: Application tracker CRUD & status filtering; Form learning correction storage and priority reuse | ✅ **PASS** |
| `src/tests/buildAndManifest.test.ts` | **Scenarios 16–17**: Manifest V3 validation, permissions check, asset existence, and bundled script integrity | ✅ **PASS** |

### Test Run Summary
```
 RUN  v5.0.3 C:/Users/pande/OneDrive/Desktop/All projects/Extension 2

 ✓ src/tests/buildAndManifest.test.ts (2 tests)
 ✓ src/tests/fieldHelperAndAi.test.ts (3 tests)
 ✓ src/tests/trackerAndLearning.test.ts (2 tests)
 ✓ src/tests/mappingEngine.test.ts (7 tests)
 ✓ src/tests/resumeParser.test.ts (3 tests)
 ✓ src/tests/googleForms.test.ts (2 tests)

 Test Files  6 passed (6)
      Tests  19 passed (19)
```

---

## 🔒 Privacy & Security Commitments

1. **Local-First Storage:** All personal details, educational records, job applications, and learned mappings are stored strictly inside your browser's local sandbox via `chrome.storage.local`.
2. **Zero Unsolicited Telemetry:** No user data or resume content is transmitted to external servers without explicit user confirmation.
3. **No Credential Exposure:** Extension packages contain zero embedded API keys. Optional AI features use user-configured keys stored securely in the local extension storage.
4. **Non-Intrusive On-Demand Helper:** The field explainer opens only upon an explicit click on the `?` icon, never suggests profile values, never alters form fields, and dismisses when clicking away.
5. **Human in the Loop:** FormPilot AI fills inputs and performs post-fill verification, but **never automatically submits forms**. Final submission is always performed manually by the user.
