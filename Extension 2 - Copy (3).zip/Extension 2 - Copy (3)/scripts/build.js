import { build } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';

async function runBuild() {
  console.log('🚀 Starting FormPilot AI production build...');

  const rootDir = process.cwd();
  const distDir = path.resolve(rootDir, 'dist');

  // Step 1: Build Popup and Options HTML pages
  console.log('📦 1/3 Building Popup & Dashboard UI pages...');
  await build({
    configFile: false,
    plugins: [react()],
    base: '',
    build: {
      outDir: distDir,
      emptyOutDir: true,
      rollupOptions: {
        input: {
          popup: path.resolve(rootDir, 'popup.html'),
          options: path.resolve(rootDir, 'options.html'),
        },
      },
    },
  });

  // Step 2: Build Background Service Worker
  console.log('⚙️ 2/3 Building Background Service Worker...');
  await build({
    configFile: false,
    build: {
      outDir: distDir,
      emptyOutDir: false,
      lib: {
        entry: path.resolve(rootDir, 'src/background/background.ts'),
        name: 'background',
        formats: ['es'],
        fileName: () => 'background.js',
      },
    },
  });

  // Step 3: Build Content Script
  console.log('🌐 3/3 Building Content Script...');
  await build({
    configFile: false,
    build: {
      outDir: distDir,
      emptyOutDir: false,
      lib: {
        entry: path.resolve(rootDir, 'src/content/content.ts'),
        name: 'FormPilotContent',
        formats: ['iife'],
        fileName: () => 'content.js',
      },
    },
  });

  // Step 4: Ensure Manifest, Content CSS, and Icons are in dist
  console.log('📋 Finalizing assets & manifest in dist/ ...');
  const manifestSrc = path.resolve(rootDir, 'public/manifest.json');
  const manifestDest = path.resolve(distDir, 'manifest.json');
  fs.copyFileSync(manifestSrc, manifestDest);

  const contentCssSrc = path.resolve(rootDir, 'src/content/content.css');
  const contentCssDest = path.resolve(distDir, 'content.css');
  fs.copyFileSync(contentCssSrc, contentCssDest);

  const iconsSrcDir = path.resolve(rootDir, 'public/icons');
  const iconsDestDir = path.resolve(distDir, 'icons');
  if (!fs.existsSync(iconsDestDir)) {
    fs.mkdirSync(iconsDestDir, { recursive: true });
  }
  const iconFiles = fs.readdirSync(iconsSrcDir);
  for (const file of iconFiles) {
    fs.copyFileSync(path.join(iconsSrcDir, file), path.join(iconsDestDir, file));
  }

  console.log('✅ FormPilot AI production build successfully created in /dist !');
}

runBuild().catch((err) => {
  console.error('❌ Build failed:', err);
  process.exit(1);
});
