import { AuthService } from '../auth/authService';

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('FormPilot AI installed/updated:', details.reason);

  // Create context menus for convenience
  chrome.contextMenus.create({
    id: 'fp-open-dashboard',
    title: 'Open FormPilot Dashboard',
    contexts: ['action'],
  });

  chrome.contextMenus.create({
    id: 'fp-scan-page',
    title: 'Autofill Form with FormPilot',
    contexts: ['page', 'editable'],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'fp-open-dashboard') {
    chrome.runtime.openOptionsPage();
  } else if (info.menuItemId === 'fp-scan-page' && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'DETECT_FORMS' });
  }
});

// Extension messaging router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'OPEN_DASHBOARD') {
    chrome.runtime.openOptionsPage();
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'GET_AUTH_STATUS') {
    AuthService.getCurrentUser().then((user) => {
      sendResponse({ isAuthenticated: !!user, user });
    });
    return true;
  }

  if (message.type === 'PING') {
    sendResponse({ type: 'PONG', version: '1.0.0' });
    return true;
  }
});
