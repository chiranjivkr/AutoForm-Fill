export interface LearnedMapping {
  id: string;
  fieldLabel: string;
  normalizedPattern: string; // Lowercase clean pattern
  domainScope?: string; // Optional domain scope like 'forms.google.com' or 'ssc.nic.in' or undefined for global
  domain?: string;
  formSignature?: string;
  fieldPath?: string;
  confidence?: number;
  userVerified?: boolean;
  targetProperty: string; // e.g. "btech.prn", "class10.percentage"
  userConfirmed: boolean;
  timesApplied: number;
  lastUsedAt: string;
  createdAt: string;
  updatedAt?: string;
}

export interface LearningState {
  rules: LearnedMapping[];
  learningEnabled: boolean;
}
