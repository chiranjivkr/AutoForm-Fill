import { DetectedField, FormDetectionSummary, FillResult } from './form';
import { FieldHelpResult } from './ai';

export type ExtensionMessageType =
  | 'DETECT_FORMS'
  | 'DETECT_FORMS_RESULT'
  | 'FILL_FIELDS'
  | 'FILL_FIELDS_RESULT'
  | 'FILL_SINGLE_FIELD'
  | 'GET_FIELD_HELP'
  | 'GET_FIELD_HELP_RESULT'
  | 'OPEN_DASHBOARD'
  | 'PING'
  | 'PONG';

export interface ExtensionMessage<T = unknown> {
  type: ExtensionMessageType;
  payload?: T;
}

export interface DetectFormsResponse {
  summary: FormDetectionSummary;
}

export interface FillFieldsRequest {
  fields: DetectedField[];
  profileId?: string;
}

export interface FillSingleFieldRequest {
  fieldId: string;
  value: string;
}

export interface FillFieldsResponse {
  results: FillResult[];
  summary: FormDetectionSummary;
}

export interface FieldHelpRequest {
  label: string;
  fieldType?: string;
  context?: string;
}
