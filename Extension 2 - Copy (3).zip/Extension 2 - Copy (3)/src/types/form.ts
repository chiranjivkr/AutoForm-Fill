export type FormFieldType =
  | 'text'
  | 'textarea'
  | 'email'
  | 'tel'
  | 'number'
  | 'date'
  | 'select'
  | 'radio'
  | 'checkbox'
  | 'custom';

export type VerificationStatus =
  | 'pending'
  | 'verified'
  | 'mismatch'
  | 'failed'
  | 'skipped';

export interface FormOption {
  value: string;
  label: string;
  elementSelector?: string;
  ariaChecked?: boolean;
}

export interface MappingCandidate {
  label: string;
  value: string;
  property: string;
}

export interface DetectedField {
  id: string;
  name: string;
  label: string;
  normalizedLabel: string;
  type: FormFieldType;
  selector: string;
  containerSelector?: string;
  options?: FormOption[];
  currentValue?: string;
  contextText?: string;
  mappedProperty?: string; // e.g. "personal.fullName", "class10.percentage", "class12.percentage", "btech.cgpa", "btech.prn"
  mappedValue?: string;
  confidence: number;
  mappingReason?: string;
  selectedForFill: boolean;
  verificationStatus: VerificationStatus;
  actualResultValue?: string;
  verificationMessage?: string;
  isGoogleForm?: boolean;
  adapterType?: 'generic' | 'google-forms' | 'ssc-gov' | 'job-portal';
  candidates?: MappingCandidate[];
}

export interface FormDetectionSummary {
  detectedCount: number;
  matchedCount: number;
  filledCount: number;
  verifiedCount: number;
  failedCount: number;
  fields: DetectedField[];
  url: string;
  formTitle: string;
  timestamp: string;
}

export interface FillResult {
  fieldId: string;
  success: boolean;
  expectedValue: string;
  actualValue: string;
  status: VerificationStatus;
  error?: string;
}
