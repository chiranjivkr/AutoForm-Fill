export type QualificationType = '12th' | 'Diploma';

export interface PersonalInfo {
  fullName: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  whatsappNumber: string;
  currentLocation: string;
  linkedin: string;
  github: string;
  portfolio: string;
  summary?: string; // Career objective or professional summary
}

export interface Class10Info {
  board: string;
  school: string;
  passingYear: string;
  percentage: string; // or CGPA
}

export interface Class12DiplomaInfo {
  qualificationType: QualificationType; // '12th' or 'Diploma'
  boardOrInstitution: string;
  stream: string;
  passingYear: string;
  percentage: string;
}

export interface BTechInfo {
  degree: string;
  branch: string;
  college: string;
  passingYear: string; // passing year or expected
  cgpa: string;
  activeBacklogs: string;
  deadBacklogs: string;
  prn: string; // Permanent Registration Number / Roll Number
}

export interface HigherEducationItem {
  id: string;
  qualification: string; // M.Tech, MBA, MCA, M.Sc., PhD, etc.
  institution: string;
  specialization: string;
  passingYear: string;
  percentageOrCgpa: string;
}

export interface WorkExperienceItem {
  id: string;
  company: string;
  role: string;
  startDate: string;
  endDate: string;
  description: string;
  isCurrent?: boolean;
  isInternship?: boolean;
}

export interface ProjectItem {
  id: string;
  title: string;
  technologies: string;
  link: string;
  description: string;
  date?: string;
}

export interface CustomAnswerItem {
  id: string;
  questionKeyword: string; // e.g. "why-hire", "strengths", "relocate"
  questionLabel: string;
  answer: string;
}

export interface CustomProfileField {
  id: string;
  title: string; // e.g. "University Registration Number", "NCC Certificate", "Diploma Percentage"
  value: string;
  category?: 'Education' | 'Identification' | 'Certificates' | 'Professional' | 'Other';
  aliases?: string[]; // Alternative search tags/labels
  createdAt: string;
  updatedAt: string;
}

export interface JobProfile {
  id: string;
  name: string; // e.g., "Software Engineer", "Government SSC", "Data Analyst"
  targetRole: string;
  skills: string[];
  summary: string;
  customAnswers: Record<string, string>; // questionId -> answer
}

export interface UserProfile {
  id: string;
  name: string; // Profile name, e.g. "Default Profile"
  updatedAt: string;
  personal: PersonalInfo;
  class10: Class10Info;
  class12: Class12DiplomaInfo;
  btech: BTechInfo; // Exactly one B.Tech section!
  higherEducation: HigherEducationItem[]; // Multiple qualifications supported
  skills: string[];
  experiences: WorkExperienceItem[];
  projects: ProjectItem[];
  certifications?: string[];
  achievements?: string[];
  customAnswers: CustomAnswerItem[];
  customFields: CustomProfileField[]; // Adaptive custom fields
}

export const defaultProfile: UserProfile = {
  id: 'default',
  name: 'Primary Profile',
  updatedAt: new Date().toISOString(),
  customFields: [],
  certifications: [],
  achievements: [],
  personal: {
    fullName: '',
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    whatsappNumber: '',
    currentLocation: '',
    linkedin: '',
    github: '',
    portfolio: '',
    summary: '',
  },
  class10: {
    board: '',
    school: '',
    passingYear: '',
    percentage: '',
  },
  class12: {
    qualificationType: '12th',
    boardOrInstitution: '',
    stream: '',
    passingYear: '',
    percentage: '',
  },
  btech: {
    degree: 'B.Tech',
    branch: '',
    college: '',
    passingYear: '',
    cgpa: '',
    activeBacklogs: '0',
    deadBacklogs: '0',
    prn: '',
  },
  higherEducation: [],
  skills: [],
  experiences: [],
  projects: [],
  customAnswers: [
    {
      id: 'why-hire',
      questionKeyword: 'why should we hire you',
      questionLabel: 'Why should we hire you?',
      answer: '',
    },
    {
      id: 'strengths',
      questionKeyword: 'what are your strengths',
      questionLabel: 'What are your strengths?',
      answer: '',
    },
    {
      id: 'describe-project',
      questionKeyword: 'describe your project',
      questionLabel: 'Describe your key project',
      answer: '',
    },
    {
      id: 'internship-experience',
      questionKeyword: 'explain your internship experience',
      questionLabel: 'Explain your internship experience',
      answer: '',
    },
  ],
};
