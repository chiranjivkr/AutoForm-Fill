export type ApplicationStatus =
  | 'Interested'
  | 'To Apply'
  | 'In Progress'
  | 'Applied'
  | 'Assessment'
  | 'Interview'
  | 'Selected'
  | 'Rejected';

export interface ApplicationDocument {
  id: string;
  name: string;
  type: 'resume' | 'cover_letter' | 'certificate' | 'other';
  uploadedAt: string;
  dataUrl?: string;
  size?: number;
}

export interface JobApplication {
  id: string;
  company: string;
  jobTitle: string;
  applicationLink: string;
  deadline?: string;
  dateApplied: string;
  status: ApplicationStatus;
  salary?: string;
  location?: string;
  jobType?: 'Full-time' | 'Internship' | 'Contract' | 'Part-time' | 'Government';
  notes: string;
  documents: ApplicationDocument[];
  portalType?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ApplicationFilter {
  searchQuery: string;
  status: ApplicationStatus | 'All';
  sortBy: 'dateApplied' | 'deadline' | 'company' | 'updatedAt';
  sortOrder: 'asc' | 'desc';
}
