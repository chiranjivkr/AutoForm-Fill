export type AIProvider = 'gemini' | 'openai' | 'custom' | 'rule-based';

export interface AISettings {
  provider: AIProvider;
  apiKey: string;
  customEndpoint?: string;
  modelName?: string;
  enabled: boolean;
}

export interface AIAnswerRequest {
  question: string;
  context?: string;
  jobTitle?: string;
  company?: string;
  tone?: 'professional' | 'concise' | 'detailed';
  maxLength?: number;
}

export interface AIAnswerResponse {
  answer: string;
  isRuleBasedFallback: boolean;
  confidence: number;
}

export interface FieldHelpResult {
  fieldName: string;
  explanation: string;
  source: 'rule-based' | 'ai';
  recommendedFormat?: string;
}
