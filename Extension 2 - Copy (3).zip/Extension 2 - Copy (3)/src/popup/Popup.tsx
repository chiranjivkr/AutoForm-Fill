import React, { useEffect, useState } from 'react';
import {
  Sparkles,
  FileText,
  Briefcase,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  Settings,
  ChevronRight,
  ShieldCheck,
  User,
  Layers,
} from 'lucide-react';
import { StorageService } from '../storage/storage';
import { UserProfile } from '../types/profile';
import { FormDetectionSummary, DetectedField } from '../types/form';
import { JobApplication } from '../types/tracker';
import { useAuth } from '../auth/useAuth';
import { AuthView } from '../components/auth/AuthView';
import { UserBadge } from '../components/auth/UserBadge';

type DetectionStatus = 'loading' | 'detected' | 'no_fields' | 'restricted' | 'unavailable';

async function getActiveTab(): Promise<chrome.tabs.Tab | null> {
  if (typeof chrome === 'undefined' || !chrome.tabs?.query) return null;
  try {
    const focusedTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (focusedTabs && focusedTabs[0]) return focusedTabs[0];

    const currentTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (currentTabs && currentTabs[0]) return currentTabs[0];

    const allTabs = await chrome.tabs.query({ active: true });
    return allTabs && allTabs[0] ? allTabs[0] : null;
  } catch (err) {
    console.warn('Error querying active tab:', err);
    return null;
  }
}

function isRestrictedUrl(url?: string): boolean {
  if (!url) return false;
  return (
    url.startsWith('chrome://') ||
    url.startsWith('chrome-extension://') ||
    url.startsWith('edge://') ||
    url.startsWith('about:') ||
    url.startsWith('view-source:') ||
    url.startsWith('devtools://') ||
    url.includes('chrome.google.com/webstore') ||
    url.includes('chromewebstore.google.com')
  );
}

export const Popup: React.FC = () => {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [summary, setSummary] = useState<FormDetectionSummary | null>(null);
  const [detectionStatus, setDetectionStatus] = useState<DetectionStatus>('loading');
  const [activeTabInfo, setActiveTabInfo] = useState<{ id?: number; url?: string; title?: string } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [filling, setFilling] = useState<boolean>(false);
  const [fillMessage, setFillMessage] = useState<string | null>(null);
  const [showReview, setShowReview] = useState<boolean>(false);
  const [customFieldTarget, setCustomFieldTarget] = useState<DetectedField | null>(null);
  const [customFieldTitle, setCustomFieldTitle] = useState('');
  const [customFieldValue, setCustomFieldValue] = useState('');
  const [customFieldCategory, setCustomFieldCategory] = useState<
    'Education' | 'Identification' | 'Certificates' | 'Professional' | 'Other'
  >('Other');

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
  }, [isAuthenticated, user?.id]);

  const loadData = async () => {
    setLoading(true);
    setDetectionStatus('loading');
    setFillMessage(null);
    try {
      const storage = await StorageService.getAll();
      setProfiles(storage.profiles);
      const active = storage.profiles.find((p) => p.id === storage.activeProfileId) || storage.profiles[0];
      setProfile(active);
      setApplications(storage.applications || []);

      const activeTab = await getActiveTab();
      if (!activeTab || !activeTab.id) {
        setDetectionStatus('no_fields');
        setLoading(false);
        return;
      }

      setActiveTabInfo({ id: activeTab.id, url: activeTab.url, title: activeTab.title });

      if (isRestrictedUrl(activeTab.url)) {
        setSummary(null);
        setDetectionStatus('restricted');
        setLoading(false);
        return;
      }

      const sendDetect = (tabId: number): Promise<FormDetectionSummary | null> => {
        return new Promise((resolve) => {
          chrome.tabs.sendMessage(tabId, { type: 'DETECT_FORMS' }, (response) => {
            if (chrome.runtime.lastError || !response?.summary) {
              resolve(null);
            } else {
              resolve(response.summary);
            }
          });
        });
      };

      let sum = await sendDetect(activeTab.id);

      // If communication failed, try programmatic injection fallback
      if (!sum && chrome.scripting?.executeScript) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: activeTab.id },
            files: ['content.js'],
          });
          await new Promise((r) => setTimeout(r, 200));
          sum = await sendDetect(activeTab.id);
        } catch (injectErr) {
          console.warn('Programmatic script injection fallback failed:', injectErr);
        }
      }

      if (sum) {
        setSummary(sum);
        setDetectionStatus(sum.detectedCount > 0 ? 'detected' : 'no_fields');
      } else {
        setSummary(null);
        setDetectionStatus('unavailable');
      }
    } catch (e) {
      console.error('loadData error:', e);
      setDetectionStatus('unavailable');
    } finally {
      setLoading(false);
    }
  };

  const handleReloadTab = () => {
    if (activeTabInfo?.id && typeof chrome !== 'undefined' && chrome.tabs?.reload) {
      chrome.tabs.reload(activeTabInfo.id, {}, () => {
        setTimeout(loadData, 1000);
      });
    }
  };

  const handleProfileChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const id = e.target.value;
    const selected = profiles.find((p) => p.id === id);
    if (selected) {
      setProfile(selected);
      await StorageService.saveAll({ activeProfileId: id });
      // Re-scan forms with new profile
      loadData();
    }
  };

  const handleAutofill = async () => {
    if (!summary || !summary.fields.length) return;
    setFilling(true);
    setFillMessage(null);

    const fieldsToFill = summary.fields.filter((f) => f.selectedForFill && f.mappedValue);

    if (fieldsToFill.length === 0) {
      setFillMessage('No fields matched your saved profile data.');
      setFilling(false);
      return;
    }

    const tab = await getActiveTab();
    if (!tab?.id) {
      setFillMessage('Could not find active tab.');
      setFilling(false);
      return;
    }

    chrome.tabs.sendMessage(
      tab.id,
      { type: 'FILL_FIELDS', payload: { fields: fieldsToFill } },
      (response) => {
        setFilling(false);
        if (chrome.runtime.lastError) {
          setFillMessage('Could not communicate with active tab. Please reload the page.');
          return;
        }
        if (response?.summary) {
          setSummary(response.summary);
          setFillMessage(`Filled & verified ${response.summary.verifiedCount} fields successfully!`);
        } else {
          setFillMessage('Fields filled! Please review the form before submitting.');
        }
      }
    );
  };

  const handleOpenCustomField = (f: DetectedField) => {
    setCustomFieldTarget(f);
    setCustomFieldTitle(f.label);
    setCustomFieldValue('');
    setCustomFieldCategory('Other');
  };

  const handleFillOnce = async (fieldId: string, value: string) => {
    if (!value.trim()) return;
    const tab = await getActiveTab();
    if (!tab?.id) return;

    chrome.tabs.sendMessage(
      tab.id,
      { type: 'FILL_SINGLE_FIELD', payload: { fieldId, value: value.trim() } },
      (response) => {
        if (response?.summary) {
          setSummary(response.summary);
        }
        setFillMessage(`Filled "${customFieldTitle || 'field'}" once (not saved to profile).`);
        setCustomFieldTarget(null);
      }
    );
  };

  const handleSelectCandidate = (fieldId: string, value: string) => {
    if (!summary) return;
    const updatedFields = summary.fields.map((f) => {
      if (f.id === fieldId) {
        return { ...f, mappedValue: value, selectedForFill: true };
      }
      return f;
    });
    setSummary({ ...summary, fields: updatedFields });
  };

  const handleSaveAndFill = async (
    field: DetectedField,
    title: string,
    value: string,
    category: 'Education' | 'Identification' | 'Certificates' | 'Professional' | 'Other'
  ) => {
    if (!title.trim() || !value.trim() || !profile) return;
    if (typeof window !== 'undefined' && window.confirm) {
      const ok = window.confirm(`Save "${title.trim()}: ${value.trim()}" as a custom field to your profile for future autofill?`);
      if (!ok) return;
    }
    try {
      const newField = await StorageService.addCustomField(profile.id, {
        title: title.trim(),
        value: value.trim(),
        category,
        aliases: [field.label.trim()],
      });

      if (summary?.url) {
        try {
          const domain = new URL(summary.url).hostname;
          await StorageService.saveLearnedMapping({
            id: 'lm_' + Date.now(),
            domain,
            formSignature: summary.formTitle || domain,
            fieldLabel: field.label,
            fieldPath: field.name || field.id,
            targetProperty: `custom.${newField.id}`,
            confidence: 1.0,
            userVerified: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        } catch (_) {}
      }

      const tab = await getActiveTab();
      if (tab?.id) {
        chrome.tabs.sendMessage(
          tab.id,
          { type: 'FILL_SINGLE_FIELD', payload: { fieldId: field.id, value: value.trim() } },
          (response) => {
            if (response?.summary) {
              setSummary(response.summary);
            }
            setFillMessage(`Saved "${title.trim()}" to profile and filled field!`);
            setCustomFieldTarget(null);
            loadData();
          }
        );
      }
    } catch (e: any) {
      console.error(e);
      setFillMessage('Failed to save custom field.');
    }
  };

  const openDashboard = (tab?: string) => {
    const targetUrl = tab ? `options.html?tab=${tab}` : 'options.html';
    try {
      if (tab && typeof chrome !== 'undefined' && chrome.tabs?.create) {
        chrome.tabs.create({ url: chrome.runtime.getURL(targetUrl) });
        return;
      }
      if (typeof chrome !== 'undefined' && chrome.runtime?.openOptionsPage) {
        chrome.runtime.openOptionsPage(() => {
          if (chrome.runtime.lastError) {
            console.warn('openOptionsPage callback error:', chrome.runtime.lastError);
            if (chrome.tabs?.create) {
              chrome.tabs.create({ url: chrome.runtime.getURL(targetUrl) });
            } else {
              window.open(chrome.runtime.getURL(targetUrl), '_blank');
            }
          }
        });
      } else if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
        chrome.tabs.create({ url: chrome.runtime.getURL(targetUrl) });
      } else {
        window.open(targetUrl, '_blank');
      }
    } catch (e) {
      console.error('Error opening dashboard:', e);
      if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
        chrome.tabs.create({ url: chrome.runtime.getURL(targetUrl) });
      } else {
        window.open(targetUrl, '_blank');
      }
    }
  };

  if (authLoading) {
    return (
      <div className="w-[380px] min-h-[480px] bg-slate-50 flex flex-col items-center justify-center p-6 text-slate-500 font-sans">
        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-2" />
        <span className="text-xs font-medium">Loading FormPilot AI...</span>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <AuthView
        isCompact={true}
        onSuccess={() => {
          loadData();
        }}
      />
    );
  }

  return (
    <div className="w-[380px] min-h-[480px] bg-background text-text-primary flex flex-col font-sans select-none">
      {/* Top Header */}
      <header className="bg-white border-b border-border px-3.5 py-2.5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-xs font-bold tracking-tight text-slate-900 leading-none">FormPilot AI</h1>
            <p className="text-[10px] text-text-secondary mt-0.5">Application Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <UserBadge user={user} isCompact={true} />
          <button
            onClick={() => openDashboard()}
            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
            title="Open Dashboard & Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Profile Selector Banner */}
      <div className="bg-white border-b border-border px-4 py-2.5 flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-text-secondary">Active Profile:</span>
        <select
          value={profile?.id || 'default'}
          onChange={handleProfileChange}
          className="text-xs font-semibold bg-slate-50 border border-border rounded-md px-2.5 py-1 text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
        >
          {profiles.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name || 'Default Profile'} ({p.personal.fullName || 'No Name'})
            </option>
          ))}
        </select>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-4 flex flex-col gap-3.5">
        {/* Detection Card */}
        <div className="bg-white rounded-xl border border-border p-3.5 shadow-sm">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full ${
                    detectionStatus === 'detected'
                      ? 'bg-emerald-400'
                      : detectionStatus === 'restricted'
                      ? 'bg-amber-400'
                      : detectionStatus === 'unavailable'
                      ? 'bg-rose-400'
                      : 'bg-slate-400'
                  } opacity-75`}
                ></span>
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    detectionStatus === 'detected'
                      ? 'bg-emerald-500'
                      : detectionStatus === 'restricted'
                      ? 'bg-amber-500'
                      : detectionStatus === 'unavailable'
                      ? 'bg-rose-500'
                      : 'bg-slate-400'
                  }`}
                ></span>
              </span>
              <h2 className="text-xs font-bold uppercase tracking-wider text-text-secondary">Current Page Status</h2>
            </div>
            <button
              onClick={loadData}
              disabled={loading}
              className="text-text-secondary hover:text-primary transition-colors p-1"
              title="Rescan current page"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {loading ? (
            <div className="py-4 text-center text-xs text-text-secondary flex flex-col items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-primary" />
              Scanning active tab for forms...
            </div>
          ) : detectionStatus === 'restricted' ? (
            <div className="py-3 px-2 text-center text-xs">
              <div className="w-8 h-8 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-2">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="font-bold text-slate-800 mb-1">Page Access Restricted</div>
              <p className="text-[11px] text-slate-500 leading-relaxed mb-2">
                Chrome prevents extensions from running scripts on internal browser pages, settings, and the Web Store.
              </p>
              <div className="text-[10px] text-slate-400 bg-slate-50 py-1 px-2 rounded font-mono truncate max-w-full">
                {activeTabInfo?.url || 'Internal browser page'}
              </div>
            </div>
          ) : detectionStatus === 'unavailable' ? (
            <div className="py-3 px-2 text-center text-xs">
              <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-2">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div className="font-bold text-slate-800 mb-1">Content Script Not Connected</div>
              <p className="text-[11px] text-slate-500 leading-relaxed mb-3">
                FormPilot is not active on this tab yet. This usually happens if the page was opened before the extension was installed or reloaded.
              </p>
              <div className="flex gap-2 justify-center">
                <button
                  onClick={handleReloadTab}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Reload Tab
                </button>
                <button
                  onClick={loadData}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] rounded-lg transition-colors cursor-pointer"
                >
                  Retry Scan
                </button>
              </div>
            </div>
          ) : detectionStatus === 'detected' && summary && summary.detectedCount > 0 ? (
            <div>
              <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-100 mb-3 text-center">
                <div className="bg-slate-50 rounded-lg p-2">
                  <div className="text-base font-bold text-slate-900">{summary.detectedCount}</div>
                  <div className="text-[10px] text-text-secondary font-medium uppercase">Detected</div>
                </div>
                <div className="bg-blue-50/60 rounded-lg p-2">
                  <div className="text-base font-bold text-primary">{summary.matchedCount}</div>
                  <div className="text-[10px] text-blue-600 font-medium uppercase">Matched</div>
                </div>
                <div className="bg-emerald-50/60 rounded-lg p-2">
                  <div className="text-base font-bold text-emerald-600">{summary.verifiedCount}</div>
                  <div className="text-[10px] text-emerald-600 font-medium uppercase">Verified</div>
                </div>
              </div>

              {fillMessage && (
                <div className="mb-3 p-2 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>{fillMessage}</span>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  onClick={handleAutofill}
                  disabled={filling || summary.matchedCount === 0}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 shadow-sm shadow-blue-500/20 transition-all cursor-pointer"
                >
                  {filling ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-white" />
                  )}
                  <span className="text-white font-semibold">{filling ? 'Filling & Verifying...' : 'Autofill Form'}</span>
                </button>

                <button
                  onClick={() => setShowReview(!showReview)}
                  className="px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
                >
                  {showReview ? 'Hide' : 'Review'}
                </button>
              </div>

              {/* Review list */}
              {showReview && (
                <div className="mt-3 pt-3 border-t border-slate-100 max-h-56 overflow-y-auto flex flex-col gap-2">
                  {summary.fields.map((f) => (
                    <div
                      key={f.id}
                      className="p-2 bg-slate-50 rounded-lg border border-slate-200/60 flex flex-col gap-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="truncate max-w-[190px]">
                          <span className="font-semibold text-slate-800 text-[11px]">{f.label}</span>
                          {f.mappedValue && (
                            <div className="text-[10px] text-text-secondary truncate">→ {f.mappedValue}</div>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5">
                          {!f.mappedValue && customFieldTarget?.id !== f.id && (
                            <button
                              type="button"
                              onClick={() => handleOpenCustomField(f)}
                              className="text-[10px] font-semibold px-2 py-0.5 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 rounded transition-colors cursor-pointer"
                            >
                              + Custom
                            </button>
                          )}
                          {f.confidence > 0 && f.confidence < 0.7 && f.mappedValue && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                              Review
                            </span>
                          )}
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                              f.verificationStatus === 'verified'
                                ? 'bg-emerald-100 text-emerald-700'
                                : f.verificationStatus === 'failed'
                                ? 'bg-rose-100 text-rose-700'
                                : f.mappedValue
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-slate-200 text-slate-600'
                            }`}
                          >
                            {f.verificationStatus !== 'pending' ? f.verificationStatus : f.mappedValue ? 'matched' : 'unmapped'}
                          </span>
                        </div>
                      </div>

                      {/* Multiple Matching Candidates (Disambiguation) */}
                      {f.candidates && f.candidates.length > 1 && (
                        <div className="mt-1 pt-1 border-t border-slate-200/50 flex flex-col gap-1">
                          <span className="text-[10px] text-slate-600 font-semibold">Choose value to map:</span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {f.candidates.map((cand, cIdx) => (
                              <button
                                key={cIdx}
                                type="button"
                                onClick={() => handleSelectCandidate(f.id, cand.value)}
                                className={`text-[10px] px-2 py-0.5 rounded border transition-colors cursor-pointer ${
                                  f.mappedValue === cand.value
                                    ? 'bg-blue-600 text-white border-blue-600 font-semibold shadow-xs'
                                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                }`}
                              >
                                {cand.label}: {cand.value}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Inline custom field creator */}
                      {customFieldTarget?.id === f.id && (
                        <div className="mt-1 p-2 bg-white rounded-md border border-blue-200 shadow-xs flex flex-col gap-2 text-[11px]">
                          <div className="font-semibold text-slate-800 flex items-center justify-between">
                            <span>Add Custom Field for this Input:</span>
                            <button
                              type="button"
                              onClick={() => setCustomFieldTarget(null)}
                              className="text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                            >
                              &times;
                            </button>
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-500 font-medium block mb-0.5">Title:</label>
                            <input
                              type="text"
                              value={customFieldTitle}
                              onChange={(e) => setCustomFieldTitle(e.target.value)}
                              placeholder="e.g. Roll Number"
                              className="w-full text-xs px-2 py-1 bg-slate-50 border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-500 font-medium block mb-0.5">Value:</label>
                            <input
                              type="text"
                              value={customFieldValue}
                              onChange={(e) => setCustomFieldValue(e.target.value)}
                              placeholder="Enter value to fill..."
                              className="w-full text-xs px-2 py-1 bg-slate-50 border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </div>
                          <div className="flex items-center gap-1.5 pt-1">
                            <button
                              type="button"
                              onClick={() => handleFillOnce(f.id, customFieldValue)}
                              disabled={!customFieldValue.trim()}
                              className="flex-1 py-1 px-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-700 font-semibold text-[10px] rounded transition-colors cursor-pointer"
                            >
                              Fill Once
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleSaveAndFill(f, customFieldTitle, customFieldValue, customFieldCategory)
                              }
                              disabled={!customFieldTitle.trim() || !customFieldValue.trim()}
                              className="flex-1 py-1 px-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-[10px] rounded shadow-xs transition-colors cursor-pointer"
                            >
                              Save & Fill
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="py-4 text-center text-xs text-text-secondary">
              <AlertCircle className="w-5 h-5 text-slate-400 mx-auto mb-1.5" />
              <div className="font-semibold text-slate-700 mb-0.5">No Supported Fields Detected</div>
              <p className="text-[11px] text-slate-500 mb-2">No interactive form or application fields were found on this tab.</p>
              <button
                onClick={loadData}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 underline cursor-pointer"
              >
                Scan Again
              </button>
            </div>
          )}
        </div>

        {/* Quick Hub Cards */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => openDashboard('resume')}
            className="p-2.5 bg-white hover:bg-blue-50/40 border border-border hover:border-blue-200 rounded-xl text-left transition-all group cursor-pointer shadow-sm"
          >
            <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <FileText className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-primary transition-colors">
              Import Resume
            </div>
            <div className="text-[10px] text-text-secondary">PDF & DOCX Parser</div>
          </button>

          <button
            onClick={() => openDashboard('profile')}
            className="p-2.5 bg-white hover:bg-blue-50/40 border border-border hover:border-blue-200 rounded-xl text-left transition-all group cursor-pointer shadow-sm"
          >
            <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <User className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-primary transition-colors">
              My Profile
            </div>
            <div className="text-[10px] text-text-secondary">Manage resume data</div>
          </button>

          <button
            onClick={() => openDashboard('custom_fields')}
            className="p-2.5 bg-white hover:bg-blue-50/40 border border-border hover:border-blue-200 rounded-xl text-left transition-all group cursor-pointer shadow-sm"
          >
            <div className="w-6 h-6 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <Layers className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-primary transition-colors">
              Custom Fields
            </div>
            <div className="text-[10px] text-text-secondary">Extra form details</div>
          </button>

          <button
            onClick={() => openDashboard('tracker')}
            className="p-2.5 bg-white hover:bg-blue-50/40 border border-border hover:border-blue-200 rounded-xl text-left transition-all group cursor-pointer shadow-sm"
          >
            <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <Briefcase className="w-3.5 h-3.5" />
            </div>
            <div className="text-xs font-bold text-slate-900 group-hover:text-primary transition-colors flex items-center justify-between">
              <span>App Tracker</span>
              <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 rounded-full font-normal">
                {applications.length}
              </span>
            </div>
            <div className="text-[10px] text-text-secondary">Track applications</div>
          </button>
        </div>

        {/* Safety & Policy Badge */}
        <div className="bg-emerald-50/60 border border-emerald-200/60 rounded-xl p-2.5 flex items-center gap-2 text-[11px] text-emerald-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Privacy Guaranteed: Data never leaves your device without explicit action.</span>
        </div>
      </div>

      {/* Bottom Footer */}
      <footer className="bg-white border-t border-border px-4 py-2.5 flex items-center justify-between">
        <button
          onClick={() => openDashboard()}
          className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 transition-colors cursor-pointer"
        >
          <span>Open Full Management Dashboard</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </footer>
    </div>
  );
};
