import { UserProfile, defaultProfile, HigherEducationItem, WorkExperienceItem, ProjectItem } from '../types/profile';
import * as mammoth from 'mammoth';

export interface ExtractedResumeData {
  profile: Partial<UserProfile>;
  rawText: string;
  isScannedPdf?: boolean;
  needsOcr?: boolean;
  uncertainFields: string[];
  fieldConfidence: Record<string, number>;
  pageCount?: number;
  conflictingFields?: string[];
}

interface RawPdfItem {
  str: string;
  x: number;
  y: number;
  width: number;
  height: number;
  hasEOL: boolean;
}

export class ResumeParser {
  /**
   * Extracts raw text from a PDF file using browser-compatible pdfjs-dist.
   * Performs layout-aware multi-column and line reconstruction to preserve
   * original reading order, line breaks, bullet points, and section boundaries.
   */
  public static async extractTextFromPdf(file: File): Promise<{ text: string; isScanned: boolean; pages: number }> {
    const arrayBuffer = await file.arrayBuffer();

    try {
      // Dynamic import of pdfjs-dist for browser and worker compatibility
      const pdfjsLib = await import('pdfjs-dist');
      if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '4.0.379'}/pdf.worker.min.mjs`;
      }

      const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
      const pdf = await loadingTask.promise;
      const numPages = pdf.numPages;
      let fullText = '';
      let totalItemCount = 0;

      for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const items: RawPdfItem[] = [];

        for (const item of textContent.items) {
          if ('str' in item && typeof item.str === 'string') {
            const trimmedStr = item.str;
            if (trimmedStr.length > 0) {
              totalItemCount++;
              items.push({
                str: trimmedStr,
                x: item.transform[4],
                y: item.transform[5],
                width: item.width || 0,
                height: item.height || Math.abs(item.transform[0]) || 10,
                hasEOL: !!item.hasEOL,
              });
            }
          }
        }

        const pageFormattedText = this.reconstructPageLayout(items);
        if (pageFormattedText) {
          fullText += (fullText ? `\n--- Page ${i} ---\n` : '') + pageFormattedText;
        }
      }

      const cleanText = fullText.trim();
      // If document has fewer than 60 extractable characters across pages, it is an image scan
      const isScanned = cleanText.length < 60 || totalItemCount < 5;

      return {
        text: cleanText,
        isScanned,
        pages: numPages,
      };
    } catch (err) {
      console.warn('pdfjs-dist parsing fallback:', err);
      // Fallback: extract visible text strings from PDF stream
      const textDecoder = new TextDecoder('utf-8');
      const text = textDecoder.decode(arrayBuffer);
      const matched = text.match(/\(([^()]+)\)/g);
      if (matched && matched.length > 15) {
        const extracted = matched.map((m) => m.slice(1, -1)).join(' ');
        return { text: extracted, isScanned: extracted.length < 60, pages: 1 };
      }
      return {
        text: '',
        isScanned: true,
        pages: 1,
      };
    }
  }

  /**
   * Reconstructs text from raw PDF.js items respecting visual lines,
   * paragraph spacing, and multi-column layouts.
   */
  private static reconstructPageLayout(items: RawPdfItem[]): string {
    if (items.length === 0) return '';

    // Calculate horizontal bounds
    let minX = Infinity;
    let maxX = -Infinity;
    for (const item of items) {
      if (item.x < minX) minX = item.x;
      if (item.x + item.width > maxX) maxX = item.x + item.width;
    }
    const pageWidth = maxX - minX;

    // Detect if page has a 2-column layout with a distinct vertical divider
    let isTwoColumn = false;
    let splitX = minX + pageWidth / 2;

    if (pageWidth > 320 && items.length > 25) {
      // Look for a gutter between 28% and 72% of width
      const gutterStart = minX + pageWidth * 0.28;
      const gutterEnd = minX + pageWidth * 0.72;

      // Find x-coordinate with minimum item overlaps
      let bestSplit = 0;
      let minCrossers = Infinity;

      for (let testX = gutterStart; testX <= gutterEnd; testX += 15) {
        let crossCount = 0;
        let leftCount = 0;
        let rightCount = 0;

        for (const item of items) {
          const itemRight = item.x + item.width;
          if (item.x < testX && itemRight > testX) {
            crossCount++;
          } else if (itemRight <= testX) {
            leftCount++;
          } else if (item.x >= testX) {
            rightCount++;
          }
        }

        // Both columns should have substantial content and minimal crossers
        if (leftCount > 8 && rightCount > 8 && crossCount < minCrossers) {
          minCrossers = crossCount;
          bestSplit = testX;
        }
      }

      if (bestSplit > 0 && minCrossers <= Math.max(3, items.length * 0.08)) {
        isTwoColumn = true;
        splitX = bestSplit;
      }
    }

    if (isTwoColumn) {
      // Find header boundary (full width items near the top: PDF Y is higher at top)
      let maxY = -Infinity;
      for (const item of items) {
        if (item.y > maxY) maxY = item.y;
      }

      const headerItems: RawPdfItem[] = [];
      const leftColItems: RawPdfItem[] = [];
      const rightColItems: RawPdfItem[] = [];

      for (const item of items) {
        const itemRight = item.x + item.width;
        // Spans across columns or is in top 15% header band
        if (item.y > maxY - 70 && (item.x < splitX && itemRight > splitX)) {
          headerItems.push(item);
        } else if (itemRight <= splitX + 5) {
          leftColItems.push(item);
        } else {
          rightColItems.push(item);
        }
      }

      const headerText = this.renderColumnLines(headerItems);
      const leftText = this.renderColumnLines(leftColItems);
      const rightText = this.renderColumnLines(rightColItems);

      return [headerText, leftText, rightText].filter(Boolean).join('\n\n');
    }

    return this.renderColumnLines(items);
  }

  /**
   * Groups items by Y-coordinate, orders lines top-to-bottom,
   * orders words left-to-right, and produces well-structured text.
   */
  private static renderColumnLines(items: RawPdfItem[]): string {
    if (items.length === 0) return '';

    // Sort items descending by Y (in PDF, higher Y is higher on page)
    items.sort((a, b) => b.y - a.y || a.x - b.x);

    const lines: { y: number; height: number; items: RawPdfItem[] }[] = [];
    const lineTolerance = 4; // Vertical pixel tolerance for same line

    for (const item of items) {
      let placed = false;
      for (const line of lines) {
        if (Math.abs(line.y - item.y) <= lineTolerance) {
          line.items.push(item);
          placed = true;
          break;
        }
      }
      if (!placed) {
        lines.push({ y: item.y, height: item.height, items: [item] });
      }
    }

    // Sort each line horizontally by x
    for (const line of lines) {
      line.items.sort((a, b) => a.x - b.x);
    }

    const outputLines: string[] = [];
    let prevY: number | null = null;
    let prevHeight = 10;

    for (const line of lines) {
      // Check for paragraph gap between lines
      if (prevY !== null) {
        const vGap = prevY - line.y;
        if (vGap > prevHeight * 1.8) {
          outputLines.push(''); // Blank line separator
        }
      }
      prevY = line.y;
      prevHeight = line.height;

      let lineText = '';
      let prevRight = -Infinity;

      for (const item of line.items) {
        if (lineText && item.x > prevRight + 2.5 && !lineText.endsWith(' ') && !item.str.startsWith(' ')) {
          lineText += ' ';
        }
        lineText += item.str;
        prevRight = item.x + item.width;
      }

      if (lineText.trim()) {
        outputLines.push(lineText.trim());
      }
    }

    return outputLines.join('\n');
  }

  /**
   * Extracts raw text from a DOCX file using mammoth.
   * Converts HTML structures to preserve tables (delimiters), lists (bullets),
   * and paragraph breaks.
   */
  public static async extractTextFromDocx(file: File): Promise<string> {
    const arrayBuffer = await file.arrayBuffer();
    try {
      // First attempt: Convert to HTML to preserve tables and headings
      const result = await mammoth.convertToHtml({ arrayBuffer });
      let html = result.value || '';

      if (html.trim()) {
        // Replace table rows with pipe-delimited lines
        html = html.replace(/<tr[^>]*>(.*?)<\/tr>/gis, (_, rowContent) => {
          const cells: string[] = [];
          const cellMatches = rowContent.matchAll(/<td[^>]*>(.*?)<\/td>/gis);
          for (const match of cellMatches) {
            cells.push(match[1].replace(/<[^>]+>/g, '').trim());
          }
          return cells.length > 0 ? cells.join(' | ') + '\n' : '';
        });

        // Convert list items to bullet points
        html = html.replace(/<li[^>]*>(.*?)<\/li>/gis, (_, item) => {
          return `- ${item.replace(/<[^>]+>/g, '').trim()}\n`;
        });

        // Convert headings and paragraphs to spaced blocks
        html = html.replace(/<h[1-6][^>]*>(.*?)<\/h[1-6]>/gis, '\n$1\n');
        html = html.replace(/<p[^>]*>(.*?)<\/p>/gis, '$1\n');
        html = html.replace(/<br\s*\/?>/gi, '\n');

        // Decode HTML entities
        html = html
          .replace(/&nbsp;/gi, ' ')
          .replace(/&amp;/gi, '&')
          .replace(/&lt;/gi, '<')
          .replace(/&gt;/gi, '>')
          .replace(/&quot;/gi, '"')
          .replace(/&#39;/gi, "'")
          .replace(/&bull;/gi, '•');

        // Strip remaining HTML tags
        const clean = html.replace(/<[^>]+>/g, ' ').replace(/[ \t]+/g, ' ');
        const finalLines = clean.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
        return finalLines.join('\n');
      }

      // Fallback: extract raw text
      const rawRes = await mammoth.extractRawText({ arrayBuffer });
      return rawRes.value || '';
    } catch (err) {
      console.error('Mammoth DOCX parsing failed:', err);
      throw new Error('Unable to read DOCX document. File might be corrupted or password-protected.');
    }
  }

  /**
   * Parses raw resume text into structured UserProfile data with section context,
   * strict entity separation, confidence scoring, and uncertainty flagging.
   */
  public static parseResumeText(rawText: string): ExtractedResumeData {
    if (!rawText || rawText.trim().length < 50) {
      return {
        profile: {
          personal: { ...defaultProfile.personal },
          class10: { ...defaultProfile.class10 },
          class12: { ...defaultProfile.class12 },
          btech: { ...defaultProfile.btech, degree: '', branch: '' },
          higherEducation: [],
          skills: [],
          experiences: [],
          projects: [],
          certifications: [],
          achievements: [],
        },
        rawText: rawText || '',
        isScannedPdf: true,
        needsOcr: true,
        uncertainFields: [
          'personal.fullName',
          'personal.email',
          'personal.phoneNumber',
          'class10.percentage',
          'class12.percentage',
        ],
        fieldConfidence: {},
      };
    }

    // Normalize unicode characters, dashes, and bullet marks
    const normalizedRaw = rawText
      .replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201C\u201D]/g, '"')
      .replace(/[\u2013\u2014]/g, '-')
      .replace(/[\u2022\u25CF\u25AA\u25BA]/g, '•')
      .replace(/[ \t]+/g, ' ');

    const lines = normalizedRaw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);

    // 1. Segment document into major sections
    const sections = this.segmentSections(lines);

    // 2. Personal Information Extraction
    const personal = this.extractPersonalInfo(normalizedRaw, lines, sections);

    // 3. Education Extraction (Isolated qualification blocks)
    const eduText = sections['EDUCATION'] || normalizedRaw;
    const { class10, class12, btech, higherEducation } = this.extractEducation(eduText, normalizedRaw);

    // 4. Skills Extraction (Technical & Soft Skills)
    const skillsText = sections['SKILLS'] || normalizedRaw;
    const skills = this.extractSkills(skillsText, normalizedRaw);

    // 5. Experience & Internships Extraction
    const expText = sections['EXPERIENCE'] || '';
    const experiences = this.extractExperience(expText);

    // 6. Projects Extraction
    const projText = sections['PROJECTS'] || '';
    const projects = this.extractProjects(projText);

    // 7. Certifications & Achievements Extraction
    const certText = sections['CERTIFICATIONS'] || '';
    const certifications = this.extractCertifications(certText);

    const achText = sections['ACHIEVEMENTS'] || '';
    const achievements = this.extractAchievements(achText);

    // 8. Validation, Confidence Scoring & Consistency Checking
    const { uncertainFields, fieldConfidence, conflictingFields } = this.validateAndScore({
      personal,
      class10,
      class12,
      btech,
      higherEducation,
      skills,
      experiences,
      projects,
      rawText: normalizedRaw,
    });

    return {
      profile: {
        personal,
        class10,
        class12,
        btech,
        higherEducation,
        skills,
        experiences,
        projects,
        certifications,
        achievements,
      },
      rawText: normalizedRaw,
      isScannedPdf: false,
      needsOcr: false,
      uncertainFields,
      fieldConfidence,
      conflictingFields,
    };
  }

  /**
   * Segments lines into major resume sections based on standalone headings.
   */
  private static segmentSections(lines: string[]): Record<string, string> {
    const sections: Record<string, string> = {};
    let currentSection = 'HEADER';
    let currentText: string[] = [];

    const sectionRegexes: Record<string, RegExp> = {
      SUMMARY: /^(?:summary|professional summary|career objective|objective|about me|profile summary|executive summary|about)\b/i,
      EDUCATION: /^(?:education|academic|qualifications|academic background|educational background|academic history|degrees?)\b/i,
      EXPERIENCE: /^(?:experience|work experience|employment|internships|work history|professional experience|career history|industry experience)\b/i,
      PROJECTS: /^(?:projects|academic projects|key projects|personal projects|notable projects|selected projects|technical projects)\b/i,
      SKILLS: /^(?:skills|technical skills|technologies|core competencies|tools|skills & competencies|technical proficiencies|areas of expertise|competencies)\b/i,
      CERTIFICATIONS: /^(?:certifications|certificates|licenses|accreditations|courses|trainings?)\b/i,
      ACHIEVEMENTS: /^(?:achievements|awards|honors|extracurricular activities|accomplishments|hackathons|co-curricular activities)\b/i,
    };

    for (const line of lines) {
      const trimmed = line.trim();

      // If line is an inline property with content (e.g. "Technologies: React, Node"), it belongs inside the current section
      if (/^(?:technologies|tools|skills|languages|summary|projects|education|experience|phone|email|location|github|linkedin)\s*[:=-]\s*.+/i.test(trimmed)) {
        currentText.push(line);
        continue;
      }

      let matchedSection = '';
      const cleanHeader = trimmed.replace(/[:\s]+$/, '');
      if (cleanHeader.length > 0 && cleanHeader.length <= 45) {
        for (const [sec, regex] of Object.entries(sectionRegexes)) {
          if (regex.test(cleanHeader)) {
            matchedSection = sec;
            break;
          }
        }
      }

      if (matchedSection) {
        if (currentSection && currentText.length > 0) {
          const content = currentText.join('\n');
          sections[currentSection] = sections[currentSection] ? sections[currentSection] + '\n' + content : content;
        }
        currentSection = matchedSection;
        currentText = [];
      } else {
        currentText.push(line);
      }
    }

    if (currentSection && currentText.length > 0) {
      const content = currentText.join('\n');
      sections[currentSection] = sections[currentSection] ? sections[currentSection] + '\n' + content : content;
    }

    return sections;
  }

  /**
   * Extracts personal contact details and social links.
   */
  private static extractPersonalInfo(
    rawText: string,
    lines: string[],
    sections: Record<string, string>
  ): UserProfile['personal'] {
    // 1. Email Extraction
    const emailMatch = rawText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    const email = emailMatch ? emailMatch[0].toLowerCase().trim() : '';

    // 2. Phone Extraction
    let phone = '';
    let whatsapp = '';

    // Check for explicit WhatsApp label
    const waMatch = rawText.match(/(?:whatsapp|wa|whatsapp no)\s*[:=-]?\s*(?:\+?91[-.\s]?)?([6-9]\d{9})\b/i);
    if (waMatch) {
      whatsapp = waMatch[1];
    }

    // Phone (Indian mobile numbers, international formats)
    const phoneMatch = rawText.match(
      /(?:(?:phone|mobile|contact|cell|tel)\s*[:=-]?\s*)?(?:(?:\+?91[-.\s]?)?([6-9]\d{9})\b|(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})\b|(?:\+\d{1,3}[-.\s]?)?(\d{10,12})\b)/i
    );

    if (phoneMatch) {
      if (phoneMatch[1]) {
        phone = phoneMatch[1];
      } else if (phoneMatch[2] && phoneMatch[3] && phoneMatch[4]) {
        phone = `${phoneMatch[2]}${phoneMatch[3]}${phoneMatch[4]}`;
      } else if (phoneMatch[5]) {
        const rawPhone = phoneMatch[5].replace(/[^\d]/g, '');
        phone = rawPhone.length === 12 && rawPhone.startsWith('91') ? rawPhone.substring(2) : rawPhone;
      }
    }

    if (!whatsapp) {
      whatsapp = phone;
    }

    // 3. Social & Portfolio links
    const linkedinMatch =
      rawText.match(/(?:https?:\/\/)?(?:www\.)?linkedin\.com\/in\/([a-zA-Z0-9_-]+)/i) ||
      rawText.match(/(?:https?:\/\/)?(?:www\.)?linkedin\.com\/([a-zA-Z0-9_-]+)/i);
    const linkedin = linkedinMatch
      ? linkedinMatch[0].startsWith('http')
        ? linkedinMatch[0]
        : 'https://' + linkedinMatch[0]
      : '';

    const githubMatch = rawText.match(/(?:https?:\/\/)?(?:www\.)?github\.com\/([a-zA-Z0-9_-]+)/i);
    const github = githubMatch
      ? githubMatch[0].startsWith('http')
        ? githubMatch[0]
        : 'https://' + githubMatch[0]
      : '';

    const portfolioMatch = rawText.match(
      /(?:https?:\/\/)?(?:www\.)?(?:[a-zA-Z0-9_-]+\.(?:dev|me|io|tech|app|vercel\.app|netlify\.app|github\.io|com|in))\b(?!\/(?:in|github))/i
    );
    const portfolio =
      portfolioMatch &&
      !portfolioMatch[0].toLowerCase().includes('linkedin') &&
      !portfolioMatch[0].toLowerCase().includes('github') &&
      !portfolioMatch[0].toLowerCase().includes('gmail')
        ? portfolioMatch[0].startsWith('http')
          ? portfolioMatch[0]
          : 'https://' + portfolioMatch[0]
        : '';

    // 4. Candidate Full Name
    const fullName = this.extractFullName(lines, email);
    const nameParts = fullName ? fullName.split(' ') : [];
    const firstName = nameParts[0] || '';
    const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';

    // 5. Current Location / Address (scan lines before the first major section header)
    const firstSectionIdx = lines.findIndex((l) =>
      /^(?:education|academic|qualifications|experience|work experience|employment|projects|skills|technical skills|summary|objective|certifications|achievements)\b/i.test(
        l.trim()
      )
    );
    const candidateHeaderLines = firstSectionIdx > 0 ? lines.slice(0, firstSectionIdx) : lines.slice(0, 8);
    const currentLocation = this.extractLocation(rawText, candidateHeaderLines);

    // 6. Professional Summary
    const summary = this.extractSummary(sections['SUMMARY'] || '');

    return {
      fullName,
      firstName,
      lastName,
      email,
      phoneNumber: phone,
      whatsappNumber: whatsapp,
      currentLocation,
      linkedin,
      github,
      portfolio,
      summary,
    };
  }

  /**
   * Intelligently extracts full name by discarding document headers,
   * professions, contact lines, and correlating with email when available.
   */
  private static extractFullName(lines: string[], email: string): string {
    const invalidProfessionWords = new Set([
      'developer', 'engineer', 'architect', 'designer', 'manager', 'lead', 'analyst',
      'consultant', 'specialist', 'student', 'fresher', 'intern', 'graduate', 'candidate',
      'programmer', 'fullstack', 'frontend', 'backend', 'devops', 'tester', 'associate',
      'officer', 'executive', 'researcher', 'scientist', 'administrator', 'coordinator'
    ]);

    const invalidHeaderWords = new Set([
      'resume', 'curriculum', 'vitae', 'cv', 'contact', 'email', 'phone', 'address',
      'location', 'profile', 'summary', 'objective', 'education', 'skills', 'experience',
      'projects', 'page', 'portfolio', 'about', 'details', 'bio', 'github', 'linkedin'
    ]);

    let candidateName = '';

    // 1. Check for explicit "Name:" labels
    for (let i = 0; i < Math.min(lines.length, 12); i++) {
      const match = lines[i].match(/^(?:name|candidate name|full name|applicant name)\s*[:=-]\s*([A-Za-z\s.'-]+)/i);
      if (match && match[1].trim().length > 2 && match[1].trim().length < 45) {
        return match[1].trim();
      }
    }

    // 2. Scan top 10 lines for valid name structures
    for (let i = 0; i < Math.min(lines.length, 10); i++) {
      let line = lines[i].trim();

      // Skip lines with emails, URLs, or phone numbers
      if (line.includes('@') || line.includes('http') || line.includes('www.') || line.includes('.com')) {
        continue;
      }
      if (/\b\d{5,}\b/.test(line)) {
        continue;
      }

      // Check length and alphabetic constraints
      if (line.length < 3 || line.length > 45) continue;
      if (!/^[A-Za-z\s.'-]+$/.test(line)) continue;

      const words = line.toLowerCase().split(/\s+/).filter(Boolean);
      if (words.length < 1 || words.length > 4) continue;

      // Reject if any word matches invalid profession or section header
      const hasProfession = words.some((w) => invalidProfessionWords.has(w));
      const hasHeader = words.some((w) => invalidHeaderWords.has(w));
      if (hasProfession || hasHeader) continue;

      // Prefer capitalized name
      if (
        /^(?:(?:Dr|Mr|Mrs|Ms|Prof)\.?\s+)?[A-Z][A-Za-z.'-]+(?:\s+[A-Za-z.'-]+){1,4}$/.test(line) ||
        /^[A-Z\s.'-]+$/.test(line)
      ) {
        candidateName = line;

        // If email handle matches parts of the name, this is guaranteed
        if (email) {
          const emailHandle = email.split('@')[0].toLowerCase();
          const matchesEmail = words.some((w) => w.length >= 3 && emailHandle.includes(w));
          if (matchesEmail) {
            return line;
          }
        }
        break;
      }
    }

    return candidateName;
  }

  /**
   * Determines if a line or string consists of technical skills, programming tools,
   * frameworks, or non-location metadata that should NEVER be mapped as an address.
   */
  private static isLikelySkillOrTechnicalText(text: string): boolean {
    if (!text || typeof text !== 'string') return true;
    const clean = text.trim();
    if (clean.length === 0) return true;

    // Check for explicit skill section prefixes
    if (
      /^(?:skills|technical skills|key skills|technologies|tools|languages|programming languages|frameworks|libraries|databases|core competencies|proficiencies)\s*[:=-]/i.test(
        clean
      )
    ) {
      return true;
    }

    // Check for other non-address section or document headers
    if (
      /^(?:education|experience|work experience|employment|projects|academic projects|certifications|awards|summary|objective|achievements)\b/i.test(
        clean
      )
    ) {
      return true;
    }

    const lower = clean.toLowerCase();

    // Catalog of programming languages, libraries, platforms, and technical skill tokens
    const skillTokens = new Set([
      'python', 'nlp', 'natural language processing', 'java', 'javascript', 'typescript',
      'c', 'c++', 'c#', 'golang', 'go', 'rust', 'ruby', 'php', 'swift', 'kotlin', 'dart', 'scala',
      'r', 'matlab', 'sql', 'nosql', 'mysql', 'postgresql', 'postgres', 'mongodb', 'redis', 'sqlite',
      'oracle', 'cassandra', 'dynamodb', 'react', 'react.js', 'reactjs', 'next.js', 'nextjs',
      'angular', 'angularjs', 'vue', 'vue.js', 'vuejs', 'svelte', 'node', 'node.js', 'nodejs',
      'express', 'express.js', 'django', 'flask', 'fastapi', 'spring', 'spring boot', 'html', 'html5',
      'css', 'css3', 'sass', 'scss', 'tailwind', 'tailwindcss', 'bootstrap', 'redux', 'graphql',
      'rest', 'rest api', 'restful', 'api', 'apis', 'grpc', 'docker', 'kubernetes', 'k8s',
      'aws', 'azure', 'gcp', 'google cloud', 'git', 'github', 'gitlab', 'ci/cd', 'jenkins', 'linux',
      'bash', 'powershell', 'devops', 'terraform', 'ansible', 'machine learning', 'deep learning',
      'artificial intelligence', 'ai', 'ml', 'pytorch', 'tensorflow', 'keras', 'pandas', 'numpy',
      'scikit-learn', 'scikit', 'opencv', 'transformers', 'bert', 'gpt', 'llm', 'llms', 'data science',
      'data structures', 'algorithms', 'dsa', 'power bi', 'tableau', 'figma', 'postman', 'jira',
      'agile', 'scrum', 'microservices', 'selenium', 'jest', 'cypress', 'kafka', 'rabbitmq'
    ]);

    // Check if the whole string matches a known technical skill
    if (skillTokens.has(lower)) {
      return true;
    }

    // Split candidate text into individual tokens separated by comma, pipe, slash, bullet, or semicolon
    const tokens = lower
      .split(/[,|/•;\t]+/)
      .map((t) => t.trim().replace(/^[-*•\s]+/, '').replace(/[-*•\s]+$/, ''))
      .filter((t) => t.length > 0);

    if (tokens.length === 0) return true;

    // Count how many tokens are identified as technical skills
    let skillCount = 0;
    for (const t of tokens) {
      if (skillTokens.has(t)) {
        skillCount++;
      }
    }

    // If any token is a known tech skill and there's no identifiable country/city, it's skills
    if (skillCount > 0) {
      const hasRealLocation = /\b(india|usa|united states|uk|united kingdom|canada|germany|france|australia|singapore|uae|dubai|pune|mumbai|bengaluru|bangalore|hyderabad|delhi|new delhi|chennai|kolkata|noida|gurgaon|gurugram|ahmedabad|jaipur|kochi|indore|nagpur|san francisco|new york|seattle|austin|boston|chicago|los angeles|london|berlin|toronto|vancouver)\b/i.test(
        lower
      );
      if (!hasRealLocation) {
        return true;
      }
    }

    return false;
  }

  /**
   * Extracts location or city, state, country from explicit labels or header lines.
   * Ensures that technical skills (such as "Python, NLP") or project/job details are
   * NEVER mapped to the address field.
   */
  private static extractLocation(rawText: string, headerLines: string[]): string {
    // 1. Check explicit Address/Location labels
    const explicitLabelRegex = /(?:current location|present location|current address|present address|permanent address|location|address|current city|present city|city|residence)\s*[:=-]\s*([^\r\n|•]+)/i;
    const explicitMatch = rawText.match(explicitLabelRegex);

    if (explicitMatch && explicitMatch[1]) {
      const candidate = explicitMatch[1].replace(/[^\w\s,.-]/g, '').trim();
      if (
        candidate.length > 2 &&
        candidate.length < 100 &&
        !candidate.includes('@') &&
        !candidate.includes('http') &&
        !candidate.includes('www.') &&
        !this.isLikelySkillOrTechnicalText(candidate)
      ) {
        return candidate;
      }
    }

    // 2. Scan top header lines (lines 0-12) for authentic geographic locations
    const usCaStateCodes = 'AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|ON|BC|QC|AB';
    const countryNames = 'India|USA|United States|United Kingdom|UK|Canada|Australia|Germany|France|Singapore|UAE|United Arab Emirates|Netherlands|Ireland|Japan|Switzerland';
    const indianStates = 'Maharashtra|Karnataka|Tamil Nadu|Telangana|Andhra Pradesh|Delhi|Uttar Pradesh|Gujarat|Kerala|West Bengal|Rajasthan|Madhya Pradesh|Punjab|Haryana|Bihar|Odisha|Goa';
    const majorCities = 'Bengaluru|Bangalore|Mumbai|Pune|Hyderabad|Delhi|New Delhi|Chennai|Kolkata|Noida|Gurgaon|Gurugram|Ahmedabad|Jaipur|Chandigarh|Kochi|Indore|Nagpur|Bhopal|Lucknow|Coimbatore|Visakhapatnam|San Francisco|San Jose|New York|Seattle|Austin|Boston|Chicago|Los Angeles|London|Berlin|Munich|Toronto|Vancouver|Singapore|Dubai';

    for (const line of headerLines) {
      const trimmed = line.trim();

      // Skip lines with emails, URLs, or handles
      if (
        trimmed.includes('@') ||
        trimmed.includes('http') ||
        trimmed.includes('github') ||
        trimmed.includes('linkedin') ||
        trimmed.includes('portfolio') ||
        /\b(?:phone|mobile|email|contact no|tel)\b/i.test(trimmed)
      ) {
        continue;
      }

      // Reject lines that look like skills or technologies immediately
      if (this.isLikelySkillOrTechnicalText(trimmed)) {
        continue;
      }

      // Reject educational institutions, universities, companies, or degree lines
      if (
        /\b(institute|college|university|school|academy|polytechnic|campus|technologies|solutions|corporation|company|pvt|ltd|inc|llc|foundation|hospital|department|faculty|bachelor|master|degree|b\.?tech|b\.?e\b|m\.?tech|mba|engineering)\b/i.test(
          trimmed
        )
      ) {
        continue;
      }

      // Pattern 1: City/State with explicit Country (e.g. "Pune, Maharashtra, India" or "Bangalore, India")
      const countryMatch = trimmed.match(
        new RegExp(`\\b([A-Z][a-zA-Z\\s.'-]+,\\s*(?:[A-Z][a-zA-Z\\s.'-]+,\\s*)?(?:${countryNames}))\\b`, 'i')
      );
      if (countryMatch && !this.isLikelySkillOrTechnicalText(countryMatch[1])) {
        const val = countryMatch[1].trim();
        if (val.length > 3 && val.length < 80) return val;
      }

      // Pattern 2: City with recognized State (e.g. "Pune, Maharashtra" or "Austin, TX")
      const stateMatch = trimmed.match(
        new RegExp(`\\b([A-Z][a-zA-Z\\s.'-]+,\\s*(?:${indianStates}|${usCaStateCodes}))\\b`, 'i')
      );
      if (stateMatch && !this.isLikelySkillOrTechnicalText(stateMatch[1])) {
        const val = stateMatch[1].trim();
        if (val.length > 3 && val.length < 80) return val;
      }

      // Pattern 3: Major tech city name with optional postal PIN/ZIP code or street address
      if (trimmed.length <= 40) {
        const cityMatch = trimmed.match(
          new RegExp(`\\b((?:\\d{1,4}[\\w\\s.'-]+,\\s*)?(?:${majorCities})(?:,\\s*[A-Z]{2})?(?:\\s*[-–,]?\\s*\\d{5,6})?)\\b`, 'i')
        );
        if (cityMatch && !this.isLikelySkillOrTechnicalText(cityMatch[0])) {
          const val = cityMatch[0].trim();
          if (val.length >= 3 && val.length < 80) return val;
        }
      }
    }

    // 3. Fallback: No verified location found -> return empty string (never guess or substitute skills)
    return '';
  }

  /**
   * Extracts career summary or objective text cleanly.
   */
  private static extractSummary(summaryText: string): string {
    if (!summaryText) return '';
    const clean = summaryText
      .replace(/^(?:summary|professional summary|career objective|objective|about me|profile summary|executive summary|about)\s*[:=-]?\s*/i, '')
      .replace(/^[-*•\s]+/, '')
      .trim();

    return clean.length > 20 ? clean : '';
  }

  /**
   * Isolates qualification blocks within the education section and extracts
   * Class 10, Class 12, Diploma, UG, and Higher Education entries separately.
   */
  private static extractEducation(eduText: string, rawText: string): {
    class10: UserProfile['class10'];
    class12: UserProfile['class12'];
    btech: UserProfile['btech'];
    higherEducation: HigherEducationItem[];
  } {
    const class10: UserProfile['class10'] = {
      board: '',
      school: '',
      passingYear: '',
      percentage: '',
    };

    const class12: UserProfile['class12'] = {
      qualificationType: '12th',
      boardOrInstitution: '',
      stream: 'Science',
      passingYear: '',
      percentage: '',
    };

    const btech: UserProfile['btech'] = {
      degree: '',
      branch: '',
      college: '',
      passingYear: '',
      cgpa: '',
      activeBacklogs: '0',
      deadBacklogs: '0',
      prn: '',
    };

    const higherEducation: HigherEducationItem[] = [];

    // Split education text into lines
    const lines = eduText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);

    // Segment education into distinct qualification blocks
    const blocks: { tag: string; text: string }[] = [];
    let currentTag = '';
    let currentBlockLines: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Identify qualification headers
      let detectedTag = '';
      if (/\b(10th|tenth|class 10|class x|matric|matriculation|secondary school|ssc)\b/i.test(line)) {
        detectedTag = '10th';
      } else if (/\b(diploma|polytechnic|d\.?voc)\b/i.test(line)) {
        detectedTag = 'diploma';
      } else if (/\b(12th|twelfth|class 12|class xii|intermediate|hsc|senior secondary|plus two|\+2)\b/i.test(line)) {
        detectedTag = '12th';
      } else if (
        /\b(m\.?tech|m\.?e\b|master of technology|mba|mca|m\.?sc|m\.?s\b|ph\.?d|post graduate|pgdm)\b/i.test(line)
      ) {
        detectedTag = 'pg';
      } else if (
        /\b(b\.?tech|b\.?e\b|bachelor of technology|bachelor of engineering|bca|b\.?sc|bachelor of|bba|b\.?com|undergraduate|b\.?pharm)\b/i.test(line)
      ) {
        detectedTag = 'ug';
      }

      if (detectedTag) {
        if (currentTag && currentBlockLines.length > 0) {
          blocks.push({ tag: currentTag, text: currentBlockLines.join('\n') });
        }
        currentTag = detectedTag;
        currentBlockLines = [line];
      } else if (currentTag) {
        currentBlockLines.push(line);
      } else {
        // Line before any tag (e.g. table header)
        currentBlockLines.push(line);
      }
    }

    if (currentTag && currentBlockLines.length > 0) {
      blocks.push({ tag: currentTag, text: currentBlockLines.join('\n') });
    }

    // Process blocks independently to eliminate cross-qualification contamination
    for (const b of blocks) {
      const blockText = b.text;

      if (b.tag === '10th' && !class10.percentage) {
        // Board
        if (/cbse/i.test(blockText)) class10.board = 'CBSE';
        else if (/icse/i.test(blockText)) class10.board = 'ICSE';
        else if (/state\s*board|maharashtra|karnataka|up\s*board|bihar\s*board|state/i.test(blockText)) class10.board = 'State Board';

        // School
        const schoolMatch = blockText.match(
          /(?:[A-Za-z0-9\s.'-]+(?:School|Vidyalaya|Academy|Public School|High School|Convent|Mandir|Pathshala))/i
        );
        if (schoolMatch) class10.school = schoolMatch[0].trim();

        // Score (Percentage or CGPA on 10 scale)
        const score = this.extractNumericScore(blockText);
        if (score) class10.percentage = score;

        // Year
        const yr = this.extractEndingYear(blockText);
        if (yr) class10.passingYear = yr;
      } else if (b.tag === 'diploma') {
        class12.qualificationType = 'Diploma';

        // Polytechnic Institution
        const polyMatch = blockText.match(
          /(?:[A-Za-z0-9\s.'-]+(?:Polytechnic|Institute of Technology|Government Polytechnic|Technical Campus|College))/i
        );
        if (polyMatch) class12.boardOrInstitution = polyMatch[0].trim();
        else if (/msbte/i.test(blockText)) class12.boardOrInstitution = 'MSBTE';

        // Stream / Branch in Diploma
        const streamMatch = this.extractEngineeringBranch(blockText);
        if (streamMatch) class12.stream = streamMatch;

        const score = this.extractNumericScore(blockText);
        if (score) class12.percentage = score;

        const yr = this.extractEndingYear(blockText);
        if (yr) class12.passingYear = yr;
      } else if (b.tag === '12th' && class12.qualificationType !== 'Diploma') {
        class12.qualificationType = '12th';

        if (/cbse/i.test(blockText)) class12.boardOrInstitution = 'CBSE';
        else if (/isc/i.test(blockText)) class12.boardOrInstitution = 'ISC';
        else if (/state\s*board|maharashtra|karnataka|up\s*board|state/i.test(blockText)) class12.boardOrInstitution = 'State Board';
        else {
          const colMatch = blockText.match(/(?:[A-Za-z0-9\s.'-]+(?:Junior College|College|School|Vidyalaya))/i);
          if (colMatch) class12.boardOrInstitution = colMatch[0].trim();
        }

        if (/pcm|non-med/i.test(blockText)) class12.stream = 'Science (PCM)';
        else if (/pcb|medical/i.test(blockText)) class12.stream = 'Science (PCB)';
        else if (/science/i.test(blockText)) class12.stream = 'Science';
        else if (/commerce/i.test(blockText)) class12.stream = 'Commerce';
        else if (/arts|humanities/i.test(blockText)) class12.stream = 'Arts';

        const score = this.extractNumericScore(blockText);
        if (score) class12.percentage = score;

        const yr = this.extractEndingYear(blockText);
        if (yr) class12.passingYear = yr;
      } else if (b.tag === 'ug' && !btech.degree) {
        // Exact Undergraduate degree
        if (/\b(b\.?e\b|bachelor of engineering)\b/i.test(blockText)) btech.degree = 'B.E.';
        else if (/\bbca\b/i.test(blockText)) btech.degree = 'BCA';
        else if (/\bb\.?sc\b/i.test(blockText)) btech.degree = 'B.Sc.';
        else if (/\bbba\b/i.test(blockText)) btech.degree = 'BBA';
        else if (/\bb\.?com\b/i.test(blockText)) btech.degree = 'B.Com';
        else if (/\bb\.?pharm\b/i.test(blockText)) btech.degree = 'B.Pharm';
        else btech.degree = 'B.Tech';

        // College
        const colMatch = blockText.match(
          /(?:[A-Za-z\s.'-]+(?:Institute of Technology|National Institute of Technology|Indian Institute of Information Technology|Institute of Information Technology|University|Engineering College|Institute|College|Campus|Vidyapeeth))/i
        );
        if (colMatch) {
          btech.college = colMatch[0].trim();
        }

        // Branch
        const branchMatch = this.extractEngineeringBranch(blockText);
        if (branchMatch) btech.branch = branchMatch;

        // CGPA / Score
        const score = this.extractCgpaOrPercentage(blockText);
        if (score) btech.cgpa = score;

        // Passing year
        const yr = this.extractEndingYear(blockText);
        if (yr) btech.passingYear = yr;

        // PRN / Roll number
        const prnMatch = blockText.match(/(?:prn|roll\s*no|registration\s*no|enrollment\s*no|urn|usn)\s*[:=-]?\s*([a-zA-Z0-9_-]+)/i);
        if (prnMatch) btech.prn = prnMatch[1];
      } else if (b.tag === 'pg') {
        let qualName = 'M.Tech';
        if (/\bmba\b/i.test(blockText)) qualName = 'MBA';
        else if (/\bmca\b/i.test(blockText)) qualName = 'MCA';
        else if (/\b(m\.?sc|master of science)\b/i.test(blockText)) qualName = 'M.Sc.';
        else if (/\b(m\.?s\b|master of science)\b/i.test(blockText)) qualName = 'M.S.';
        else if (/\bph\.?d\b/i.test(blockText)) qualName = 'Ph.D.';

        const colMatch = blockText.match(
          /(?:[A-Za-z\s.'-]+(?:Institute of Science|Institute of Technology|National Institute of Technology|Indian Institute of Information Technology|Institute|University|College|Campus))/i
        );
        const specMatch = this.extractEngineeringBranch(blockText);
        const yr = this.extractEndingYear(blockText);
        const score = this.extractCgpaOrPercentage(blockText);

        higherEducation.push({
          id: 'he_' + Math.random().toString(36).substr(2, 6),
          qualification: qualName,
          institution: colMatch ? colMatch[0].trim() : '',
          specialization: specMatch || '',
          passingYear: yr || '',
          percentageOrCgpa: score || '',
        });
      }
    }

    // Fallbacks if education section had no explicit headers
    if (!btech.degree && /\b(b\.?tech|b\.?e\b|bachelor of technology|bca|b\.?sc)\b/i.test(rawText)) {
      if (/\b(b\.?e\b)\b/i.test(rawText)) btech.degree = 'B.E.';
      else if (/\bbca\b/i.test(rawText)) btech.degree = 'BCA';
      else if (/\bb\.?sc\b/i.test(rawText)) btech.degree = 'B.Sc.';
      else btech.degree = 'B.Tech';

      btech.branch = this.extractEngineeringBranch(rawText) || '';
      const colMatch = rawText.match(
        /(?:[A-Za-z\s.'-]+(?:Institute of Technology|National Institute of Technology|Institute of Information Technology|University|Engineering College))/i
      );
      if (colMatch) btech.college = colMatch[0].trim();
    }

    return { class10, class12, btech, higherEducation };
  }

  /**
   * Extracts engineering or academic branch from text.
   */
  private static extractEngineeringBranch(text: string): string {
    if (/computer science and engineering|computer engineering|cse/i.test(text)) {
      return 'Computer Science and Engineering';
    } else if (/information technology|it\b/i.test(text) && !/polytechnic/i.test(text)) {
      return 'Information Technology';
    } else if (/electronics and (?:communication|telecommunication)|ece|electronics & communication|telecommunication/i.test(text)) {
      return 'Electronics and Communication';
    } else if (/artificial intelligence and data science|ai & ds|ai and ds/i.test(text)) {
      return 'Artificial Intelligence and Data Science';
    } else if (/artificial intelligence|\bai\b/i.test(text)) {
      return 'Artificial Intelligence';
    } else if (/data science/i.test(text)) {
      return 'Data Science';
    } else if (/mechanical engineering|mechanical/i.test(text)) {
      return 'Mechanical Engineering';
    } else if (/electrical engineering|electrical and electronics|eee/i.test(text)) {
      return 'Electrical Engineering';
    } else if (/civil engineering|civil/i.test(text)) {
      return 'Civil Engineering';
    } else if (/chemical engineering|chemical/i.test(text)) {
      return 'Chemical Engineering';
    } else if (/biotechnology|biotech/i.test(text)) {
      return 'Biotechnology';
    }
    return '';
  }

  /**
   * Accurately extracts a numeric academic score (percentage or CGPA).
   */
  private static extractNumericScore(block: string): string {
    // 1. Explicit percentage label
    const pctMatch =
      block.match(/(?:percentage|percent|marks|aggregate|score)\s*[:=-]?\s*(\d{1,2}(?:\.\d{1,2})?)/i) ||
      block.match(/(\d{1,2}(?:\.\d{1,2})?)\s*(?:%|\bpercent\b)/i);
    if (pctMatch) {
      return pctMatch[1];
    }

    // 2. Explicit CGPA label
    const cgpaMatch = block.match(/(?:cgpa|gpa|pointer)\s*[:=-]?\s*(\d{1,2}(?:\.\d{1,2})?)/i);
    if (cgpaMatch) {
      return cgpaMatch[1];
    }

    // 3. Fallback to percentage pattern
    const fallback = block.match(/\b(\d{2}(?:\.\d{1,2})?)\s*%/);
    return fallback ? fallback[1] : '';
  }

  /**
   * Distinguishes CGPA (scale <= 10.0) from Percentage (scale > 10.0) for degree fields.
   */
  private static extractCgpaOrPercentage(block: string): string {
    const cgpaMatch = block.match(/(?:cgpa|gpa|pointer)\s*[:=-]?\s*(\d{1,2}(?:\.\d{1,2})?)/i);
    if (cgpaMatch) {
      return cgpaMatch[1];
    }

    const pctMatch = block.match(/(?:percentage|percent|marks|aggregate)\s*[:=-]?\s*(\d{1,2}(?:\.\d{1,2})?)/i) ||
      block.match(/(\d{1,2}(?:\.\d{1,2})?)\s*%/);
    if (pctMatch) {
      return pctMatch[1];
    }

    // General floating number on 10 scale (e.g. 8.85, 9.12)
    const floatMatch = block.match(/\b([5-9]\.\d{1,2})\b/);
    return floatMatch ? floatMatch[1] : '';
  }

  /**
   * Extracts the completion / passing year from a block or date range (e.g. 2020-2024 -> 2024).
   */
  private static extractEndingYear(block: string): string {
    // 1. Date range (start - end) -> extract end year
    const rangeMatch = block.match(/\b(200\d|201\d|202\d)\s*[-–—to]+\s*(200\d|201\d|202\d|203\d)\b/i);
    if (rangeMatch) {
      return rangeMatch[2];
    }

    // 2. Explicit passing year label
    const explicitMatch = block.match(
      /(?:passing year|pass year|year of passing|yop|graduation year|passed in|batch)\s*[:=-]?\s*(200\d|201\d|202\d|203\d)\b/i
    );
    if (explicitMatch) {
      return explicitMatch[1];
    }

    // 3. Standalone year
    const standaloneMatch = block.match(/\b(200\d|201\d|202\d|203\d)\b/);
    return standaloneMatch ? standaloneMatch[1] : '';
  }

  /**
   * Extracts technical and soft skills cleanly without capturing document noise.
   */
  private static extractSkills(skillsText: string, rawText: string): string[] {
    const knownSkills = [
      // Languages
      'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'C', 'Go', 'Golang', 'Rust',
      'PHP', 'Ruby', 'Swift', 'Kotlin', 'Dart', 'SQL', 'R', 'HTML', 'HTML5', 'CSS', 'CSS3',
      // Web & Frontend
      'React', 'React.js', 'Next.js', 'Vue', 'Vue.js', 'Angular', 'Svelte', 'Node.js', 'Express', 'Express.js',
      'Django', 'Flask', 'FastAPI', 'Spring Boot', 'Tailwind CSS', 'Bootstrap', 'Redux', 'GraphQL',
      'REST API', 'Webpack', 'Vite', 'Sass',
      // Databases & Cloud
      'MongoDB', 'PostgreSQL', 'MySQL', 'Redis', 'Firebase', 'Supabase', 'SQLite', 'Oracle',
      'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP', 'Google Cloud', 'Git', 'GitHub', 'Linux',
      'CI/CD', 'Jenkins', 'Terraform',
      // AI & Data
      'NLP', 'Natural Language Processing', 'Machine Learning', 'Deep Learning', 'PyTorch', 'TensorFlow', 'Pandas', 'NumPy',
      'Scikit-learn', 'OpenCV', 'Data Structures', 'Algorithms', 'Power BI', 'Tableau', 'Computer Vision', 'LLMs', 'Generative AI',
      // Tools & Testing
      'Figma', 'Postman', 'Jira', 'Agile', 'Scrum', 'Jest', 'Cypress',
      // Soft Skills
      'Problem Solving', 'Critical Thinking', 'Team Leadership', 'Communication', 'Project Management',
      'Time Management', 'Agile Methodology', 'Adaptability'
    ];

    const found = new Set<string>();

    // 1. Keyword matching for known skills catalog across entire resume text
    for (const s of knownSkills) {
      const escaped = s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const r = new RegExp(`(?:^|[^a-zA-Z0-9#+])${escaped}(?:$|[^a-zA-Z0-9#+])`, 'i');
      if (r.test(rawText)) {
        found.add(s);
      }
    }

    // 2. Parse skill tokens from SKILLS section if present
    if (skillsText) {
      const lines = skillsText.split(/\r?\n/);
      for (const line of lines) {
        // Strip category prefixes like "Programming Languages:", "Frameworks:", "Tools:"
        const cleanedLine = line.replace(/^(?:languages|frameworks|tools|libraries|technologies|databases|skills|core competencies)\s*[:=-]\s*/i, '');
        const tokens = cleanedLine.split(/[,|•;•·\/]/);
        for (let t of tokens) {
          t = t.trim().replace(/^[-*•\s]+/, '').replace(/[-*•\s]+$/, '');
          if (
            t.length >= 2 &&
            t.length <= 32 &&
            !/^(?:and|the|with|proficient|experienced|familiar|knowledge|of|in|etc|skills|tools|date|link|repo)$/i.test(t) &&
            !t.includes('@') &&
            !t.includes('http') &&
            !t.includes(':')
          ) {
            const existing = Array.from(found).find((k) => k.toLowerCase() === t.toLowerCase());
            if (!existing) {
              found.add(t);
            }
          }
        }
      }
    }

    return Array.from(found);
  }

  /**
   * Extracts work experiences and internships with role, company, dates, and descriptions.
   */
  private static extractExperience(expText: string): WorkExperienceItem[] {
    if (!expText) return [];
    const lines = expText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const exps: WorkExperienceItem[] = [];

    let currentExp: WorkExperienceItem | null = null;

    for (const line of lines) {
      const cleanLine = line.trim();
      const isBullet = cleanLine.startsWith('-') || cleanLine.startsWith('•') || cleanLine.startsWith('*');
      const isAction = /^(?:built|developed|implemented|engineered|managed|created|designed|maintained|architected|collaborated|integrated|spearheaded|responsible|worked|assisted|delivered|led|optimized)\b/i.test(cleanLine);

      if (isBullet || isAction) {
        if (currentExp) {
          const content = cleanLine.replace(/^[-*•\s]+/, '');
          currentExp.description += (currentExp.description ? ' ' : '') + content;
        }
        continue;
      }

      // Check if line contains date range
      const monthPattern = '(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)';
      const dateToken = `(?:${monthPattern}\\s*\\d{2,4}|\\d{1,2}\\/\\d{2,4}|\\b\\d{4}\\b|${monthPattern})`;
      const expDateRegex = new RegExp(`(?:${dateToken})\\s*(?:[-–—]|\\bto\\b)\\s*(?:Present|Current|till date|now|${dateToken})`, 'i');
      const dateMatch = cleanLine.match(expDateRegex);

      if (dateMatch && currentExp && !currentExp.startDate) {
        const parts = dateMatch[0].split(/\s*(?:[-–—]|\bto\b)\s*/i);
        currentExp.startDate = (parts[0] || '').trim();
        currentExp.endDate = (parts[1] || '').trim();
        currentExp.isCurrent = /present|current|till date|now/i.test(currentExp.endDate);
        continue;
      }

      // Check if line is a companion company name for an existing role
      if (
        currentExp &&
        currentExp.company === 'Company' &&
        !/\b(intern|engineer|developer|analyst|designer|consultant|lead|manager|assistant|scientist|researcher)\b/i.test(cleanLine) &&
        !dateMatch
      ) {
        currentExp.company = cleanLine;
        continue;
      }

      // Check if line is an experience header
      if (cleanLine.length > 2 && cleanLine.length < 75) {
        let company = cleanLine;
        let role = 'Software Developer';

        if (cleanLine.includes('|')) {
          const parts = cleanLine.split('|');
          company = parts[0].trim();
          role = parts[1].trim();
        } else if (cleanLine.includes(' - ') && !dateMatch) {
          const parts = cleanLine.split(' - ');
          company = parts[0].trim();
          role = parts[1].trim();
        } else if (
          /\b(intern|engineer|developer|analyst|designer|consultant|lead|manager|trainee|apprentice|scientist|researcher|specialist|fellow|postdoc|instructor|professor|director|officer|associate)\b/i.test(cleanLine)
        ) {
          role = cleanLine;
          company = 'Company';
        }

        if (currentExp) exps.push(currentExp);
        currentExp = {
          id: 'exp_' + Math.random().toString(36).substr(2, 6),
          company,
          role,
          startDate: dateMatch ? (dateMatch[0].split(/\s*(?:[-–—]|\bto\b)\s*/i)[0] || '').trim() : '',
          endDate: dateMatch ? (dateMatch[0].split(/\s*(?:[-–—]|\bto\b)\s*/i)[1] || '').trim() : '',
          description: '',
          isInternship: /\b(intern|internship|trainee|apprentice)\b/i.test(role) || /\b(intern|internship)\b/i.test(cleanLine),
          isCurrent: dateMatch ? /present|current|till date|now/i.test(dateMatch[0]) : false,
        };
      } else if (currentExp) {
        const content = cleanLine.replace(/^[-*•\s]+/, '');
        currentExp.description += (currentExp.description ? ' ' : '') + content;
      }
    }

    if (currentExp) exps.push(currentExp);
    return exps.slice(0, 6);
  }

  /**
   * Extracts projects with title, tech stack, link, dates, and descriptions.
   */
  private static extractProjects(projText: string): ProjectItem[] {
    if (!projText) return [];
    const lines = projText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const projects: ProjectItem[] = [];

    let currentProject: ProjectItem | null = null;

    for (const line of lines) {
      const cleanLine = line.trim();
      const isBullet = cleanLine.startsWith('-') || cleanLine.startsWith('•') || cleanLine.startsWith('*');
      const isAction = /^(?:built|developed|implemented|engineered|managed|created|designed|maintained|architected|collaborated|integrated|spearheaded|responsible|worked|assisted|delivered)\b/i.test(cleanLine);
      const isProperty = /^(?:tech(?:nologies| stack)?|tools?|built with|role|date|duration|period|link|url|repo|github)\s*[:=-]/i.test(cleanLine);

      if (currentProject && (isProperty || isBullet || isAction)) {
        // Link
        const linkMatch = cleanLine.match(/https?:\/\/[^\s)]+/);
        if (linkMatch && !currentProject.link) {
          currentProject.link = linkMatch[0];
        }

        // Tech stack
        const techMatch = cleanLine.match(/(?:tech(?:nologies| stack)?|tools?|built with)\s*[:=-]\s*(.+)/i);
        if (techMatch && !currentProject.technologies) {
          currentProject.technologies = techMatch[1].trim();
        }

        // Date
        const dateMatch = cleanLine.match(/(?:date|duration|period)\s*[:=-]\s*(.+)/i);
        if (dateMatch && !currentProject.date) {
          currentProject.date = dateMatch[1].trim();
        }

        if (isAction || isBullet) {
          const content = cleanLine.replace(/^[-*•\s]+/, '');
          currentProject.description += (currentProject.description ? ' ' : '') + content;
        }
        continue;
      }

      // Check if line looks like a project title
      if (!isBullet && cleanLine.length > 2 && cleanLine.length < 65) {
        if (currentProject) projects.push(currentProject);

        let title = cleanLine;
        let technologies = '';

        // Extract inline tech stack if separated by pipe or parentheses
        if (cleanLine.includes('|')) {
          const parts = cleanLine.split('|');
          title = parts[0].trim();
          technologies = parts[1].trim();
        } else if (cleanLine.includes('(') && cleanLine.includes(')')) {
          const parenMatch = cleanLine.match(/^(.*?)\((.*?)\)$/);
          if (parenMatch) {
            title = parenMatch[1].trim();
            technologies = parenMatch[2].trim();
          }
        }

        currentProject = {
          id: 'proj_' + Math.random().toString(36).substr(2, 6),
          title,
          technologies,
          link: '',
          description: '',
          date: '',
        };
      } else if (currentProject) {
        const content = cleanLine.replace(/^[-*•\s]+/, '');
        currentProject.description += (currentProject.description ? ' ' : '') + content;
      }
    }

    if (currentProject) projects.push(currentProject);
    return projects.slice(0, 6);
  }

  /**
   * Extracts discrete certification names and dates.
   */
  private static extractCertifications(certText: string): string[] {
    if (!certText) return [];
    const lines = certText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const certs: string[] = [];

    for (let line of lines) {
      line = line.replace(/^[-*•\s]+/, '').trim();
      if (
        line.length > 3 &&
        line.length < 100 &&
        !/^(?:certifications|certificates|licenses)\b/i.test(line)
      ) {
        certs.push(line);
      }
    }

    return certs.slice(0, 8);
  }

  /**
   * Extracts discrete achievement entries and honors.
   */
  private static extractAchievements(achText: string): string[] {
    if (!achText) return [];
    const lines = achText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const achs: string[] = [];

    for (let line of lines) {
      line = line.replace(/^[-*•\s]+/, '').trim();
      if (
        line.length > 3 &&
        line.length < 120 &&
        !/^(?:achievements|awards|honors|extracurricular activities)\b/i.test(line)
      ) {
        achs.push(line);
      }
    }

    return achs.slice(0, 8);
  }

  /**
   * Performs validation, consistency checks, and computes confidence scores.
   * Identifies missing, out-of-range, and chronologically conflicting fields.
   */
  private static validateAndScore(data: {
    personal: UserProfile['personal'];
    class10: UserProfile['class10'];
    class12: UserProfile['class12'];
    btech: UserProfile['btech'];
    higherEducation: HigherEducationItem[];
    skills: string[];
    experiences: WorkExperienceItem[];
    projects: ProjectItem[];
    rawText: string;
  }): {
    uncertainFields: string[];
    fieldConfidence: Record<string, number>;
    conflictingFields: string[];
  } {
    const uncertainFields: string[] = [];
    const conflictingFields: string[] = [];
    const fieldConfidence: Record<string, number> = {};

    // 1. Full Name Validation
    if (data.personal.fullName && data.personal.fullName.length >= 3) {
      const words = data.personal.fullName.split(' ');
      if (words.length >= 2 && words.every((w) => /^[A-Z]/.test(w))) {
        fieldConfidence['personal.fullName'] = 0.96;
      } else {
        fieldConfidence['personal.fullName'] = 0.85;
      }
    } else {
      uncertainFields.push('personal.fullName');
      fieldConfidence['personal.fullName'] = 0;
    }

    // 2. Email Validation
    if (data.personal.email && /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(data.personal.email)) {
      fieldConfidence['personal.email'] = 0.99;
    } else {
      uncertainFields.push('personal.email');
      fieldConfidence['personal.email'] = 0;
    }

    // 3. Phone Validation
    const cleanDigits = (data.personal.phoneNumber || '').replace(/\D/g, '');
    if (cleanDigits.length >= 10 && cleanDigits.length <= 15) {
      fieldConfidence['personal.phoneNumber'] = 0.96;
    } else {
      uncertainFields.push('personal.phoneNumber');
      fieldConfidence['personal.phoneNumber'] = 0;
    }

    // 4. Location
    if (data.personal.currentLocation && data.personal.currentLocation.length >= 3) {
      fieldConfidence['personal.currentLocation'] = 0.90;
    } else {
      uncertainFields.push('personal.currentLocation');
      fieldConfidence['personal.currentLocation'] = 0;
    }

    // 5. Class 10 Validation
    const c10Pct = parseFloat(data.class10.percentage);
    if (!isNaN(c10Pct) && c10Pct >= 30 && c10Pct <= 100) {
      fieldConfidence['class10.percentage'] = 0.95;
    } else if (!isNaN(c10Pct) && c10Pct >= 4 && c10Pct <= 10) {
      // CGPA on 10 scale
      fieldConfidence['class10.percentage'] = 0.92;
    } else {
      uncertainFields.push('class10.percentage');
      fieldConfidence['class10.percentage'] = 0;
    }

    if (data.class10.passingYear && /^(?:199\d|200\d|201\d|202\d)\b/.test(data.class10.passingYear)) {
      fieldConfidence['class10.passingYear'] = 0.95;
    }

    // 6. Class 12 / Diploma Validation
    const c12Pct = parseFloat(data.class12.percentage);
    if (!isNaN(c12Pct) && c12Pct >= 30 && c12Pct <= 100) {
      fieldConfidence['class12.percentage'] = 0.95;
    } else if (!isNaN(c12Pct) && c12Pct >= 4 && c12Pct <= 10) {
      fieldConfidence['class12.percentage'] = 0.92;
    } else {
      uncertainFields.push('class12.percentage');
      fieldConfidence['class12.percentage'] = 0;
    }

    if (data.class12.passingYear && /^(?:199\d|200\d|201\d|202\d)\b/.test(data.class12.passingYear)) {
      fieldConfidence['class12.passingYear'] = 0.95;
    }

    // 7. Degree / B.Tech Validation
    if (data.btech.degree) {
      fieldConfidence['btech.degree'] = 0.95;

      const cgpaNum = parseFloat(data.btech.cgpa);
      if (!isNaN(cgpaNum) && cgpaNum >= 1.0 && cgpaNum <= 10.0) {
        fieldConfidence['btech.cgpa'] = 0.95;
      } else if (!isNaN(cgpaNum) && cgpaNum >= 35 && cgpaNum <= 100) {
        // Percentage scale
        fieldConfidence['btech.cgpa'] = 0.92;
      } else {
        uncertainFields.push('btech.cgpa');
        fieldConfidence['btech.cgpa'] = 0;
      }

      if (!data.btech.prn) {
        uncertainFields.push('btech.prn');
      } else {
        fieldConfidence['btech.prn'] = 0.92;
      }
    } else {
      fieldConfidence['btech.degree'] = 0;
      fieldConfidence['btech.cgpa'] = 0;
      if (!uncertainFields.includes('btech.degree')) uncertainFields.push('btech.degree');
      if (!uncertainFields.includes('btech.cgpa')) uncertainFields.push('btech.cgpa');
    }

    // 8. Chronological Sanity Checks
    const y10 = parseInt(data.class10.passingYear, 10);
    const y12 = parseInt(data.class12.passingYear, 10);
    const yDegree = parseInt(data.btech.passingYear, 10);

    if (!isNaN(y10) && !isNaN(y12) && y10 >= y12) {
      conflictingFields.push(`Class 10 passing year (${y10}) is not before Class 12 passing year (${y12})`);
      if (!uncertainFields.includes('class10.passingYear')) uncertainFields.push('class10.passingYear');
      if (!uncertainFields.includes('class12.passingYear')) uncertainFields.push('class12.passingYear');
    }

    if (!isNaN(y12) && !isNaN(yDegree) && y12 >= yDegree) {
      conflictingFields.push(`Class 12 passing year (${y12}) is not before Graduation year (${yDegree})`);
      if (!uncertainFields.includes('btech.passingYear')) uncertainFields.push('btech.passingYear');
    }

    // 9. Skills & Experience Confidence
    if (data.skills.length >= 3) {
      fieldConfidence['skills'] = 0.95;
    }

    if (data.experiences.length > 0) {
      fieldConfidence['experiences'] = 0.92;
    }

    if (data.projects.length > 0) {
      fieldConfidence['projects'] = 0.92;
    }

    return { uncertainFields, fieldConfidence, conflictingFields };
  }
}
