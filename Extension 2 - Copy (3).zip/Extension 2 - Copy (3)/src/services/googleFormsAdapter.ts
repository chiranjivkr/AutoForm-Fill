import { DetectedField, FormOption, FillResult } from '../types/form';
import { UserProfile } from '../types/profile';
import { MappingEngine } from './mappingEngine';
import { LearnedMapping } from '../types/learning';

export class GoogleFormsAdapter {
  /**
   * Detects if the current document is a Google Form.
   * Avoids false positives on regular websites that use common 2-letter CSS utility classes like .m2.
   */
  public static isGoogleForm(doc: Document = document): boolean {
    try {
      if (typeof window !== 'undefined' && window.location) {
        if (
          window.location.hostname.includes('docs.google.com') &&
          (window.location.pathname.includes('/forms/') || window.location.pathname.includes('/forms'))
        ) {
          return true;
        }
      }
      if (
        doc.querySelector('form[action*="docs.google.com/forms"], form[action*="/forms/d/e/"], form[action*="forms/d/e"]') !== null ||
        doc.querySelector('.freebirdFormviewerViewFormContent, form.freebirdFormviewerViewFormCard') !== null
      ) {
        return true;
      }
    } catch {
      // ignore
    }
    return false;
  }

  /**
   * Scans all Google Forms question containers in the DOM.
   */
  public static detectFields(
    doc: Document = document,
    profile?: UserProfile,
    learnedMappings: LearnedMapping[] = []
  ): DetectedField[] {
    const fields: DetectedField[] = [];

    // Question containers in modern and classic Google Forms
    const containers = doc.querySelectorAll(
      '[role="listitem"], .geS5n, .Qr7O8, div[jscontroller][data-item-id], div[jsmodel][data-params], .freebirdFormviewerViewNumberedItemContainer'
    );

    containers.forEach((container, index) => {
      // 1. Extract the full question label
      const headingEl = container.querySelector(
        '[role="heading"], .M7eMe, .HoControl, span.M7eMe, div[dir="auto"][role="heading"], div[dir="auto"].M7eMe'
      );
      if (!headingEl) return;

      const rawLabel = (headingEl.textContent || '')
        .replace(/\s*\*$/, '') // strip trailing required asterisk
        .trim();

      if (!rawLabel) return;

      // Also get any sub-description or help text
      const descEl = container.querySelector('.gfh2eb, .M7eMe + div, [id*="desc"]');
      const contextText = descEl ? (descEl.textContent || '').trim() : '';

      // 2. Identify answer control type
      // Check for radio group
      const radioGroup = container.querySelector('[role="radiogroup"]');
      if (radioGroup) {
        const radioOptions: FormOption[] = [];
        const radioEls = container.querySelectorAll('[role="radio"]');

        radioEls.forEach((radioEl) => {
          const labelSpan =
            radioEl.querySelector('.aDTYNe, .docssharedWizToggleLabeledLabelText') ||
            radioEl.closest('label') ||
            radioEl.parentElement;
          const optLabel = (labelSpan?.textContent || radioEl.getAttribute('data-value') || '').trim();
          const optVal = radioEl.getAttribute('data-value') || optLabel;
          const isChecked = radioEl.getAttribute('aria-checked') === 'true';

          radioOptions.push({
            value: optVal,
            label: optLabel,
            ariaChecked: isChecked,
          });
        });

        const fieldId = `gf_radio_${index}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;
        const mapping = profile
          ? MappingEngine.mapField(
              {
                label: rawLabel,
                type: 'radio',
                contextText,
                options: radioOptions,
              },
              profile,
              learnedMappings,
              'docs.google.com'
            )
          : null;

        fields.push({
          id: fieldId,
          name: rawLabel,
          label: rawLabel,
          normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
          type: 'radio',
          selector: `[data-gf-field-id="${fieldId}"]`,
          containerSelector: `[role="listitem"]:nth-of-type(${index + 1})`,
          options: radioOptions,
          contextText,
          mappedProperty: mapping?.targetProperty,
          mappedValue: mapping?.selectedOptionValue || mapping?.value,
          confidence: mapping ? mapping.confidence : 0,
          mappingReason: mapping?.reason,
          candidates: mapping?.candidates,
          selectedForFill: !!mapping && !!mapping.value,
          verificationStatus: 'pending',
          isGoogleForm: true,
          adapterType: 'google-forms',
        });

        // Attach a marker for easy DOM lookup during fill
        (container as HTMLElement).setAttribute('data-gf-field-id', fieldId);
        return;
      }

      // Check for Checkbox group
      const checkboxes = container.querySelectorAll('[role="checkbox"]');
      if (checkboxes.length > 0) {
        const checkboxOptions: FormOption[] = [];
        checkboxes.forEach((cb) => {
          const labelSpan =
            cb.querySelector('.aDTYNe, .docssharedWizToggleLabeledLabelText') ||
            cb.closest('label') ||
            cb.parentElement;
          const optLabel = (labelSpan?.textContent || cb.getAttribute('data-value') || '').trim();
          checkboxOptions.push({
            value: optLabel,
            label: optLabel,
            ariaChecked: cb.getAttribute('aria-checked') === 'true',
          });
        });

        const fieldId = `gf_cb_${index}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;
        const mapping = profile
          ? MappingEngine.mapField(
              {
                label: rawLabel,
                type: 'checkbox',
                contextText,
                options: checkboxOptions,
              },
              profile,
              learnedMappings,
              'docs.google.com'
            )
          : null;

        fields.push({
          id: fieldId,
          name: rawLabel,
          label: rawLabel,
          normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
          type: 'checkbox',
          selector: `[data-gf-field-id="${fieldId}"]`,
          options: checkboxOptions,
          contextText,
          mappedProperty: mapping?.targetProperty,
          mappedValue: mapping?.value,
          confidence: mapping ? mapping.confidence : 0,
          mappingReason: mapping?.reason,
          candidates: mapping?.candidates,
          selectedForFill: !!mapping && !!mapping.value,
          verificationStatus: 'pending',
          isGoogleForm: true,
          adapterType: 'google-forms',
        });

        (container as HTMLElement).setAttribute('data-gf-field-id', fieldId);
        return;
      }

      // Check for Text input or Textarea
      const textInput = container.querySelector(
        'input[type="text"], input[type="email"], input[type="date"], input[type="tel"], input[type="number"], input[type="url"], input.whsOnd, input[jsname]'
      ) as HTMLInputElement | null;

      const textArea = container.querySelector('textarea, textarea.KHxj8b') as HTMLTextAreaElement | null;

      if (textInput || textArea) {
        const inputEl = textInput || textArea!;
        const isArea = !!textArea;
        const fieldId = `gf_text_${index}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;

        const mapping = profile
          ? MappingEngine.mapField(
              {
                label: rawLabel,
                type: isArea ? 'textarea' : textInput?.type || 'text',
                contextText,
              },
              profile,
              learnedMappings,
              'docs.google.com'
            )
          : null;

        fields.push({
          id: fieldId,
          name: rawLabel,
          label: rawLabel,
          normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
          type: isArea ? 'textarea' : 'text',
          selector: `[data-gf-field-id="${fieldId}"] input, [data-gf-field-id="${fieldId}"] textarea`,
          currentValue: inputEl.value,
          contextText,
          mappedProperty: mapping?.targetProperty,
          mappedValue: mapping?.value,
          confidence: mapping ? mapping.confidence : 0,
          mappingReason: mapping?.reason,
          candidates: mapping?.candidates,
          selectedForFill: !!mapping && !!mapping.value,
          verificationStatus: 'pending',
          isGoogleForm: true,
          adapterType: 'google-forms',
        });

        (container as HTMLElement).setAttribute('data-gf-field-id', fieldId);
        return;
      }

      // Check for Dropdown (Listbox)
      const listbox = container.querySelector('[role="listbox"]');
      if (listbox) {
        const fieldId = `gf_list_${index}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;
        const mapping = profile
          ? MappingEngine.mapField(
              {
                label: rawLabel,
                type: 'select',
                contextText,
              },
              profile,
              learnedMappings,
              'docs.google.com'
            )
          : null;

        fields.push({
          id: fieldId,
          name: rawLabel,
          label: rawLabel,
          normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
          type: 'select',
          selector: `[data-gf-field-id="${fieldId}"] [role="listbox"]`,
          contextText,
          mappedProperty: mapping?.targetProperty,
          mappedValue: mapping?.value,
          confidence: mapping ? mapping.confidence : 0,
          mappingReason: mapping?.reason,
          candidates: mapping?.candidates,
          selectedForFill: !!mapping && !!mapping.value,
          verificationStatus: 'pending',
          isGoogleForm: true,
          adapterType: 'google-forms',
        });

        (container as HTMLElement).setAttribute('data-gf-field-id', fieldId);
      }
    });

    return fields;
  }

  /**
   * Fills a Google Form field and performs verification.
   * Dispatches genuine DOM interaction events (pointerdown, click, input, change).
   */
  public static async fillAndVerify(
    doc: Document,
    field: DetectedField,
    valueToFill: string
  ): Promise<FillResult> {
    const container = doc.querySelector(`[data-gf-field-id="${field.id}"]`);
    if (!container) {
      return {
        fieldId: field.id,
        success: false,
        expectedValue: valueToFill,
        actualValue: '',
        status: 'failed',
        error: 'Container element not found in DOM',
      };
    }

    // 1. RADIO GROUPS
    if (field.type === 'radio') {
      const radioEls = container.querySelectorAll('[role="radio"]');
      let targetRadio: HTMLElement | null = null;
      const normalizedTarget = MappingEngine.normalizeLabel(valueToFill);

      for (const rEl of Array.from(radioEls) as HTMLElement[]) {
        const labelSpan =
          rEl.querySelector('.aDTYNe, .docssharedWizToggleLabeledLabelText') ||
          rEl.closest('label') ||
          rEl.parentElement;
        const optText = MappingEngine.normalizeLabel(labelSpan?.textContent || rEl.getAttribute('data-value') || '');

        if (
          optText === normalizedTarget ||
          optText.includes(normalizedTarget) ||
          normalizedTarget.includes(optText)
        ) {
          targetRadio = rEl;
          break;
        }
      }

      if (!targetRadio) {
        return {
          fieldId: field.id,
          success: false,
          expectedValue: valueToFill,
          actualValue: '',
          status: 'mismatch',
          error: `No matching radio option found for "${valueToFill}"`,
        };
      }

      // Google Forms requires real pointer/mouse sequence to trigger internal Closure listeners
      this.dispatchGoogleClickEvents(targetRadio);

      // Allow microtask / event cycle to complete
      await new Promise((resolve) => setTimeout(resolve, 80));

      // Verify the aria-checked state
      const isAriaChecked = targetRadio.getAttribute('aria-checked') === 'true';
      if (isAriaChecked) {
        return {
          fieldId: field.id,
          success: true,
          expectedValue: valueToFill,
          actualValue: valueToFill,
          status: 'verified',
        };
      } else {
        // Retry with parent click
        const parentLabel = targetRadio.closest('label') || targetRadio.parentElement;
        if (parentLabel) {
          this.dispatchGoogleClickEvents(parentLabel as HTMLElement);
          await new Promise((resolve) => setTimeout(resolve, 80));
        }

        const retryChecked = targetRadio.getAttribute('aria-checked') === 'true';
        return {
          fieldId: field.id,
          success: retryChecked,
          expectedValue: valueToFill,
          actualValue: retryChecked ? valueToFill : 'unchecked',
          status: retryChecked ? 'verified' : 'failed',
          error: retryChecked ? undefined : 'Google Forms radio aria-checked did not toggle to true',
        };
      }
    }

    // 2. TEXT INPUTS & TEXTAREAS
    const inputEl = container.querySelector(
      'input[type="text"], input[type="email"], input[type="date"], input[type="tel"], input[type="number"], input[type="url"], input.whsOnd, input[jsname], textarea, textarea.KHxj8b'
    ) as HTMLInputElement | HTMLTextAreaElement | null;

    if (inputEl) {
      inputEl.focus();

      // Use native value setter to bypass React/Closure synthetic event shadowing
      const prototype = Object.getPrototypeOf(inputEl);
      const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
      if (prototypeValueSetter) {
        prototypeValueSetter.call(inputEl, valueToFill);
      } else {
        inputEl.value = valueToFill;
      }

      // Dispatch input, change, and blur events
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.blur();

      await new Promise((resolve) => setTimeout(resolve, 50));

      const actual = inputEl.value;
      const isMatch = actual === valueToFill;

      return {
        fieldId: field.id,
        success: isMatch,
        expectedValue: valueToFill,
        actualValue: actual,
        status: isMatch ? 'verified' : 'mismatch',
        error: isMatch ? undefined : `Value mismatch: expected "${valueToFill}", got "${actual}"`,
      };
    }

    return {
      fieldId: field.id,
      success: false,
      expectedValue: valueToFill,
      actualValue: '',
      status: 'failed',
      error: 'Unsupported control type or element not found',
    };
  }

  /**
   * Dispatches full mouse and pointer event cycle for Google Forms interactive components
   */
  private static dispatchGoogleClickEvents(el: HTMLElement): void {
    const eventOpts = { bubbles: true, cancelable: true };
    try {
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerdown', eventOpts));
      }
    } catch (_) {
      el.dispatchEvent(new MouseEvent('pointerdown', eventOpts));
    }

    el.dispatchEvent(new MouseEvent('mousedown', eventOpts));

    try {
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerup', eventOpts));
      }
    } catch (_) {
      el.dispatchEvent(new MouseEvent('pointerup', eventOpts));
    }

    el.dispatchEvent(new MouseEvent('mouseup', eventOpts));
    el.dispatchEvent(new MouseEvent('click', eventOpts));
  }
}
