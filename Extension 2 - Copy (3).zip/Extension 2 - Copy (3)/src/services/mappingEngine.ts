import { UserProfile } from '../types/profile';
import { DetectedField, FormOption, MappingCandidate } from '../types/form';
import { LearnedMapping } from '../types/learning';

export interface MappingResult {
  targetProperty: string;
  value: string;
  confidence: number;
  reason: string;
  selectedOptionValue?: string; // For radio or select options
  candidates?: MappingCandidate[]; // Multiple matching saved options for disambiguation
}

export class MappingEngine {
  /**
   * Normalizes label string for consistent, noise-free matching.
   */
  public static normalizeLabel(label: string): string {
    if (!label) return '';
    return label
      .toLowerCase()
      .replace(/[\*\:\?\!\#\(\)\[\]\{\}\_\-\/\\]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Retrieves value from UserProfile by property path (e.g. 'personal.fullName', 'class10.percentage', 'custom.cf_123', 'experiences.0.company')
   */
  public static getValueByPath(profile: UserProfile, path: string): string {
    if (!profile || !path) return '';

    // Handle custom profile fields, e.g. "custom.cf_123" or "customFields.cf_123"
    if (path.startsWith('custom.') || path.startsWith('customFields.')) {
      const fieldId = path.split('.')[1];
      const customField = profile.customFields?.find(
        (cf) => cf.id === fieldId || cf.title.toLowerCase() === fieldId.toLowerCase()
      );
      return customField ? customField.value : '';
    }

    const parts = path.split('.');
    let current: any = profile;

    for (const part of parts) {
      if (current === undefined || current === null) return '';
      current = current[part];
    }

    if (Array.isArray(current)) {
      return current.join(', ');
    }
    if (typeof current === 'string') return current;
    if (typeof current === 'number') return String(current);
    return '';
  }

  /**
   * Resolves a field mapping using learned rules, custom profile fields, context heuristics, and profile data.
   */
  public static mapField(
    field: {
      label: string;
      name?: string;
      type: string;
      contextText?: string;
      options?: FormOption[];
    },
    profile: UserProfile,
    learnedMappings: LearnedMapping[] = [],
    currentDomain?: string
  ): MappingResult | null {
    const rawLabel = (field.label || field.name || '').trim();
    const normalized = this.normalizeLabel(rawLabel);
    const context = (field.contextText ? this.normalizeLabel(field.contextText) : '') + ' ' + normalized;

    // 1. Check user-learned mappings first (highest priority)
    if (learnedMappings && learnedMappings.length > 0) {
      for (const rule of learnedMappings) {
        if (rule.domainScope && currentDomain && !currentDomain.includes(rule.domainScope)) {
          continue;
        }
        const rulePattern = rule.normalizedPattern || this.normalizeLabel(rule.fieldLabel || '');
        if (
          rulePattern &&
          (rulePattern === normalized ||
            normalized.includes(rulePattern) ||
            (rule.fieldPath && field.name && rule.fieldPath === field.name))
        ) {
          const val = this.getValueByPath(profile, rule.targetProperty);
          return {
            targetProperty: rule.targetProperty,
            value: val,
            confidence: rule.confidence || 1.0,
            reason: `Learned user mapping rule ("${rule.fieldLabel}")`,
          };
        }
      }
    }

    // Helper to evaluate user's custom profile fields
    const findCustomFieldMatch = (strictOnly: boolean): MappingResult | null => {
      if (!profile.customFields || profile.customFields.length === 0) return null;

      for (const cf of profile.customFields) {
        if (!cf.title || !cf.value) continue;
        const normTitle = this.normalizeLabel(cf.title);
        if (!normTitle) continue;

        const aliases = (cf.aliases || []).map((a) => this.normalizeLabel(a)).filter(Boolean);

        // Exact title match
        if (normTitle === normalized) {
          return {
            targetProperty: `custom.${cf.id}`,
            value: cf.value,
            confidence: 0.96,
            reason: `Exact match for custom profile field: "${cf.title}"`,
          };
        }

        // Exact alias match
        if (aliases.includes(normalized)) {
          return {
            targetProperty: `custom.${cf.id}`,
            value: cf.value,
            confidence: 0.95,
            reason: `Alias match for custom profile field: "${cf.title}"`,
          };
        }

        if (!strictOnly) {
          const titleTokens = normTitle.split(' ').filter((t) => t.length > 2);

          // Full title contained in form label with significant length
          if (normTitle.length >= 4 && (normalized.includes(normTitle) || context.includes(normTitle))) {
            return {
              targetProperty: `custom.${cf.id}`,
              value: cf.value,
              confidence: 0.92,
              reason: `Context matched custom profile field: "${cf.title}"`,
            };
          }

          // All title keywords present in form label
          if (
            titleTokens.length >= 2 &&
            titleTokens.every((token) => normalized.includes(token) || context.includes(token))
          ) {
            return {
              targetProperty: `custom.${cf.id}`,
              value: cf.value,
              confidence: 0.90,
              reason: `Keywords matched custom profile field: "${cf.title}"`,
            };
          }

          // Check aliases against label
          for (const alias of aliases) {
            if (alias.length >= 4 && (normalized.includes(alias) || context.includes(alias))) {
              return {
                targetProperty: `custom.${cf.id}`,
                value: cf.value,
                confidence: 0.91,
                reason: `Alias context matched custom profile field: "${cf.title}"`,
              };
            }
          }
        }
      }
      return null;
    };

    // Check exact custom field match early
    const exactCustomMatch = findCustomFieldMatch(true);
    if (exactCustomMatch) {
      return exactCustomMatch;
    }

    // 2. Special requirement: 12th vs Diploma radio/dropdown question
    const has12thToken =
      /\b(12th|12|hsc|intermediate|inter)\b/i.test(normalized) ||
      (field.options && field.options.some((o) => /\b(12th|12|intermediate|hsc)\b/i.test(o.label || o.value)));
    const hasDiplomaToken =
      /\b(diploma|polytechnic)\b/i.test(normalized) ||
      (field.options && field.options.some((o) => /\b(diploma|polytechnic)\b/i.test(o.label || o.value)));

    if (
      (field.type === 'radio' || field.type === 'select' || field.type === 'custom') &&
      has12thToken &&
      hasDiplomaToken
    ) {
      const savedType = profile.class12?.qualificationType; // '12th' | 'Diploma'
      if (savedType === '12th' || savedType === 'Diploma') {
        let matchedOption: FormOption | undefined;
        if (field.options) {
          matchedOption = field.options.find((opt) => {
            const optText = (opt.label + ' ' + opt.value).toLowerCase();
            if (savedType === '12th') {
              return /\b(12th|12|intermediate|hsc|senior secondary|inter)\b/i.test(optText) && !optText.includes('diploma');
            } else {
              return /\b(diploma|polytechnic)\b/i.test(optText);
            }
          });
        }

        return {
          targetProperty: 'class12.qualificationType',
          value: savedType,
          selectedOptionValue: matchedOption ? matchedOption.value || matchedOption.label : savedType,
          confidence: 0.95,
          reason: `12th/Diploma qualification discriminator (saved: ${savedType})`,
        };
      } else {
        return null;
      }
    }

    // 3. Class 10 specific checks (Matric, SSC, Class X, 10th)
    const isClass10 =
      /\b(10th|tenth|class 10|class x|matric|matriculation|ssc|secondary school|high school)\b/i.test(context);

    if (isClass10) {
      if (/\b(percentage|percent|pct|\%|cgpa|gpa|marks|aggregate|score)\b/i.test(normalized)) {
        return {
          targetProperty: 'class10.percentage',
          value: profile.class10?.percentage || '',
          confidence: 0.95,
          reason: 'Class 10 percentage / CGPA / marks',
        };
      }
      if (/\b(year of passing|passing year|pass year|yop|passing|completion year|passed in)\b/i.test(normalized)) {
        return {
          targetProperty: 'class10.passingYear',
          value: profile.class10?.passingYear || '',
          confidence: 0.95,
          reason: 'Class 10 passing year',
        };
      }
      if (/\b(board|council)\b/i.test(normalized)) {
        return {
          targetProperty: 'class10.board',
          value: profile.class10?.board || '',
          confidence: 0.9,
          reason: 'Class 10 examination board',
        };
      }
      if (/\b(school|institution|institute)\b/i.test(normalized)) {
        return {
          targetProperty: 'class10.school',
          value: profile.class10?.school || '',
          confidence: 0.9,
          reason: 'Class 10 school',
        };
      }
    }

    // 4. Class 12 / Intermediate / Diploma specific checks
    const isClass12 =
      /\b(12th|twelfth|class 12|class xii|intermediate|inter|hsc|senior secondary|higher secondary|diploma|polytechnic)\b/i.test(
        context
      );

    if (isClass12 && !isClass10) {
      if (/\b(percentage|percent|pct|\%|cgpa|gpa|marks|aggregate|score)\b/i.test(normalized)) {
        return {
          targetProperty: 'class12.percentage',
          value: profile.class12?.percentage || '',
          confidence: 0.95,
          reason: 'Class 12 / Intermediate / Diploma percentage / marks',
        };
      }
      if (/\b(year of passing|passing year|pass year|yop|passing|completion year|passed in)\b/i.test(normalized)) {
        return {
          targetProperty: 'class12.passingYear',
          value: profile.class12?.passingYear || '',
          confidence: 0.95,
          reason: 'Class 12 / Intermediate / Diploma passing year',
        };
      }
      if (/\b(board|council|institution|institute|school|college)\b/i.test(normalized)) {
        return {
          targetProperty: 'class12.boardOrInstitution',
          value: profile.class12?.boardOrInstitution || '',
          confidence: 0.9,
          reason: 'Class 12 / Diploma board or institution',
        };
      }
      if (/\b(stream|branch|discipline|specialization)\b/i.test(normalized)) {
        return {
          targetProperty: 'class12.stream',
          value: profile.class12?.stream || '',
          confidence: 0.9,
          reason: 'Class 12 / Diploma stream',
        };
      }
    }

    // 5. Higher Education / Master's / Postgraduate specifics
    const isHigherEdu =
      /\b(post graduation|postgraduate|pg|master|masters|mtech|m tech|mba|mca|msc|m sc|phd|doctorate)\b/i.test(
        context
      ) &&
      !isClass10 &&
      !isClass12;

    if (isHigherEdu) {
      const topHigher = profile.higherEducation && profile.higherEducation.length > 0 ? profile.higherEducation[0] : null;

      if (/\b(degree|qualification|course|program)\b/i.test(normalized)) {
        return {
          targetProperty: 'higherEducation.0.qualification',
          value: topHigher?.qualification || '',
          confidence: 0.92,
          reason: 'Higher Education Qualification / Degree',
        };
      }
      if (/\b(college|university|institute|institution)\b/i.test(normalized)) {
        return {
          targetProperty: 'higherEducation.0.institution',
          value: topHigher?.institution || '',
          confidence: 0.9,
          reason: 'Higher Education Institution',
        };
      }
      if (/\b(specialization|branch|discipline|major)\b/i.test(normalized)) {
        return {
          targetProperty: 'higherEducation.0.specialization',
          value: topHigher?.specialization || '',
          confidence: 0.9,
          reason: 'Higher Education Specialization',
        };
      }
      if (/\b(cgpa|gpa|percentage|pointer|marks)\b/i.test(normalized)) {
        return {
          targetProperty: 'higherEducation.0.percentageOrCgpa',
          value: topHigher?.percentageOrCgpa || '',
          confidence: 0.92,
          reason: 'Higher Education CGPA / Percentage',
        };
      }
      if (/\b(year of passing|passing year|yop|graduation year)\b/i.test(normalized)) {
        return {
          targetProperty: 'higherEducation.0.passingYear',
          value: topHigher?.passingYear || '',
          confidence: 0.92,
          reason: 'Higher Education Passing Year',
        };
      }
    }

    // 6. PRN / Permanent Registration Number (Strict mapping)
    if (
      /\b(prn|permanent registration number|permanent reg no|registration number|reg no|university reg|enrollment no|enrollment number|roll no|roll number|hall ticket no|hall ticket number)\b/i.test(
        normalized
      ) &&
      !isClass10 &&
      !isClass12
    ) {
      return {
        targetProperty: 'btech.prn',
        value: profile.btech?.prn || '',
        confidence: 0.95,
        reason: 'PRN (Permanent Registration Number / Roll Number)',
      };
    }

    // 7. B.Tech / Undergraduate / Graduation specifics
    const isGraduationContext =
      /\b(btech|b tech|b e|be|bachelor|undergraduate|ug|graduation|college|degree|engineering)\b/i.test(context) &&
      !isClass10 &&
      !isClass12 &&
      !isHigherEdu;

    if (isGraduationContext) {
      if (/\b(cgpa|gpa|aggregate|cumulative gpa|percentage|pointer|marks)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.cgpa',
          value: profile.btech?.cgpa || '',
          confidence: 0.95,
          reason: 'B.Tech / Graduation CGPA or percentage',
        };
      }
      if (/\b(year of passing|passing year|expected graduation|yop|graduation year|passing|completion year)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.passingYear',
          value: profile.btech?.passingYear || '',
          confidence: 0.95,
          reason: 'B.Tech / Graduation passing year',
        };
      }
      if (/\b(branch|stream|discipline|department|major|field of study)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.branch',
          value: profile.btech?.branch || '',
          confidence: 0.9,
          reason: 'B.Tech branch / engineering discipline',
        };
      }
      if (/\b(college|university|institute|institution|campus)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.college',
          value: profile.btech?.college || '',
          confidence: 0.9,
          reason: 'B.Tech college or university',
        };
      }
      if (/\b(active backlogs|current backlogs|live backlogs|standing backlogs|backlogs count)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.activeBacklogs',
          value: profile.btech?.activeBacklogs || '0',
          confidence: 0.95,
          reason: 'Active backlogs count',
        };
      }
      if (/\b(dead backlogs|cleared backlogs|history of backlogs|past backlogs|total backlogs)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.deadBacklogs',
          value: profile.btech?.deadBacklogs || '0',
          confidence: 0.95,
          reason: 'Dead / cleared backlogs count',
        };
      }
      if (/\b(degree|course|program)\b/i.test(normalized)) {
        return {
          targetProperty: 'btech.degree',
          value: profile.btech?.degree || 'B.Tech',
          confidence: 0.92,
          reason: 'Undergraduate Degree title',
        };
      }
    }

    // 8. General CGPA / Passing Year fallback when NOT prefixed by Class 10 or 12 or Higher Edu
    if (/\b(cgpa|gpa|aggregate cgpa)\b/i.test(normalized) && !isClass10 && !isClass12 && !isHigherEdu) {
      return {
        targetProperty: 'btech.cgpa',
        value: profile.btech?.cgpa || '',
        confidence: 0.9,
        reason: 'Degree CGPA / Aggregate',
      };
    }

    if (
      /\b(year of passing|passing year|yop|expected graduation|graduation year)\b/i.test(normalized) &&
      !isClass10 &&
      !isClass12 &&
      !isHigherEdu
    ) {
      return {
        targetProperty: 'btech.passingYear',
        value: profile.btech?.passingYear || '',
        confidence: 0.9,
        reason: 'Graduation Year of Passing',
      };
    }

    // 9. Work Experience & Employment specifics
    const isCompanyAttribute = /\b(hierarchy|rank|level|tier|grade|size|revenue|turnover|address|location|city|country|state|pincode|zip|website|url|domain)\b/i.test(normalized);

    // Current Company
    if (
      !isCompanyAttribute &&
      !/\b(designation|job title|role)\b/i.test(normalized) &&
      /\b(current company|present company|current employer|present employer|current organization|present organization|current workplace|current firm)\b/i.test(
        normalized
      )
    ) {
      const exp = profile.experiences && profile.experiences.length > 0 ? profile.experiences[0] : null;
      return {
        targetProperty: 'experiences.0.company',
        value: exp?.company || '',
        confidence: 0.95,
        reason: 'Current Company / Employer',
      };
    }

    // Previous Company
    if (
      !isCompanyAttribute &&
      !/\b(designation|job title|role)\b/i.test(normalized) &&
      /\b(previous company|past company|previous employer|past employer|former company|former employer|last company)\b/i.test(
        normalized
      )
    ) {
      const exp = profile.experiences && profile.experiences.length > 1 ? profile.experiences[1] : profile.experiences?.[0] || null;
      return {
        targetProperty: profile.experiences && profile.experiences.length > 1 ? 'experiences.1.company' : 'experiences.0.company',
        value: exp?.company || '',
        confidence: 0.92,
        reason: 'Previous Company / Employer',
      };
    }

    // Generic Company / Organization (fallback)
    if (
      !isCompanyAttribute &&
      !/\b(designation|job title|role)\b/i.test(normalized) &&
      /\b(company|company name|employer|organization|organization name)\b/i.test(normalized) &&
      !normalized.includes('previous') &&
      !normalized.includes('last')
    ) {
      const exp = profile.experiences && profile.experiences.length > 0 ? profile.experiences[0] : null;
      const candidates: MappingCandidate[] = (profile.experiences || [])
        .map((e, idx) => ({ label: `${e.company} (${e.role || 'Role'})`, value: e.company, property: `experiences.${idx}.company` }))
        .filter((c) => !!c.value);

      return {
        targetProperty: 'experiences.0.company',
        value: exp?.company || '',
        confidence: 0.88,
        reason: 'Primary / Current Company',
        candidates: candidates.length > 1 ? candidates : undefined,
      };
    }

    // Job Title / Designation
    if (
      !/\b(hierarchy|rank|level|tier|grade)\b/i.test(normalized) &&
      /\b(current designation|designation|current job title|job title|current role|present role|position title|your role)\b/i.test(
        normalized
      )
    ) {
      const exp = profile.experiences && profile.experiences.length > 0 ? profile.experiences[0] : null;
      return {
        targetProperty: 'experiences.0.role',
        value: exp?.role || '',
        confidence: 0.92,
        reason: 'Current Designation / Job Title',
      };
    }

    // Internship Details
    if (/\b(internship details|describe your internship|previous internship|internship experience)\b/i.test(normalized)) {
      const internExp = profile.experiences?.find((e) => e.isInternship || /intern/i.test(e.role));
      const answer = internExp
        ? `${internExp.role} at ${internExp.company}${internExp.description ? ': ' + internExp.description : ''}`
        : profile.customAnswers?.find((q) => q.id === 'internship-experience')?.answer || '';
      return {
        targetProperty: 'customAnswers.internship-experience',
        value: answer,
        confidence: 0.9,
        reason: 'Internship Experience',
      };
    }

    // 10. Projects specifics
    if (/\b(project title|project name|name of project|title of project|key project title)\b/i.test(normalized)) {
      const proj = profile.projects && profile.projects.length > 0 ? profile.projects[0] : null;
      const candidates: MappingCandidate[] = (profile.projects || [])
        .map((p, idx) => ({ label: p.title, value: p.title, property: `projects.${idx}.title` }))
        .filter((c) => !!c.value);

      return {
        targetProperty: 'projects.0.title',
        value: proj?.title || '',
        confidence: 0.92,
        reason: 'Project Title',
        candidates: candidates.length > 1 ? candidates : undefined,
      };
    }

    if (/\b(project description|describe your project|key project description|project summary|about project)\b/i.test(normalized)) {
      const proj = profile.projects && profile.projects.length > 0 ? profile.projects[0] : null;
      return {
        targetProperty: 'projects.0.description',
        value: proj?.description || profile.customAnswers?.find((q) => q.id === 'describe-project')?.answer || '',
        confidence: 0.90,
        reason: 'Project Description',
      };
    }

    if (/\b(project tech|project technologies|tech stack used|tools used in project|technologies used in project)\b/i.test(normalized)) {
      const proj = profile.projects && profile.projects.length > 0 ? profile.projects[0] : null;
      return {
        targetProperty: 'projects.0.technologies',
        value: proj?.technologies || '',
        confidence: 0.90,
        reason: 'Project Technologies',
      };
    }

    if (/\b(project link|project url|project github|live demo|demo link|repository url)\b/i.test(normalized)) {
      const proj = profile.projects && profile.projects.length > 0 ? profile.projects[0] : null;
      return {
        targetProperty: 'projects.0.link',
        value: proj?.link || '',
        confidence: 0.90,
        reason: 'Project URL / Repository',
      };
    }

    // 11. Skills, Certifications & Achievements
    if (/\b(skills|technical skills|key skills|technologies|programming languages|core competencies|tools known)\b/i.test(normalized)) {
      const skillsStr = (profile.skills || []).join(', ');
      return {
        targetProperty: 'skills',
        value: skillsStr,
        confidence: 0.94,
        reason: 'Technical Skills & Languages',
      };
    }

    if (/\b(certifications|certificates|key certifications|professional certifications)\b/i.test(normalized)) {
      const certsStr = (profile.certifications || []).join(', ');
      return {
        targetProperty: 'certifications',
        value: certsStr,
        confidence: 0.92,
        reason: 'Certifications',
      };
    }

    if (/\b(achievements|key achievements|honors|awards|academic achievements)\b/i.test(normalized)) {
      const achsStr = (profile.achievements || []).join(', ');
      return {
        targetProperty: 'achievements',
        value: achsStr,
        confidence: 0.92,
        reason: 'Achievements & Awards',
      };
    }

    // 12. Career Objective / Summary
    if (
      /\b(career objective|objective|professional summary|summary|bio|about me|about yourself)\b/i.test(
        normalized
      )
    ) {
      return {
        targetProperty: 'personal.summary',
        value: profile.personal?.summary || '',
        confidence: 0.92,
        reason: 'Career Objective / Professional Summary',
      };
    }

    // 13. Personal Information mappings
    // WhatsApp Number (prioritize before generic phone)
    if (/\b(whatsapp|wa number|whatsapp number|wa contact)\b/i.test(normalized)) {
      return {
        targetProperty: 'personal.whatsappNumber',
        value: profile.personal?.whatsappNumber || profile.personal?.phoneNumber || '',
        confidence: 0.95,
        reason: 'WhatsApp contact number',
      };
    }

    // Phone / Mobile Number (support Mobile, Phone Number, Contact Number, etc.)
    if (/\b(phone|mobile|contact number|cell phone|telephone|tel no|mobile no|phone number|cell|contact no)\b/i.test(normalized)) {
      const primaryPhone = profile.personal?.phoneNumber || (profile.personal as any)?.phone || '';
      const waPhone = profile.personal?.whatsappNumber || '';

      const candidates: MappingCandidate[] = [];
      if (primaryPhone) candidates.push({ label: 'Primary Phone', value: primaryPhone, property: 'personal.phoneNumber' });
      if (waPhone && waPhone !== primaryPhone) candidates.push({ label: 'WhatsApp Number', value: waPhone, property: 'personal.whatsappNumber' });

      return {
        targetProperty: 'personal.phoneNumber',
        value: primaryPhone,
        confidence: 0.95,
        reason: 'Primary phone / mobile number',
        candidates: candidates.length > 1 ? candidates : undefined,
      };
    }

    // Email
    if (/\b(email|e mail|email address|mail id|electronic mail)\b/i.test(normalized) || field.type === 'email') {
      return {
        targetProperty: 'personal.email',
        value: profile.personal?.email || '',
        confidence: 0.98,
        reason: 'Email address',
      };
    }

    // First Name
    if (/\b(first name|given name|fname|forename)\b/i.test(normalized)) {
      const firstNameVal = profile.personal?.firstName || (profile.personal?.fullName ? profile.personal.fullName.split(' ')[0] : '');
      return {
        targetProperty: 'personal.firstName',
        value: firstNameVal,
        confidence: 0.95,
        reason: 'First / Given name',
      };
    }

    // Last Name
    if (/\b(last name|surname|family name|lname)\b/i.test(normalized)) {
      const lastNameVal = profile.personal?.lastName || (profile.personal?.fullName ? profile.personal.fullName.split(' ').slice(1).join(' ') : '');
      return {
        targetProperty: 'personal.lastName',
        value: lastNameVal,
        confidence: 0.95,
        reason: 'Last name / Surname',
      };
    }

    // Full Name
    if (
      /\b(full name|applicant name|candidate name|name of candidate|name of applicant|student name|complete name|your name)\b/i.test(
        normalized
      ) ||
      normalized === 'name'
    ) {
      return {
        targetProperty: 'personal.fullName',
        value: profile.personal?.fullName || '',
        confidence: 0.95,
        reason: 'Full candidate name',
      };
    }

    // Location / City / Address
    if (/\b(current location|current city|present address|city|location|residence|street address|address line 1|address line|address)\b/i.test(normalized)) {
      return {
        targetProperty: 'personal.currentLocation',
        value: profile.personal?.currentLocation || '',
        confidence: 0.88,
        reason: 'Current location / address',
      };
    }

    // Social Links
    if (/\b(linkedin|linkedin profile|linkedin url)\b/i.test(normalized)) {
      return {
        targetProperty: 'personal.linkedin',
        value: profile.personal?.linkedin || '',
        confidence: 0.95,
        reason: 'LinkedIn profile URL',
      };
    }

    if (/\b(github|github profile|git url|github url)\b/i.test(normalized)) {
      return {
        targetProperty: 'personal.github',
        value: profile.personal?.github || '',
        confidence: 0.95,
        reason: 'GitHub profile URL',
      };
    }

    if (/\b(portfolio|personal website|portfolio url|website url|personal site)\b/i.test(normalized)) {
      return {
        targetProperty: 'personal.portfolio',
        value: profile.personal?.portfolio || '',
        confidence: 0.9,
        reason: 'Portfolio website URL',
      };
    }

    // 14. Custom Application Questions (Why Hire, Strengths, Project, Internship)
    if (/\b(why should we hire you|why hire|why do you want to join|why are you a good fit)\b/i.test(normalized)) {
      const qa = profile.customAnswers?.find((q) => q.id === 'why-hire' || q.questionKeyword.includes('hire'));
      return {
        targetProperty: 'customAnswers.why-hire',
        value: qa?.answer || '',
        confidence: 0.9,
        reason: 'Behavioral answer: Why should we hire you',
      };
    }

    if (/\b(strengths|what are your strengths|key strengths|greatest strength)\b/i.test(normalized)) {
      const qa = profile.customAnswers?.find((q) => q.id === 'strengths' || q.questionKeyword.includes('strengths'));
      return {
        targetProperty: 'customAnswers.strengths',
        value: qa?.answer || '',
        confidence: 0.9,
        reason: 'Behavioral answer: Key strengths',
      };
    }

    // 15. Contextual matching against custom profile fields
    const contextualCustomMatch = findCustomFieldMatch(false);
    if (contextualCustomMatch) {
      return contextualCustomMatch;
    }

    return null;
  }
}
