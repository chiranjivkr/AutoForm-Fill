import { DetectedField, FormOption, FillResult, FormFieldType } from '../types/form';
import { UserProfile } from '../types/profile';
import { MappingEngine } from './mappingEngine';
import { GoogleFormsAdapter } from './googleFormsAdapter';
import { LearnedMapping } from '../types/learning';

export class FormDetector {
  /**
   * Scans document for all form fields, leveraging Google Forms adapter if on Google Forms,
   * otherwise using intelligent generic and recruitment portal heuristics.
   */
  public static detectAll(
    doc: Document = document,
    profile?: UserProfile,
    learnedMappings: LearnedMapping[] = []
  ): DetectedField[] {
    // Do not scan the extension's own popup or dashboard options page
    try {
      if (
        typeof window !== 'undefined' &&
        window.location &&
        (window.location.protocol === 'chrome-extension:' ||
          window.location.pathname.endsWith('options.html') ||
          window.location.pathname.endsWith('popup.html'))
      ) {
        return [];
      }
    } catch {
      // ignore
    }

    // If it's a Google Form, use the specialized Google Forms adapter first
    if (GoogleFormsAdapter.isGoogleForm(doc)) {
      const gfFields = GoogleFormsAdapter.detectFields(doc, profile, learnedMappings);
      if (gfFields && gfFields.length > 0) {
        return gfFields;
      }
      // If specialized Google Forms adapter found 0 fields, fall through to generic detection
    }

    const detected: DetectedField[] = [];
    const processedElements = new Set<Element>();
    const currentDomain = typeof window !== 'undefined' && window.location ? window.location.hostname : '';

    // 1. Scan standard interactive inputs, textareas, and selects
    const inputs = doc.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(
      'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="file"]):not([type="image"]), textarea, select'
    );

    // Group radio buttons by name or parent group
    const radioGroups = new Map<string, HTMLInputElement[]>();

    inputs.forEach((inputEl) => {
      if (processedElements.has(inputEl)) return;

      // Never scan FormPilot's own in-page UI widgets
      if (inputEl.closest('#formpilot-floating-root, .fp-panel, [data-formpilot-ui]')) {
        return;
      }

      // Ignore disabled or explicitly non-interactive elements
      if (inputEl.disabled || inputEl.getAttribute('aria-disabled') === 'true') {
        return;
      }

      // Ignore global search bars in headers / navigation bars
      if (
        inputEl.type === 'search' ||
        (inputEl.closest('header, nav, [role="search"], [role="banner"]') &&
          (inputEl.name === 'q' || inputEl.name === 'search' || inputEl.getAttribute('type') === 'search'))
      ) {
        return;
      }

      // Ignore CAPTCHA fields and honeypot traps
      const nameAttr = (inputEl.getAttribute('name') || '').toLowerCase();
      const idAttr = (inputEl.id || '').toLowerCase();
      if (
        nameAttr.includes('recaptcha') ||
        nameAttr.includes('h-captcha') ||
        nameAttr.includes('cf-turnstile') ||
        idAttr.includes('recaptcha') ||
        idAttr.includes('h-captcha')
      ) {
        return;
      }

      // Filter out invisible or hidden elements (except styled radio/checkbox controls)
      const style = window.getComputedStyle ? window.getComputedStyle(inputEl) : null;
      if (style && (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')) {
        if (inputEl.type !== 'radio' && inputEl.type !== 'checkbox') {
          return;
        }
      }
      if (inputEl.hasAttribute('hidden') && inputEl.type !== 'radio' && inputEl.type !== 'checkbox') {
        return;
      }

      if (inputEl.type === 'radio') {
        const groupName =
          inputEl.name ||
          inputEl.closest('[role="radiogroup"], fieldset')?.id ||
          inputEl.closest('.form-group, .radio-group, [role="radiogroup"], tr, .field')?.getAttribute('data-group') ||
          'radio_group_' + (inputEl.getAttribute('name') || 'unnamed');
        if (!radioGroups.has(groupName)) {
          radioGroups.set(groupName, []);
        }
        radioGroups.get(groupName)!.push(inputEl as HTMLInputElement);
        return;
      }

      const label = this.extractLabel(inputEl, doc);
      const fallbackName = this.humanizeIdentifier(inputEl.name || inputEl.id || inputEl.getAttribute('autocomplete') || '');
      const ariaLabel = inputEl.getAttribute('aria-label') || '';
      const fullLabel =
        label ||
        inputEl.placeholder ||
        fallbackName ||
        ariaLabel ||
        (inputEl.type === 'email'
          ? 'Email Address'
          : inputEl.type === 'tel'
          ? 'Phone Number'
          : inputEl.type === 'date'
          ? 'Date of Birth'
          : inputEl.type === 'checkbox'
          ? 'Checkbox option'
          : 'Input field');

      const fieldType = this.resolveFieldType(inputEl);
      const fieldId = this.generateFieldId(inputEl, fullLabel);

      let options: FormOption[] | undefined;
      if (inputEl instanceof HTMLSelectElement) {
        options = Array.from(inputEl.options).map((opt) => ({
          value: opt.value,
          label: opt.text.trim(),
        }));
      }

      const mapping = profile
        ? MappingEngine.mapField(
            {
              label: fullLabel,
              name: inputEl.name,
              type: fieldType,
              options,
            },
            profile,
            learnedMappings,
            currentDomain
          )
        : null;

      detected.push({
        id: fieldId,
        name: inputEl.name || fullLabel,
        label: fullLabel,
        normalizedLabel: MappingEngine.normalizeLabel(fullLabel),
        type: fieldType,
        selector: this.getElementSelector(inputEl),
        currentValue: inputEl.value,
        options,
        mappedProperty: mapping?.targetProperty,
        mappedValue: mapping?.selectedOptionValue || mapping?.value,
        confidence: mapping ? mapping.confidence : 0,
        mappingReason: mapping?.reason,
        candidates: mapping?.candidates,
        selectedForFill: !!mapping && !!mapping.value,
        verificationStatus: 'pending',
        isGoogleForm: false,
        adapterType: 'generic',
      });

      inputEl.setAttribute('data-formpilot-id', fieldId);
      processedElements.add(inputEl);
    });

    // 2. Process Radio Groups
    radioGroups.forEach((radios, groupName) => {
      if (radios.length === 0) return;
      const firstRadio = radios[0];
      const groupLabel = this.extractRadioGroupLabel(firstRadio, doc) || this.humanizeIdentifier(groupName) || groupName;
      const fieldId = `fp_radio_group_${groupName.replace(/\W/g, '')}`;

      const options: FormOption[] = radios.map((r) => {
        const optLabel = this.extractLabel(r, doc) || r.value;
        return {
          value: r.value,
          label: optLabel,
          ariaChecked: r.checked,
        };
      });

      const mapping = profile
        ? MappingEngine.mapField(
            {
              label: groupLabel,
              name: groupName,
              type: 'radio',
              options,
            },
            profile,
            learnedMappings,
            currentDomain
          )
        : null;

      detected.push({
        id: fieldId,
        name: groupName,
        label: groupLabel,
        normalizedLabel: MappingEngine.normalizeLabel(groupLabel),
        type: 'radio',
        selector: firstRadio.name ? `input[type="radio"][name="${firstRadio.name}"]` : `[data-formpilot-radio-group="${fieldId}"]`,
        options,
        mappedProperty: mapping?.targetProperty,
        mappedValue: mapping?.selectedOptionValue || mapping?.value,
        confidence: mapping ? mapping.confidence : 0,
        mappingReason: mapping?.reason,
        selectedForFill: !!mapping && !!mapping.value,
        verificationStatus: 'pending',
        isGoogleForm: false,
        adapterType: 'generic',
      });

      radios.forEach((r) => {
        r.setAttribute('data-formpilot-radio-group', fieldId);
        processedElements.add(r);
      });
    });

    return detected;
  }

  /**
   * Humanizes camelCase, snake_case, kebab-case, or prefix-tagged identifiers
   */
  public static humanizeIdentifier(str: string): string {
    if (!str) return '';
    let cleaned = str.replace(/^(txt|input|inp|field|val|id|form|ctl\d*)[_-]?/i, '');
    cleaned = cleaned.replace(/[_-]?(txt|input|inp|field|val|id|form)$/i, '');
    if (!cleaned) cleaned = str;
    return cleaned
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/[-_.]+/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase())
      .trim();
  }

  /**
   * Extracts label for an element using standard accessibility attributes,
   * associated <label>, table cell siblings, and surrounding text.
   */
  public static extractLabel(el: HTMLElement, doc: Document = document): string {
    // 0. Native HTML labels property on form controls
    if ((el as any).labels && (el as any).labels.length > 0) {
      const nativeLabel = (el as any).labels[0].textContent?.trim();
      if (nativeLabel && nativeLabel.length < 120) {
        return nativeLabel.replace(/[:*]+$/, '').trim();
      }
    }

    // 1. aria-label or aria-labelledby
    if (el.getAttribute('aria-label')) {
      return el.getAttribute('aria-label')!.trim();
    }
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const parts = labelledBy
        .split(/\s+/)
        .map((id) => doc.getElementById(id)?.textContent?.trim())
        .filter(Boolean);
      if (parts.length > 0) {
        return parts.join(' ').replace(/[:*]+$/, '').trim();
      }
    }

    // 2. Associated <label for="id">
    if (el.id) {
      const label = doc.querySelector(`label[for="${this.escapeCss(el.id)}"]`);
      if (label && label.textContent) {
        return label.textContent.replace(/[:*]+$/, '').trim();
      }
    }

    // 3. Parent <label>
    const parentLabel = el.closest('label');
    if (parentLabel) {
      const clone = parentLabel.cloneNode(true) as HTMLElement;
      clone.querySelectorAll('input, select, textarea').forEach((n) => n.remove());
      const txt = clone.textContent?.trim();
      if (txt) return txt.replace(/[:*]+$/, '').trim();
    }

    // 4. Common portal form layout: table row (SSC / Govt. forms)
    const tableCell = el.closest('td');
    if (tableCell) {
      if (tableCell.previousElementSibling) {
        const prevTxt = tableCell.previousElementSibling.textContent?.trim();
        if (prevTxt && prevTxt.length < 100) {
          return prevTxt.replace(/[:*]+$/, '').trim();
        }
      }
      const tr = tableCell.parentElement;
      if (tr && tr.parentElement) {
        const cellIndex = Array.from(tr.children).indexOf(tableCell);
        const th = tr.parentElement.querySelector(`th:nth-child(${cellIndex + 1})`);
        if (th && th.textContent?.trim() && th.textContent.trim().length < 100) {
          return th.textContent.trim().replace(/[:*]+$/, '').trim();
        }
      }
    }

    // 5. Preceding sibling label or span or div
    let prev = el.previousElementSibling;
    while (prev) {
      if (['LABEL', 'SPAN', 'DIV', 'P', 'H3', 'H4', 'H5', 'H6', 'STRONG', 'B'].includes(prev.tagName)) {
        const txt = prev.textContent?.trim();
        if (txt && txt.length > 0 && txt.length < 100) {
          return txt.replace(/[:*]+$/, '').trim();
        }
      }
      prev = prev.previousElementSibling;
    }

    // 6. Parent element's previous sibling (e.g. <div class="form-field"><label>Name</label><div class="input-wrap"><input /></div></div>)
    if (el.parentElement && el.parentElement !== doc.body) {
      let parentPrev = el.parentElement.previousElementSibling;
      while (parentPrev) {
        if (['LABEL', 'SPAN', 'DIV', 'P', 'H3', 'H4', 'H5', 'H6', 'STRONG', 'B'].includes(parentPrev.tagName)) {
          const txt = parentPrev.textContent?.trim();
          if (txt && txt.length > 0 && txt.length < 100) {
            return txt.replace(/[:*]+$/, '').trim();
          }
        }
        parentPrev = parentPrev.previousElementSibling;
      }
    }

    // 7. Closest form group container label (Bootstrap / Tailwind / Workday / Ant Design layouts)
    const formGroup = el.closest(
      '.form-group, .form-row, .form-item, .form-field, .field, .input-container, .field-wrapper, .ant-form-item, .MuiFormControl-root, .chakra-form-control, [class*="form-group"], [class*="formGroup"], [class*="form-item"], [class*="FormField"], [class*="formField"], [class*="inputWrapper"], .grid, tr, [role="group"]'
    );
    if (formGroup) {
      const grpLabel = formGroup.querySelector(
        'label, [class*="label"], [class*="Label"], legend, strong, b, [role="heading"]'
      );
      if (grpLabel && grpLabel.textContent) {
        const txt = grpLabel.textContent.trim();
        if (txt && txt.length < 120) {
          return txt.replace(/[:*]+$/, '').trim();
        }
      }
    }

    // 8. Fallback to placeholder, title, or autocomplete
    const placeholder = el.getAttribute('placeholder');
    if (placeholder && placeholder.trim()) return placeholder.trim();

    const title = el.getAttribute('title');
    if (title && title.trim()) return title.trim();

    const ariaPlaceholder = el.getAttribute('aria-placeholder') || el.getAttribute('data-placeholder');
    if (ariaPlaceholder && ariaPlaceholder.trim()) return ariaPlaceholder.trim();

    return '';
  }

  /**
   * Discovers label for a group of radio buttons.
   */
  private static extractRadioGroupLabel(firstRadio: HTMLInputElement, doc: Document): string {
    const fieldset = firstRadio.closest('fieldset');
    if (fieldset) {
      const legend = fieldset.querySelector('legend');
      if (legend && legend.textContent) {
        return legend.textContent.trim();
      }
    }

    const formGroup = firstRadio.closest(
      '.form-group, .radio-group, [role="radiogroup"], tr, .field, .form-row, .form-item, [class*="radio"]'
    );
    if (formGroup) {
      const label = formGroup.querySelector('label, [class*="label"], [class*="Label"], td:first-child, legend, strong, b');
      if (label && label.textContent) {
        return label.textContent.trim();
      }
    }

    return firstRadio.name || '';
  }

  /**
   * Determines field type
   */
  private static resolveFieldType(el: HTMLElement): FormFieldType {
    if (el instanceof HTMLTextAreaElement) return 'textarea';
    if (el instanceof HTMLSelectElement) return 'select';
    if (el instanceof HTMLInputElement) {
      switch (el.type) {
        case 'email':
          return 'email';
        case 'tel':
          return 'tel';
        case 'number':
          return 'number';
        case 'date':
          return 'date';
        case 'radio':
          return 'radio';
        case 'checkbox':
          return 'checkbox';
        default:
          return 'text';
      }
    }
    return 'custom';
  }

  /**
   * Generates a stable unique ID for detected fields.
   */
  private static generateFieldId(el: HTMLElement, label: string): string {
    if (el.id) return `fp_${el.id}`;
    if (el.getAttribute('name')) return `fp_${el.getAttribute('name')}`;
    const cleanLabel = label.replace(/\W/g, '').substring(0, 20);
    return `fp_${cleanLabel}_${Math.random().toString(36).substr(2, 6)}`;
  }

  /**
   * Safe CSS escaping helper that works across browsers and jsdom test environments
   */
  public static escapeCss(str: string): string {
    if (typeof CSS !== 'undefined' && CSS && typeof CSS.escape === 'function') {
      return CSS.escape(str);
    }
    return str.replace(/([!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~])/g, '\\$1');
  }

  /**
   * Generates a unique CSS selector for an element.
   */
  private static getElementSelector(el: HTMLElement): string {
    if (el.id) return `#${this.escapeCss(el.id)}`;
    if (el.getAttribute('data-formpilot-id')) return `[data-formpilot-id="${el.getAttribute('data-formpilot-id')}"]`;
    if (el.getAttribute('name')) return `[name="${this.escapeCss(el.getAttribute('name')!)}"]`;
    return el.tagName.toLowerCase();
  }

  /**
   * Fills and verifies a standard form field.
   */
  public static async fillAndVerify(
    doc: Document,
    field: DetectedField,
    valueToFill: string
  ): Promise<FillResult> {
    if (field.isGoogleForm) {
      return GoogleFormsAdapter.fillAndVerify(doc, field, valueToFill);
    }

    // 1. Radio Group handling
    if (field.type === 'radio') {
      const radios = doc.querySelectorAll<HTMLInputElement>(
        `input[type="radio"][data-formpilot-radio-group="${field.id}"], input[type="radio"][name="${field.name}"]`
      );

      let targetRadio: HTMLInputElement | null = null;
      const normalizedTarget = MappingEngine.normalizeLabel(valueToFill);

      for (const r of Array.from(radios)) {
        const optLabel = MappingEngine.normalizeLabel(this.extractLabel(r, doc) || r.value);
        if (optLabel === normalizedTarget || optLabel.includes(normalizedTarget) || normalizedTarget.includes(optLabel)) {
          targetRadio = r;
          break;
        }
      }

      if (!targetRadio) {
        return {
          fieldId: field.id,
          success: false,
          expectedValue: valueToFill,
          actualValue: '',
          status: 'mismatch',
          error: `Radio option "${valueToFill}" not found`,
        };
      }

      targetRadio.checked = true;
      targetRadio.dispatchEvent(new Event('change', { bubbles: true }));
      targetRadio.dispatchEvent(new Event('input', { bubbles: true }));
      targetRadio.click();

      await new Promise((r) => setTimeout(r, 50));

      const isChecked = targetRadio.checked;
      return {
        fieldId: field.id,
        success: isChecked,
        expectedValue: valueToFill,
        actualValue: targetRadio.value,
        status: isChecked ? 'verified' : 'failed',
      };
    }

    // 2. Select Dropdown handling
    const selectEl = doc.querySelector<HTMLSelectElement>(
      `[data-formpilot-id="${field.id}"], ${field.selector}`
    );

    if (selectEl instanceof HTMLSelectElement) {
      const normalizedTarget = MappingEngine.normalizeLabel(valueToFill);
      let matchedIndex = -1;

      for (let i = 0; i < selectEl.options.length; i++) {
        const opt = selectEl.options[i];
        const optLabel = MappingEngine.normalizeLabel(opt.text);
        const optVal = MappingEngine.normalizeLabel(opt.value);

        if (optLabel === normalizedTarget || optVal === normalizedTarget || optLabel.includes(normalizedTarget)) {
          matchedIndex = i;
          break;
        }
      }

      if (matchedIndex >= 0) {
        selectEl.selectedIndex = matchedIndex;
        selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        selectEl.dispatchEvent(new Event('input', { bubbles: true }));
        await new Promise((r) => setTimeout(r, 50));

        return {
          fieldId: field.id,
          success: true,
          expectedValue: valueToFill,
          actualValue: selectEl.options[matchedIndex].text,
          status: 'verified',
        };
      } else {
        return {
          fieldId: field.id,
          success: false,
          expectedValue: valueToFill,
          actualValue: selectEl.value,
          status: 'mismatch',
          error: `Option "${valueToFill}" not in dropdown list`,
        };
      }
    }

    // 3. Checkbox handling
    if (field.type === 'checkbox') {
      const checkboxEl = doc.querySelector<HTMLInputElement>(
        `[data-formpilot-id="${field.id}"], ${field.selector}`
      );
      if (checkboxEl instanceof HTMLInputElement) {
        const lowerVal = (valueToFill || '').trim().toLowerCase();
        const shouldCheck = ['true', 'yes', '1', 'on', 'checked', 'agree'].includes(lowerVal) ||
          lowerVal === (checkboxEl.value || '').toLowerCase() ||
          lowerVal === (field.label || '').toLowerCase();

        checkboxEl.checked = shouldCheck;
        checkboxEl.dispatchEvent(new Event('change', { bubbles: true }));
        checkboxEl.dispatchEvent(new Event('input', { bubbles: true }));
        await new Promise((r) => setTimeout(r, 50));

        return {
          fieldId: field.id,
          success: true,
          expectedValue: valueToFill,
          actualValue: checkboxEl.checked ? 'checked' : 'unchecked',
          status: 'verified',
        };
      }
    }

    // 4. Text, Email, Tel, Number, Textarea inputs
    const inputEl = doc.querySelector<HTMLInputElement | HTMLTextAreaElement>(
      `[data-formpilot-id="${field.id}"], ${field.selector}`
    );

    if (inputEl) {
      inputEl.focus();

      // Native setter for React/Vue synthetic events
      const proto = Object.getPrototypeOf(inputEl);
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (nativeSetter) {
        nativeSetter.call(inputEl, valueToFill);
      } else {
        inputEl.value = valueToFill;
      }

      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.blur();

      await new Promise((r) => setTimeout(r, 50));

      const actual = inputEl.value;
      const isMatch = actual === valueToFill;

      return {
        fieldId: field.id,
        success: isMatch,
        expectedValue: valueToFill,
        actualValue: actual,
        status: isMatch ? 'verified' : 'mismatch',
        error: isMatch ? undefined : `Expected "${valueToFill}", got "${actual}"`,
      };
    }

    return {
      fieldId: field.id,
      success: false,
      expectedValue: valueToFill,
      actualValue: '',
      status: 'failed',
      error: 'Element not found in DOM for filling',
    };
  }
}
