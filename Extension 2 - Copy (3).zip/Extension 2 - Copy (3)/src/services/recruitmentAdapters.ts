import { DetectedField } from '../types/form';
import { UserProfile } from '../types/profile';
import { MappingEngine } from './mappingEngine';
import { LearnedMapping } from '../types/learning';

export interface PortalDetector {
  id: string;
  name: string;
  canHandle(url: string, doc: Document): boolean;
  detect(doc: Document, profile?: UserProfile, learnedMappings?: LearnedMapping[]): DetectedField[];
}

export class SscGovAdapter implements PortalDetector {
  public id = 'ssc-gov';
  public name = 'Staff Selection Commission / Govt. Portals';

  public canHandle(url: string, doc: Document): boolean {
    return (
      url.includes('ssc.nic.in') ||
      url.includes('ssc.gov.in') ||
      url.includes('upsc.gov.in') ||
      url.includes('gate.') ||
      doc.title.toLowerCase().includes('staff selection') ||
      doc.title.toLowerCase().includes('recruitment portal')
    );
  }

  public detect(doc: Document, profile?: UserProfile, learnedMappings: LearnedMapping[] = []): DetectedField[] {
    const fields: DetectedField[] = [];
    const rows = doc.querySelectorAll('tr');

    rows.forEach((row, rowIndex) => {
      const cells = row.querySelectorAll('td, th');
      if (cells.length < 2) return;

      const labelCell = cells[0];
      const inputCell = cells[1];

      const rawLabel = (labelCell.textContent || '').replace(/[*:]+/g, '').trim();
      const input = inputCell.querySelector<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>(
        'input:not([type="hidden"]):not([type="submit"]), select, textarea'
      );

      if (!input || !rawLabel) return;

      // Notice: strictly respect CAPTCHA security - never attempt to autofill or bypass captcha!
      if (
        /captcha|security code|enter code shown/i.test(rawLabel) ||
        input.name?.toLowerCase().includes('captcha')
      ) {
        return;
      }

      const fieldType = input instanceof HTMLSelectElement ? 'select' : input instanceof HTMLTextAreaElement ? 'textarea' : 'text';
      const mapping = profile
        ? MappingEngine.mapField(
            {
              label: rawLabel,
              name: input.name,
              type: fieldType,
            },
            profile,
            learnedMappings,
            window.location.hostname
          )
        : null;

      const fieldId = `ssc_${rowIndex}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;
      input.setAttribute('data-formpilot-id', fieldId);

      fields.push({
        id: fieldId,
        name: input.name || rawLabel,
        label: rawLabel,
        normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
        type: fieldType,
        selector: `[data-formpilot-id="${fieldId}"]`,
        currentValue: input.value,
        mappedProperty: mapping?.targetProperty,
        mappedValue: mapping?.value,
        confidence: mapping ? mapping.confidence : 0,
        mappingReason: mapping?.reason,
        selectedForFill: !!mapping && !!mapping.value,
        verificationStatus: 'pending',
        adapterType: 'ssc-gov',
      });
    });

    return fields;
  }
}

export class JobPortalsAdapter implements PortalDetector {
  public id = 'job-portal';
  public name = 'Workday / Greenhouse / Lever / Job Boards';

  public canHandle(url: string, doc: Document): boolean {
    return (
      url.includes('greenhouse.io') ||
      url.includes('lever.co') ||
      url.includes('myworkdayjobs.com') ||
      url.includes('ashbyhq.com') ||
      doc.querySelector('[data-automation-id]') !== null
    );
  }

  public detect(doc: Document, profile?: UserProfile, learnedMappings: LearnedMapping[] = []): DetectedField[] {
    const fields: DetectedField[] = [];
    const formGroups = doc.querySelectorAll(
      '.field, .application-field, [data-automation-id*="formField"], .form-item, [class*="formGroup"]'
    );

    formGroups.forEach((group, index) => {
      const labelEl = group.querySelector('label, [data-automation-id*="label"]');
      const inputEl = group.querySelector<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(
        'input:not([type="hidden"]), textarea, select'
      );

      if (!inputEl) return;
      const rawLabel = (labelEl?.textContent || inputEl.placeholder || inputEl.name || '').trim();
      if (!rawLabel) return;

      const fieldType = inputEl instanceof HTMLSelectElement ? 'select' : inputEl instanceof HTMLTextAreaElement ? 'textarea' : 'text';
      const mapping = profile
        ? MappingEngine.mapField(
            {
              label: rawLabel,
              name: inputEl.name,
              type: fieldType,
            },
            profile,
            learnedMappings,
            window.location.hostname
          )
        : null;

      const fieldId = `job_${index}_${rawLabel.substring(0, 15).replace(/\W/g, '')}`;
      inputEl.setAttribute('data-formpilot-id', fieldId);

      fields.push({
        id: fieldId,
        name: inputEl.name || rawLabel,
        label: rawLabel,
        normalizedLabel: MappingEngine.normalizeLabel(rawLabel),
        type: fieldType,
        selector: `[data-formpilot-id="${fieldId}"]`,
        currentValue: inputEl.value,
        mappedProperty: mapping?.targetProperty,
        mappedValue: mapping?.value,
        confidence: mapping ? mapping.confidence : 0,
        mappingReason: mapping?.reason,
        selectedForFill: !!mapping && !!mapping.value,
        verificationStatus: 'pending',
        adapterType: 'job-portal',
      });
    });

    return fields;
  }
}
