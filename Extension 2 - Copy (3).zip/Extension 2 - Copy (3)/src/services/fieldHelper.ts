import { FieldHelpResult } from '../types/ai';
import { MappingEngine } from './mappingEngine';

export class FieldHelperService {
  /**
   * Explains a form field in 1-2 simple, clear sentences.
   * Uses rule-based dictionary for all known fields, and optional configured AI for unknown labels.
   * Never suggests saved profile values or fills fields.
   */
  public static getExplanation(rawLabel: string, context?: string): FieldHelpResult {
    const normalized = MappingEngine.normalizeLabel(rawLabel);
    const combined = (context ? MappingEngine.normalizeLabel(context) : '') + ' ' + normalized;

    // 1. Class 10 Specific
    if (/\b(10th|tenth|class 10|class x|matric|ssc)\b/i.test(combined)) {
      if (/\b(percentage|percent|marks|aggregate|cgpa|score)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the percentage you scored in your Class 10 board exams.',
          source: 'rule-based',
          recommendedFormat: 'e.g. 88.5%',
        };
      }
      if (/\b(year|passing year|yop)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the calendar year in which you completed your Class 10 board examinations.',
          source: 'rule-based',
          recommendedFormat: 'YYYY (e.g. 2018)',
        };
      }
      if (/\b(board|council)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the education board that conducted your Class 10 exams (e.g., CBSE, ICSE, or State Board).',
          source: 'rule-based',
        };
      }
      if (/\b(school|institution)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the official name of the high school where you completed Class 10.',
          source: 'rule-based',
        };
      }
    }

    // 2. Class 12 / Diploma Specific
    if (/\b(12th|twelfth|class 12|class xii|intermediate|hsc|senior secondary|diploma)\b/i.test(combined)) {
      if (/\b(percentage|percent|marks|aggregate|cgpa|score)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter your final aggregate percentage or score obtained in Class 12 (Intermediate/HSC) or Diploma.',
          source: 'rule-based',
          recommendedFormat: 'e.g. 91.2%',
        };
      }
      if (/\b(year|passing year|yop)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the year you passed your 12th standard (HSC) or completed your Diploma course.',
          source: 'rule-based',
          recommendedFormat: 'YYYY (e.g. 2020)',
        };
      }
      if (/\b(stream|branch)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Specify your academic specialization in higher secondary, such as Science (PCM), Commerce, or Arts.',
          source: 'rule-based',
        };
      }
      if (/\b(qualification|type)\b/i.test(normalized) || /\b(12th|diploma)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Select whether you completed standard Higher Secondary (12th) or a Technical Polytechnic Diploma.',
          source: 'rule-based',
        };
      }
    }

    // 3. PRN / Permanent Registration Number
    if (/\b(prn|permanent registration number|reg no|enrollment no|roll no)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Enter the Permanent Registration Number provided by your college.',
        source: 'rule-based',
        recommendedFormat: 'Unique university or college identifier',
      };
    }

    // 4. B.Tech / Degree Specific
    if (/\b(btech|b tech|b e|be|graduation|undergraduate|degree)\b/i.test(combined) || /\b(cgpa|gpa)\b/i.test(normalized)) {
      if (/\b(cgpa|gpa|aggregate|cumulative)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter your B.Tech CGPA as shown on your college marksheet.',
          source: 'rule-based',
          recommendedFormat: 'e.g. 8.75 on a 10-point scale',
        };
      }
      if (/\b(year|passing year|yop|expected)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the actual or expected year of your undergraduate degree completion.',
          source: 'rule-based',
          recommendedFormat: 'YYYY (e.g. 2024)',
        };
      }
      if (/\b(branch|department|discipline|major)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter your engineering branch, such as Computer Science & Engineering or Information Technology.',
          source: 'rule-based',
        };
      }
      if (/\b(college|university|institute)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the full registered name of the university or college awarding your degree.',
          source: 'rule-based',
        };
      }
      if (/\b(active backlog|standing backlog|live backlog)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the number of subjects or courses currently uncleared/pending in your degree curriculum.',
          source: 'rule-based',
          recommendedFormat: '0 if none',
        };
      }
      if (/\b(dead backlog|cleared backlog|history of backlog)\b/i.test(normalized)) {
        return {
          fieldName: rawLabel,
          explanation: 'Enter the count of subjects that were previously failed but have now been successfully cleared.',
          source: 'rule-based',
          recommendedFormat: '0 if none',
        };
      }
    }

    // 5. Personal Information
    if (/\b(full name|applicant name|candidate name|name)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Enter your legal full name as recorded on official government and educational documents.',
        source: 'rule-based',
      };
    }

    if (/\b(whatsapp|wa number)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Enter your mobile number where recruiters or portals can contact you via WhatsApp.',
        source: 'rule-based',
      };
    }

    if (/\b(linkedin)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Paste your complete LinkedIn profile URL (e.g., https://linkedin.com/in/username).',
        source: 'rule-based',
      };
    }

    if (/\b(github)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Provide your GitHub profile URL where your coding repositories and public projects are hosted.',
        source: 'rule-based',
      };
    }

    if (/\b(portfolio|website)\b/i.test(normalized)) {
      return {
        fieldName: rawLabel,
        explanation: 'Provide your personal developer portfolio or personal website showcasing your work.',
        source: 'rule-based',
      };
    }

    // Generic fallback for any other field
    return {
      fieldName: rawLabel,
      explanation: `This field asks for "${rawLabel}". Review the application context and provide the requested details accurately.`,
      source: 'rule-based',
    };
  }
}
