import { describe, it, expect } from 'vitest';
import { MappingEngine } from '../services/mappingEngine';
import { UserProfile, defaultProfile } from '../types/profile';

describe('MappingEngine - Field Disambiguation & Rules', () => {
  const testProfile: UserProfile = {
    ...defaultProfile,
    personal: {
      ...defaultProfile.personal,
      fullName: 'Vikram Aditya Sharma',
      email: 'vikram.sharma@example.com',
      phoneNumber: '9876543210',
      whatsappNumber: '9123456789',
    },
    class10: {
      board: 'CBSE',
      school: 'St. Xavier School',
      passingYear: '2018',
      percentage: '88.4',
    },
    class12: {
      qualificationType: '12th',
      boardOrInstitution: 'CBSE',
      stream: 'Science (PCM)',
      passingYear: '2020',
      percentage: '93.2',
    },
    btech: {
      degree: 'B.Tech',
      branch: 'Computer Science and Engineering',
      college: 'National Institute of Technology',
      passingYear: '2024',
      cgpa: '8.75',
      activeBacklogs: '0',
      deadBacklogs: '0',
      prn: 'NITK2020CS104',
    },
  };

  // Scenario 1: Class 10 and Class 12 percentages map correctly
  it('Scenario 1: Class 10 and Class 12 percentages map correctly', () => {
    const result10 = MappingEngine.mapField(
      { label: 'Class 10 Percentage / CGPA', type: 'text' },
      testProfile
    );
    expect(result10?.targetProperty).toBe('class10.percentage');
    expect(result10?.value).toBe('88.4');

    const resultMatric = MappingEngine.mapField(
      { label: 'Matriculation Marks / Percentage', type: 'text' },
      testProfile
    );
    expect(resultMatric?.targetProperty).toBe('class10.percentage');
    expect(resultMatric?.value).toBe('88.4');

    const result12 = MappingEngine.mapField(
      { label: 'Class 12 Percentage', type: 'text' },
      testProfile
    );
    expect(result12?.targetProperty).toBe('class12.percentage');
    expect(result12?.value).toBe('93.2');

    const resultInter = MappingEngine.mapField(
      { label: 'Intermediate / HSC Aggregate Percentage', type: 'text' },
      testProfile
    );
    expect(resultInter?.targetProperty).toBe('class12.percentage');
    expect(resultInter?.value).toBe('93.2');

    // Verify they never map to each other
    expect(result10?.value).not.toBe(result12?.value);
  });

  // Scenario 2: Class 10 and Class 12 passing years remain separate
  it('Scenario 2: Class 10 and Class 12 passing years remain separate', () => {
    const res10Year = MappingEngine.mapField(
      { label: '10th Year of Passing', type: 'text' },
      testProfile
    );
    expect(res10Year?.targetProperty).toBe('class10.passingYear');
    expect(res10Year?.value).toBe('2018');

    const res12Year = MappingEngine.mapField(
      { label: '12th Passing Year / YOP', type: 'text' },
      testProfile
    );
    expect(res12Year?.targetProperty).toBe('class12.passingYear');
    expect(res12Year?.value).toBe('2020');

    const resDegreeYear = MappingEngine.mapField(
      { label: 'B.Tech Year of Passing', type: 'text' },
      testProfile
    );
    expect(resDegreeYear?.targetProperty).toBe('btech.passingYear');
    expect(resDegreeYear?.value).toBe('2024');

    expect(res10Year?.value).not.toBe(res12Year?.value);
    expect(res12Year?.value).not.toBe(resDegreeYear?.value);
  });

  // Scenario 3: Full Name maps to the correct saved name
  it('Scenario 3: Full Name maps to the correct saved name', () => {
    const labels = [
      'Full Name',
      'Applicant Name',
      'Candidate Name',
      'Name of Candidate',
      'Complete Name',
    ];

    for (const lbl of labels) {
      const res = MappingEngine.mapField({ label: lbl, type: 'text' }, testProfile);
      expect(res?.targetProperty).toBe('personal.fullName');
      expect(res?.value).toBe('Vikram Aditya Sharma');
    }
  });

  // Scenario 4: PRN maps to the correct saved identifier
  it('Scenario 4: PRN maps to the correct saved identifier', () => {
    const prnLabels = [
      'PRN',
      'Permanent Registration Number',
      'Registration Number',
      'University Reg No',
      'Enrollment Number',
    ];

    for (const lbl of prnLabels) {
      const res = MappingEngine.mapField({ label: lbl, type: 'text' }, testProfile);
      expect(res?.targetProperty).toBe('btech.prn');
      expect(res?.value).toBe('NITK2020CS104');
    }
  });

  // Scenario 5: A 12th profile selects the 12th radio option
  it('Scenario 5: A 12th profile selects the 12th radio option', () => {
    const radioField = {
      label: 'Highest Secondary Qualification (12th / Diploma)',
      type: 'radio',
      options: [
        { label: 'Class 12th (HSC)', value: '12th' },
        { label: 'Diploma in Polytechnic', value: 'Diploma' },
      ],
    };

    const res = MappingEngine.mapField(radioField, testProfile);
    expect(res?.targetProperty).toBe('class12.qualificationType');
    expect(res?.value).toBe('12th');
    expect(res?.selectedOptionValue).toBe('12th');
  });

  // Scenario 6: A Diploma profile selects the Diploma option
  it('Scenario 6: A Diploma profile selects the Diploma option', () => {
    const diplomaProfile: UserProfile = {
      ...testProfile,
      class12: {
        ...testProfile.class12,
        qualificationType: 'Diploma',
      },
    };

    const radioField = {
      label: 'Please select 12th or Diploma',
      type: 'radio',
      options: [
        { label: '12th Standard', value: '12th' },
        { label: 'Diploma', value: 'Diploma' },
      ],
    };

    const res = MappingEngine.mapField(radioField, diplomaProfile);
    expect(res?.targetProperty).toBe('class12.qualificationType');
    expect(res?.value).toBe('Diploma');
    expect(res?.selectedOptionValue).toBe('Diploma');
  });

  // Scenario 7: Missing qualification data does not cause a guessed selection
  it('Scenario 7: Missing qualification data does not cause a guessed selection', () => {
    const ambiguousProfile: UserProfile = {
      ...testProfile,
      class12: {
        ...testProfile.class12,
        qualificationType: '' as any, // Missing / unselected
      },
    };

    const radioField = {
      label: 'Qualification (12th / Diploma)',
      type: 'radio',
      options: [
        { label: '12th', value: '12th' },
        { label: 'Diploma', value: 'Diploma' },
      ],
    };

    const res = MappingEngine.mapField(radioField, ambiguousProfile);
    // Must remain null / unanswered when qualification data is missing!
    expect(res).toBeNull();
  });

  // Scenario 8: Career summary, skills, experience, and project mappings
  it('Scenario 8: Maps career summary, skills, current vs previous company, and projects correctly', () => {
    const enrichedProfile: UserProfile = {
      ...testProfile,
      personal: {
        ...testProfile.personal,
        summary: 'Passionate software engineer with expertise in full-stack web applications and AI.',
        currentLocation: 'Pune, Maharashtra, India',
      },
      skills: ['TypeScript', 'React', 'Node.js', 'Python', 'AWS'],
      experiences: [
        {
          id: 'exp_1',
          company: 'Acme Technologies',
          role: 'Senior Software Engineer',
          startDate: 'Jan 2022',
          endDate: 'Present',
          isCurrent: true,
          isInternship: false,
          description: 'Architecting scalable cloud microservices.',
        },
        {
          id: 'exp_2',
          company: 'Legacy Corp',
          role: 'Junior Developer',
          startDate: 'Jun 2020',
          endDate: 'Dec 2021',
          isCurrent: false,
          isInternship: false,
          description: 'Maintained enterprise databases.',
        },
      ],
      projects: [
        {
          id: 'proj_1',
          title: 'FormPilot AI Assistant',
          technologies: 'React, TypeScript, Chrome Extensions API',
          role: 'Lead Developer',
          link: 'https://github.com/example/formpilot',
          description: 'Smart browser form filling system.',
        },
      ],
      certifications: ['AWS Certified Solutions Architect', 'CKA Kubernetes'],
      achievements: ['First Prize in National Hackathon 2023'],
    };

    // Summary / Objective
    const resSummary = MappingEngine.mapField(
      { label: 'Career Objective / Professional Summary', type: 'textarea' },
      enrichedProfile
    );
    expect(resSummary?.targetProperty).toBe('personal.summary');
    expect(resSummary?.value).toContain('Passionate software engineer');

    // Technical skills
    const resSkills = MappingEngine.mapField(
      { label: 'Technical Skills & Key Technologies', type: 'text' },
      enrichedProfile
    );
    expect(resSkills?.targetProperty).toBe('skills');
    expect(resSkills?.value).toContain('TypeScript');
    expect(resSkills?.value).toContain('React');

    // Current Company
    const resCurrentCo = MappingEngine.mapField(
      { label: 'Current Company / Employer Name', type: 'text' },
      enrichedProfile
    );
    expect(resCurrentCo?.targetProperty).toBe('experiences.0.company');
    expect(resCurrentCo?.value).toBe('Acme Technologies');

    // Previous Company
    const resPrevCo = MappingEngine.mapField(
      { label: 'Previous Employer / Past Company', type: 'text' },
      enrichedProfile
    );
    expect(resPrevCo?.targetProperty).toBe('experiences.1.company');
    expect(resPrevCo?.value).toBe('Legacy Corp');

    // Current Job Title / Designation
    const resRole = MappingEngine.mapField(
      { label: 'Current Designation / Position Title', type: 'text' },
      enrichedProfile
    );
    expect(resRole?.targetProperty).toBe('experiences.0.role');
    expect(resRole?.value).toBe('Senior Software Engineer');

    // Project Name
    const resProject = MappingEngine.mapField(
      { label: 'Key Project Title / Project Name', type: 'text' },
      enrichedProfile
    );
    expect(resProject?.targetProperty).toBe('projects.0.title');
    expect(resProject?.value).toBe('FormPilot AI Assistant');

    // Certifications
    const resCert = MappingEngine.mapField(
      { label: 'Licenses & Professional Certifications', type: 'text' },
      enrichedProfile
    );
    expect(resCert?.targetProperty).toBe('certifications');
    expect(resCert?.value).toContain('AWS Certified Solutions Architect');
  });

  // Scenario 9: Multi-candidate disambiguation for phone numbers
  it('Scenario 9: Provides candidates when multiple values exist (Phone vs WhatsApp)', () => {
    const resPhone = MappingEngine.mapField(
      { label: 'Contact Phone Number', type: 'tel' },
      testProfile
    );
    expect(resPhone?.targetProperty).toBe('personal.phoneNumber');
    expect(resPhone?.candidates).toBeDefined();
    expect(resPhone?.candidates?.length).toBe(2);
    expect(resPhone?.candidates?.[0].value).toBe('9876543210');
    expect(resPhone?.candidates?.[1].value).toBe('9123456789');
  });
});
