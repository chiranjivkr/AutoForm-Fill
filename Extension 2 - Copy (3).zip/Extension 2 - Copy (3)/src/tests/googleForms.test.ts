import { describe, it, expect, beforeEach } from 'vitest';
import { GoogleFormsAdapter } from '../services/googleFormsAdapter';
import { UserProfile, defaultProfile } from '../types/profile';

describe('Google Forms Integration & Verification', () => {
  let doc: Document;

  const testProfile: UserProfile = {
    ...defaultProfile,
    personal: {
      ...defaultProfile.personal,
      fullName: 'Aarav Patel',
    },
    class10: {
      board: 'CBSE',
      school: 'Modern Academy',
      passingYear: '2019',
      percentage: '92.5',
    },
    class12: {
      qualificationType: '12th',
      boardOrInstitution: 'CBSE',
      stream: 'Science',
      passingYear: '2021',
      percentage: '94.8',
    },
    btech: {
      degree: 'B.Tech',
      branch: 'Computer Science',
      college: 'Delhi Technological University',
      passingYear: '2025',
      cgpa: '8.9',
      activeBacklogs: '0',
      deadBacklogs: '0',
      prn: 'DTU2021CS091',
    },
  };

  beforeEach(() => {
    // Setup simulated Google Forms DOM
    document.body.innerHTML = `
      <form class="freebirdFormviewerViewFormContent">
        <!-- Q1: Full Name -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">Candidate Full Name *</div>
          <div>
            <input type="text" class="whsOnd" value="" />
          </div>
        </div>

        <!-- Q2: PRN -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">PRN / Registration Number</div>
          <div>
            <input type="text" class="whsOnd" value="" />
          </div>
        </div>

        <!-- Q3: 10th Percentage -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">10th Percentage</div>
          <div>
            <input type="text" class="whsOnd" value="" />
          </div>
        </div>

        <!-- Q4: 12th Percentage -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">12th Aggregate Percentage</div>
          <div>
            <input type="text" class="whsOnd" value="" />
          </div>
        </div>

        <!-- Q5: 12th vs Diploma Radio Group -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">Select Qualification (12th / Diploma) *</div>
          <div role="radiogroup">
            <div role="radio" aria-checked="false" data-value="12th">
              <span class="aDTYNe">12th</span>
            </div>
            <div role="radio" aria-checked="false" data-value="Diploma">
              <span class="aDTYNe">Diploma</span>
            </div>
          </div>
        </div>

        <!-- Q6: B.Tech CGPA -->
        <div role="listitem" class="geS5n">
          <div role="heading" class="M7eMe">B.Tech CGPA</div>
          <div>
            <input type="text" class="whsOnd" value="" />
          </div>
        </div>
      </form>
    `;

    doc = document;

    // Simulate Google Forms radio interaction event handler
    const radios = doc.querySelectorAll('[role="radio"]');
    radios.forEach((r) => {
      r.addEventListener('click', () => {
        radios.forEach((other) => other.setAttribute('aria-checked', 'false'));
        r.setAttribute('aria-checked', 'true');
      });
    });
  });

  // Scenario 8: Google Forms registers the selected radio option
  it('Scenario 8: Google Forms detects questions, fills, and verifies radio selection', async () => {
    const fields = GoogleFormsAdapter.detectFields(doc, testProfile);
    expect(fields.length).toBe(6);

    const radioField = fields.find((f) => f.type === 'radio');
    expect(radioField).toBeDefined();
    expect(radioField?.mappedProperty).toBe('class12.qualificationType');
    expect(radioField?.mappedValue).toBe('12th');

    // Perform fill and verify
    const result = await GoogleFormsAdapter.fillAndVerify(doc, radioField!, '12th');
    expect(result.success).toBe(true);
    expect(result.status).toBe('verified');

    // Confirm that DOM aria-checked was actually updated
    const selectedRadio = doc.querySelector('[role="radio"][data-value="12th"]');
    expect(selectedRadio?.getAttribute('aria-checked')).toBe('true');
  });

  it('Google Forms regression: Full Name, PRN, 10th %, 12th %, and CGPA fill correctly', async () => {
    const fields = GoogleFormsAdapter.detectFields(doc, testProfile);

    // Full Name
    const nameField = fields.find((f) => f.label.includes('Full Name'));
    expect(nameField?.mappedValue).toBe('Aarav Patel');
    const nameRes = await GoogleFormsAdapter.fillAndVerify(doc, nameField!, 'Aarav Patel');
    expect(nameRes.success).toBe(true);
    expect(nameRes.actualValue).toBe('Aarav Patel');

    // PRN
    const prnField = fields.find((f) => f.label.includes('PRN'));
    expect(prnField?.mappedValue).toBe('DTU2021CS091');
    const prnRes = await GoogleFormsAdapter.fillAndVerify(doc, prnField!, 'DTU2021CS091');
    expect(prnRes.success).toBe(true);

    // 10th % vs 12th %
    const f10 = fields.find((f) => f.label === '10th Percentage');
    const f12 = fields.find((f) => f.label === '12th Aggregate Percentage');
    expect(f10?.mappedValue).toBe('92.5');
    expect(f12?.mappedValue).toBe('94.8');
    expect(f10?.mappedValue).not.toBe(f12?.mappedValue);
  });
});
