import { describe, it, expect, beforeEach } from 'vitest';
import { FormDetector } from '../services/formDetector';
import { GoogleFormsAdapter } from '../services/googleFormsAdapter';
import { UserProfile, defaultProfile } from '../types/profile';

describe('FormPilot AI Form Field Detection Comprehensive Suite', () => {
  let doc: Document;

  const testProfile: UserProfile = {
    ...defaultProfile,
    personal: {
      ...defaultProfile.personal,
      fullName: 'Aarav Patel',
      email: 'aarav.patel@example.com',
      phoneNumber: '+91 9876543210',
    },
    class10: {
      board: 'CBSE',
      school: 'Modern Academy',
      passingYear: '2019',
      percentage: '92.5',
    },
  };

  beforeEach(() => {
    document.body.innerHTML = '';
    doc = document;
  });

  // 1. Simple HTML Form
  it('detects standard HTML form fields: text, email, select dropdown, and checkbox', async () => {
    doc.body.innerHTML = `
      <form id="contact-form">
        <label for="name-input">Full Name</label>
        <input id="name-input" type="text" name="fullName" />

        <label for="email-input">Email Address</label>
        <input id="email-input" type="email" name="user_email" />

        <label for="country-select">Country</label>
        <select id="country-select" name="country">
          <option value="">Select a country</option>
          <option value="IN">India</option>
          <option value="US">United States</option>
        </select>

        <label>
          <input type="checkbox" id="terms-agree" name="terms" value="agreed" />
          I agree to the terms and conditions
        </label>
      </form>
    `;

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(4);

    const nameField = fields.find((f) => f.label === 'Full Name');
    expect(nameField).toBeDefined();
    expect(nameField?.type).toBe('text');
    expect(nameField?.mappedValue).toBe('Aarav Patel');

    const emailField = fields.find((f) => f.label === 'Email Address');
    expect(emailField).toBeDefined();
    expect(emailField?.type).toBe('email');
    expect(emailField?.mappedValue).toBe('aarav.patel@example.com');

    const selectField = fields.find((f) => f.label === 'Country');
    expect(selectField).toBeDefined();
    expect(selectField?.type).toBe('select');
    expect(selectField?.options?.length).toBe(3);

    const checkboxField = fields.find((f) => f.label.includes('terms and conditions'));
    expect(checkboxField).toBeDefined();
    expect(checkboxField?.type).toBe('checkbox');

    // Test filling and verifying checkbox
    const chkRes = await FormDetector.fillAndVerify(doc, checkboxField!, 'true');
    expect(chkRes.success).toBe(true);
    expect((doc.getElementById('terms-agree') as HTMLInputElement).checked).toBe(true);
  });

  // 2. React / SPA dynamically structured form
  it('detects fields in React/SPA layouts without traditional for-labels using humanized IDs and form-groups', () => {
    doc.body.innerHTML = `
      <div class="chakra-form-control">
        <label class="chakra-form__label">Primary Phone Number</label>
        <div class="chakra-input__group">
          <input type="tel" id="candidate_phone_num" placeholder="+1 (555) 000-0000" />
        </div>
      </div>
      <div class="MuiFormControl-root">
        <div class="MuiInputBase-root">
          <input type="text" id="applicantFirstName" placeholder="Enter given name" />
        </div>
      </div>
      <div class="ant-form-item">
        <div class="ant-form-item-label">
          <label>10th Board of Education</label>
        </div>
        <div class="ant-form-item-control">
          <input type="text" name="class10_board" />
        </div>
      </div>
    `;

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(3);

    const phoneField = fields.find((f) => f.label.includes('Primary Phone Number'));
    expect(phoneField).toBeDefined();
    expect(phoneField?.mappedValue).toBe('+91 9876543210');

    const muiField = fields.find((f) => f.label === 'Enter given name' || f.label === 'Applicant First Name');
    expect(muiField).toBeDefined();

    const boardField = fields.find((f) => f.label.includes('10th Board of Education'));
    expect(boardField).toBeDefined();
    expect(boardField?.mappedValue).toBe('CBSE');
  });

  // 3. Table-based recruitment form layout (Govt./SSC/Enterprise portals)
  it('detects table cell label layouts and radio button groups correctly', async () => {
    doc.body.innerHTML = `
      <table class="portal-form-table">
        <tbody>
          <tr>
            <td class="field-label">Date of Birth:</td>
            <td><input type="date" name="dob" /></td>
          </tr>
          <tr>
            <td class="field-label">Gender:</td>
            <td>
              <div class="radio-group" data-group="gender_group">
                <label><input type="radio" name="gender" value="Male" /> Male</label>
                <label><input type="radio" name="gender" value="Female" /> Female</label>
                <label><input type="radio" name="gender" value="Other" /> Other</label>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    `;

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(2);

    const dobField = fields.find((f) => f.type === 'date');
    expect(dobField).toBeDefined();
    expect(dobField?.label).toBe('Date of Birth');

    const radioGroup = fields.find((f) => f.type === 'radio');
    expect(radioGroup).toBeDefined();
    expect(radioGroup?.options?.length).toBe(3);

    // Fill radio option
    const fillRadioRes = await FormDetector.fillAndVerify(doc, radioGroup!, 'Male');
    expect(fillRadioRes.success).toBe(true);
    const maleRadio = doc.querySelector('input[type="radio"][value="Male"]') as HTMLInputElement;
    expect(maleRadio.checked).toBe(true);
  });

  // 4. False-positive immunity: Normal sites with .m2 CSS class are NOT misidentified as Google Forms
  it('does NOT treat regular websites using utility class ".m2" as Google Forms', () => {
    doc.body.innerHTML = `
      <div class="m2 flex flex-col p-4">
        <label for="username">Username</label>
        <input id="username" type="text" name="username" />
        <label for="pass">Password</label>
        <input id="pass" type="password" name="password" />
      </div>
    `;

    expect(GoogleFormsAdapter.isGoogleForm(doc)).toBe(false);

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(2);
    expect(fields[0].label).toBe('Username');
    expect(fields[0].adapterType).toBe('generic');
  });

  // 5. Exclusions: Ignores FormPilot UI, hidden/disabled elements, honeypots, search bars
  it('ignores FormPilot floating widget, hidden inputs, disabled controls, search bars, and CAPTCHAs', () => {
    doc.body.innerHTML = `
      <!-- Legitimate form -->
      <form>
        <label for="user-bio">Personal Statement</label>
        <textarea id="user-bio" name="bio"></textarea>
      </form>

      <!-- Search bar in header (ignored) -->
      <header>
        <input type="search" name="q" placeholder="Search jobs..." />
      </header>

      <!-- Disabled input (ignored) -->
      <input type="text" disabled value="Read only" />

      <!-- Honeypot & CAPTCHA (ignored) -->
      <input type="text" name="g-recaptcha-response" />
      <input type="hidden" name="csrf_token" value="abc123" />

      <!-- FormPilot internal UI (ignored) -->
      <div id="formpilot-floating-root">
        <input type="text" id="fp-custom-title-123" value="Field Title" />
      </div>
    `;

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(1);
    expect(fields[0].label).toBe('Personal Statement');
    expect(fields[0].type).toBe('textarea');
  });

  // 6. Empty page / no form fields
  it('returns empty array when page contains no form fields', () => {
    doc.body.innerHTML = `
      <article>
        <h1>Welcome to our Company Careers Blog</h1>
        <p>Read about our company culture and open opportunities.</p>
      </article>
    `;

    const fields = FormDetector.detectAll(doc, testProfile);
    expect(fields.length).toBe(0);
  });
});
