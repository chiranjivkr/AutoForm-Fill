import { describe, it, expect } from 'vitest';
import { FieldHelperService } from '../services/fieldHelper';
import { AIAnswerGenerator } from '../services/aiAnswerGenerator';
import { defaultProfile, UserProfile } from '../types/profile';
import { AISettings } from '../types/ai';

describe('AI Field Helper & Answer Generator', () => {
  // Scenario 12: The AI Field Helper remains inactive until clicked
  it('Scenario 12: Field helper only produces explanation when requested', () => {
    // When queried for 10th percentage
    const help10 = FieldHelperService.getExplanation('10th Percentage');
    expect(help10.explanation).toBe('Enter the percentage you scored in your Class 10 board exams.');

    // When queried for PRN
    const helpPrn = FieldHelperService.getExplanation('Permanent Registration Number (PRN)');
    expect(helpPrn.explanation).toBe('Enter the Permanent Registration Number provided by your college.');

    // When queried for B.Tech CGPA
    const helpCgpa = FieldHelperService.getExplanation('B.Tech CGPA');
    expect(helpCgpa.explanation).toBe('Enter your B.Tech CGPA as shown on your college marksheet.');
  });

  // Scenario 13: The AI Field Helper never modifies form data
  it('Scenario 13: The AI Field Helper never modifies form inputs or profile data', () => {
    // Setup a DOM input element with an existing value
    const input = document.createElement('input');
    input.value = 'Existing Input Value';
    const originalValue = input.value;

    const profileClone = JSON.parse(JSON.stringify(defaultProfile));

    // Request field helper explanation
    const result = FieldHelperService.getExplanation('PRN');

    // Confirm that the explanation is strictly informative
    expect(result.explanation.length).toBeGreaterThan(10);
    // Confirm input DOM value was NOT changed
    expect(input.value).toBe(originalValue);
    // Confirm profile was NOT mutated
    expect(defaultProfile).toEqual(profileClone);
  });

  it('AI Answer Generator builds truthful answers grounded in profile data without fabrication', async () => {
    const profile: UserProfile = {
      ...defaultProfile,
      personal: {
        ...defaultProfile.personal,
        fullName: 'Kavita Raman',
      },
      btech: {
        degree: 'B.Tech',
        branch: 'Computer Science and Engineering',
        college: 'BITS Pilani',
        passingYear: '2024',
        cgpa: '9.1',
        activeBacklogs: '0',
        deadBacklogs: '0',
        prn: '2020BITS01',
      },
      skills: ['Python', 'FastAPI', 'PostgreSQL'],
      projects: [
        {
          id: 'p1',
          title: 'Distributed Log Parser',
          technologies: 'Python, FastAPI',
          link: '',
          description: 'Designed a high-throughput streaming log parser handling 10k events/sec',
        },
      ],
    };

    const settings: AISettings = {
      provider: 'rule-based',
      apiKey: '',
      enabled: true,
    };

    const res = await AIAnswerGenerator.generateAnswer(
      {
        question: 'Why should we hire you?',
        jobTitle: 'Backend Engineer',
        company: 'Stripe',
      },
      profile,
      settings
    );

    expect(res.answer).toContain('Computer Science and Engineering');
    expect(res.answer).toContain('BITS Pilani');
    expect(res.answer).toContain('Distributed Log Parser');
    expect(res.answer).toContain('Python');
    expect(res.isRuleBasedFallback).toBe(true);
  });
});
