import { describe, it, expect, beforeEach } from 'vitest';
import { ResumeParser } from '../services/resumeParser';
import { defaultProfile, UserProfile, CustomProfileField } from '../types/profile';
import { AuthService } from '../auth/authService';
import { StorageService } from '../storage/storage';

describe('ResumeParser - Text, PDF, DOCX & Review Scenarios', () => {
  const sampleResumeText = `
Ananya Deshmukh
Email: ananya.deshmukh@gmail.com
Phone: +91 9876543210
LinkedIn: https://linkedin.com/in/ananya-deshmukh
GitHub: https://github.com/ananya-d

EDUCATION
Bachelor of Technology in Computer Science and Engineering
Indian Institute of Information Technology
Passing Year: 2024
CGPA: 8.85
PRN: IIIT2020CS089

Class 12th (HSC) - Science
Maharashtra State Board
Year of Passing: 2020
Percentage: 91.2%

Class 10th (SSC)
Maharashtra State Board
Year of Passing: 2018
Percentage: 89.5%

SKILLS
JavaScript, TypeScript, React, Node.js, Python, Docker, SQL

PROJECTS
FormPilot Extension
AI-powered form filling assistant built using React and TypeScript.

E-Commerce Portal
Full-stack web application built using Node.js and MongoDB.
  `;

  // Scenario 9: PDF, DOCX, and pasted resume text are parsed
  it('Scenario 9: Pasted resume text is parsed with structured entities', () => {
    const res = ResumeParser.parseResumeText(sampleResumeText);

    expect(res.profile.personal?.fullName).toBe('Ananya Deshmukh');
    expect(res.profile.personal?.email).toBe('ananya.deshmukh@gmail.com');
    expect(res.profile.personal?.phoneNumber).toBe('9876543210');
    expect(res.profile.personal?.linkedin).toBe('https://linkedin.com/in/ananya-deshmukh');

    // Education separation
    expect(res.profile.class10?.percentage).toBe('89.5');
    expect(res.profile.class10?.passingYear).toBe('2018');

    expect(res.profile.class12?.percentage).toBe('91.2');
    expect(res.profile.class12?.passingYear).toBe('2020');
    expect(res.profile.class12?.qualificationType).toBe('12th');

    expect(res.profile.btech?.degree).toBe('B.Tech');
    expect(res.profile.btech?.cgpa).toBe('8.85');
    expect(res.profile.btech?.passingYear).toBe('2024');
    expect(res.profile.btech?.prn).toBe('IIIT2020CS089');

    // Skills
    expect(res.profile.skills).toContain('React');
    expect(res.profile.skills).toContain('TypeScript');
    expect(res.profile.skills).toContain('Docker');
  });

  // Scenario 10: Extracted information can be reviewed and edited before saving
  it('Scenario 10: Extracted data flags uncertain fields for review and allows corrections', () => {
    // Incomplete resume text missing 10th details
    const incompleteResume = `
John Doe
Email: john@example.com
Phone: 9998887776
B.Tech in Mechanical Engineering
CGPA: 7.8
    `;

    const res = ResumeParser.parseResumeText(incompleteResume);
    // Uncertain fields list identifies what needs user review
    expect(res.uncertainFields).toContain('class10.percentage');
    expect(res.uncertainFields).toContain('class12.percentage');

    // Simulate user editing the review payload before applying
    const reviewedProfile: UserProfile = {
      ...defaultProfile,
      personal: {
        ...defaultProfile.personal,
        fullName: res.profile.personal?.fullName || '',
        email: res.profile.personal?.email || '',
      },
      class10: {
        board: 'CBSE',
        school: 'City High',
        passingYear: '2017',
        percentage: '85.0', // User manually corrected this in review
      },
      class12: {
        qualificationType: '12th',
        boardOrInstitution: 'CBSE',
        stream: 'Science',
        passingYear: '2019',
        percentage: '88.0', // User manually corrected this in review
      },
      btech: {
        ...defaultProfile.btech,
        cgpa: res.profile.btech?.cgpa || '',
      },
    };

    expect(reviewedProfile.class10.percentage).toBe('85.0');
    expect(reviewedProfile.btech.cgpa).toBe('7.8');
  });

  // Scenario 11: Existing profiles are not overwritten without confirmation
  it('Scenario 11: Preserves existing data when user opts not to overwrite', () => {
    const existingProfile: UserProfile = {
      ...defaultProfile,
      personal: {
        ...defaultProfile.personal,
        fullName: 'Original Preserved Name',
        currentLocation: 'Bangalore, India',
      },
      btech: {
        ...defaultProfile.btech,
        prn: 'ORIGINAL_PRN_123',
      },
    };

    const extracted = ResumeParser.parseResumeText(`
New Candidate Name
Email: newcandidate@gmail.com
B.Tech CGPA: 9.0
    `);

    // In 'preserve existing' mode: only fill empty properties
    const safeMerged: UserProfile = {
      ...existingProfile,
      personal: {
        ...existingProfile.personal,
        fullName: existingProfile.personal.fullName || extracted.profile.personal?.fullName || '',
        email: existingProfile.personal.email || extracted.profile.personal?.email || '',
      },
      btech: {
        ...existingProfile.btech,
        prn: existingProfile.btech.prn || extracted.profile.btech?.prn || '',
        cgpa: existingProfile.btech.cgpa || extracted.profile.btech?.cgpa || '',
      },
    };

    expect(safeMerged.personal.fullName).toBe('Original Preserved Name');
    expect(safeMerged.btech.prn).toBe('ORIGINAL_PRN_123');
    // Newly provided empty field is populated
    expect(safeMerged.personal.email).toBe('newcandidate@gmail.com');
    expect(safeMerged.btech.cgpa).toBe('9.0');
  });

  // Scenario 12: Complete resume extraction with objective, location, diploma, internships, projects, and certifications
  it('Scenario 12: Extracts professional summary, location, diploma qualification, internships, projects, and awards', () => {
    const fullResume = `
Rahul Verma
Location: Pune, Maharashtra, India
Email: rahul.verma@outlook.com
Phone: +91 9123456789
LinkedIn: https://linkedin.com/in/rahul-verma
GitHub: https://github.com/rahul-v

SUMMARY
Results-oriented software developer with 2+ years of experience developing responsive web applications and RESTful APIs using React and Python.

EDUCATION
Bachelor of Technology in Computer Engineering
Pune Institute of Computer Technology
Passing Year: 2023
CGPA: 9.12
PRN: PICT2019CE055

Diploma in Computer Engineering
Government Polytechnic Pune
Year of Passing: 2020
Percentage: 87.5%

Class 10th (SSC)
Maharashtra State Board
Year of Passing: 2017
Percentage: 86.4%

SKILLS
JavaScript, TypeScript, React.js, Python, Django, PostgreSQL, Docker, Git

EXPERIENCE
Software Engineer Intern
TechCorp Solutions
Jan 2023 - Jun 2023
Built user authentication and form automations using React and FastAPI.

PROJECTS
Smart AutoFill Extension
Technologies: TypeScript, Chrome Extensions API, TailwindCSS
Date: 2023
Link: https://github.com/rahul-v/autofill
Engineered smart DOM detection and form filling assistant with local parsing.

CERTIFICATIONS
AWS Certified Cloud Practitioner
Google Professional Data Engineer

ACHIEVEMENTS
Winner of Smart India Hackathon 2022
Published research paper in IEEE Conference
    `;

    const res = ResumeParser.parseResumeText(fullResume);

    // Personal & Location
    expect(res.profile.personal?.fullName).toBe('Rahul Verma');
    expect(res.profile.personal?.email).toBe('rahul.verma@outlook.com');
    expect(res.profile.personal?.phoneNumber).toBe('9123456789');
    expect(res.profile.personal?.currentLocation).toBe('Pune, Maharashtra, India');
    expect(res.profile.personal?.summary).toContain('Results-oriented software developer');

    // Education
    expect(res.profile.class10?.percentage).toBe('86.4');
    expect(res.profile.class10?.passingYear).toBe('2017');

    // Diploma discrimination
    expect(res.profile.class12?.qualificationType).toBe('Diploma');
    expect(res.profile.class12?.percentage).toBe('87.5');
    expect(res.profile.class12?.passingYear).toBe('2020');

    // B.Tech
    expect(res.profile.btech?.cgpa).toBe('9.12');
    expect(res.profile.btech?.passingYear).toBe('2023');
    expect(res.profile.btech?.prn).toBe('PICT2019CE055');

    // Skills
    expect(res.profile.skills).toContain('React.js');
    expect(res.profile.skills).toContain('Python');
    expect(res.profile.skills).toContain('Django');

    // Experience & Internship detection
    expect(res.profile.experiences).toHaveLength(1);
    expect(res.profile.experiences?.[0].company).toBe('TechCorp Solutions');
    expect(res.profile.experiences?.[0].role).toBe('Software Engineer Intern');
    expect(res.profile.experiences?.[0].isInternship).toBe(true);

    // Projects
    expect(res.profile.projects).toHaveLength(1);
    expect(res.profile.projects?.[0].title).toBe('Smart AutoFill Extension');
    expect(res.profile.projects?.[0].link).toBe('https://github.com/rahul-v/autofill');

    // Certifications & Achievements
    expect(res.profile.certifications).toContain('AWS Certified Cloud Practitioner');
    expect(res.profile.achievements).toContain('Winner of Smart India Hackathon 2022');
  });

  // Scenario 13: Interactive review modification flow
  it('Scenario 13: Allows reviewing, correcting, adding skills, and editing experiences before saving', () => {
    const rawResume = `
Jane Doe
Email: jane@test.com
Phone: 9876500000
B.Tech in Information Technology
CGPA: 8.0
    `;

    const parsed = ResumeParser.parseResumeText(rawResume);
    const reviewedProfile: UserProfile = {
      ...defaultProfile,
      ...parsed.profile,
      personal: {
        ...defaultProfile.personal,
        ...parsed.profile.personal,
        currentLocation: 'Hyderabad, India', // Manually added during review
      },
      skills: ['React', 'TypeScript', 'Node.js'], // Added in review screen
      experiences: [
        {
          id: 'exp_rev_1',
          company: 'Fintech Labs',
          role: 'Full Stack Intern',
          startDate: '2023',
          endDate: 'Present',
          description: 'Payment gateway integrations',
          isInternship: true,
          isCurrent: true,
        },
      ],
    };

    expect(reviewedProfile.personal.currentLocation).toBe('Hyderabad, India');
    expect(reviewedProfile.skills).toHaveLength(3);
    expect(reviewedProfile.experiences[0].isCurrent).toBe(true);
    expect(reviewedProfile.experiences[0].company).toBe('Fintech Labs');
  });

  // Scenario 14: Complex layout with lateral entry / polytechnic diploma (No 12th)
  it('Scenario 14: Accurately separates Polytechnic Diploma from Class 12th and B.Tech without cross-contamination', () => {
    const lateralResume = `
Siddharth Ramesh Patil
Email: siddharth.patil@yahoo.com
Phone: +91 9822012345
Location: Navi Mumbai, India

EDUCATION
Bachelor of Technology in Electronics and Telecommunication
VJTI Mumbai
Passing Year: 2022
CGPA: 8.45

Diploma in Electronics Engineering
Government Polytechnic Mumbai
Year of Passing: 2019
Percentage: 88.2%

Class 10th (SSC)
Maharashtra State Board
Year of Passing: 2016
Percentage: 84.6%

EXPERIENCE
Embedded Firmware Engineer
Siemens India
July 2022 - Present
Developed industrial IoT firmware and Modbus protocols in C and RTOS.
    `;

    const res = ResumeParser.parseResumeText(lateralResume);
    expect(res.profile.personal?.fullName).toBe('Siddharth Ramesh Patil');
    expect(res.profile.personal?.email).toBe('siddharth.patil@yahoo.com');
    expect(res.profile.personal?.phoneNumber).toBe('9822012345');
    expect(res.profile.personal?.currentLocation).toBe('Navi Mumbai, India');

    // 10th
    expect(res.profile.class10?.percentage).toBe('84.6');
    expect(res.profile.class10?.passingYear).toBe('2016');

    // Diploma
    expect(res.profile.class12?.qualificationType).toBe('Diploma');
    expect(res.profile.class12?.percentage).toBe('88.2');
    expect(res.profile.class12?.passingYear).toBe('2019');

    // B.Tech
    expect(res.profile.btech?.degree).toBe('B.Tech');
    expect(res.profile.btech?.branch).toBe('Electronics and Communication');
    expect(res.profile.btech?.cgpa).toBe('8.45');
    expect(res.profile.btech?.passingYear).toBe('2022');

    // Work experience
    expect(res.profile.experiences).toHaveLength(1);
    expect(res.profile.experiences?.[0].company).toBe('Siemens India');
    expect(res.profile.experiences?.[0].isCurrent).toBe(true);
  });

  // Scenario 15: Post-graduate Higher Education + B.E. + 12th + 10th
  it('Scenario 15: Extracts post-graduate M.Tech into higherEducation alongside undergraduate B.E. and schooling', () => {
    const postgradResume = `
Dr. Kavita Narayanan
Email: kavita.narayanan@iisc.ac.in
Phone: +91 9765432109
Location: Bengaluru, Karnataka

SUMMARY
Senior AI Researcher with 5+ years of experience in deep learning, transformer architectures, and medical imaging.

EDUCATION
Master of Technology in Artificial Intelligence
Indian Institute of Science
Passing Year: 2021
CGPA: 9.70

Bachelor of Engineering in Computer Science and Engineering
College of Engineering Guindy
Passing Year: 2019
CGPA: 8.92

Class 12th (HSC)
Tamil Nadu State Board
Passing Year: 2015
Percentage: 96.25%

Class 10th (SSLC)
Tamil Nadu State Board
Passing Year: 2013
Percentage: 95.8%

EXPERIENCE
Senior AI Research Scientist
DeepMind Health
Aug 2021 - Present
Lead research on medical vision-language foundation models.

HONORS & ACHIEVEMENTS
Best Paper Award CVPR 2023
Published 12 papers in top-tier computer vision conferences
    `;

    const res = ResumeParser.parseResumeText(postgradResume);
    expect(res.profile.personal?.fullName).toBe('Dr. Kavita Narayanan');
    expect(res.profile.personal?.email).toBe('kavita.narayanan@iisc.ac.in');
    expect(res.profile.personal?.currentLocation).toBe('Bengaluru, Karnataka');

    // Higher Education (M.Tech)
    expect(res.profile.higherEducation).toHaveLength(1);
    expect(res.profile.higherEducation?.[0].qualification).toBe('M.Tech');
    expect(res.profile.higherEducation?.[0].institution).toContain('Indian Institute of Science');
    expect(res.profile.higherEducation?.[0].specialization).toBe('Artificial Intelligence');
    expect(res.profile.higherEducation?.[0].percentageOrCgpa).toBe('9.70');
    expect(res.profile.higherEducation?.[0].passingYear).toBe('2021');

    // Undergraduate (B.E.)
    expect(res.profile.btech?.degree).toBe('B.E.');
    expect(res.profile.btech?.branch).toBe('Computer Science and Engineering');
    expect(res.profile.btech?.cgpa).toBe('8.92');
    expect(res.profile.btech?.passingYear).toBe('2019');

    // Schooling
    expect(res.profile.class12?.percentage).toBe('96.25');
    expect(res.profile.class12?.passingYear).toBe('2015');
    expect(res.profile.class10?.percentage).toBe('95.8');
    expect(res.profile.class10?.passingYear).toBe('2013');

    // Experience & Achievements
    expect(res.profile.experiences?.[0].company).toBe('DeepMind Health');
    expect(res.profile.achievements).toContain('Best Paper Award CVPR 2023');
  });

  // Scenario 16: Scanned PDF / Empty document detection
  it('Scenario 16: Accurately detects scanned PDFs with no digital text and requires OCR', () => {
    const emptyScannedText = 'Scan 001 Page 1';
    const res = ResumeParser.parseResumeText(emptyScannedText);

    expect(res.isScannedPdf).toBe(true);
    expect(res.needsOcr).toBe(true);
    // Never fabricates missing degrees or contact details
    expect(res.profile.personal?.fullName).toBe('');
    expect(res.profile.personal?.email).toBe('');
    expect(res.profile.btech?.cgpa).toBe('');
  });

  // Scenario 17: Validation and confidence scoring for missing or ambiguous fields
  it('Scenario 17: Flags uncertain fields, inconsistent dates, and assigns calibrated confidence scores', () => {
    const inconsistentResume = `
Candidate With An Inverted Timeline
Email: candidate@sample.org
Phone: 9112345670

EDUCATION
Class 10th
Passing Year: 2022
Percentage: 85%

Class 12th
Passing Year: 2020
Percentage: 88%
    `;

    const res = ResumeParser.parseResumeText(inconsistentResume);

    // Inconsistent: 10th passing year (2022) is after 12th passing year (2020)
    expect(res.conflictingFields).toBeDefined();
    expect(res.conflictingFields!.length).toBeGreaterThan(0);
    expect(res.conflictingFields![0]).toContain('Class 10 passing year');

    // Degree is missing
    expect(res.uncertainFields).toContain('btech.cgpa');
    expect(res.fieldConfidence['btech.degree']).toBeLessThan(0.5);
  });

  // Scenario 18: Custom fields and multi-user account isolation preservation
  it('Scenario 18: Account isolation preserves custom fields and isolates resume data between users', async () => {
    await AuthService._resetAuthForTesting();
    StorageService.clearMemoryCache();

    // 1. User A signup & set custom field
    const signupA = await AuthService.signUp({
      name: 'User Alpha',
      email: 'user.alpha@example.com',
      password: 'AlphaPassword123!',
    });
    expect(signupA.success).toBe(true);

    const initialProfileA = (await StorageService.getAll()).profiles[0];
    const customFieldA: CustomProfileField = {
      id: 'cf_alpha_passport',
      title: 'Passport Number',
      value: 'Z9876543',
      category: 'Identification',
      aliases: ['passport', 'passport_no'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    initialProfileA.customFields = [customFieldA];
    await StorageService.saveProfile(initialProfileA);

    // 2. User A extracts resume and updates profile
    const resumeA = `
Arjun Malhotra
Email: arjun.malhotra@example.com
Phone: 9988776655
B.Tech in Computer Science and Engineering
CGPA: 8.9
    `;
    const parsedA = ResumeParser.parseResumeText(resumeA);

    // In dashboard, merging preserves custom fields
    const updatedProfileA: UserProfile = {
      ...initialProfileA,
      personal: {
        ...initialProfileA.personal,
        fullName: parsedA.profile.personal?.fullName || initialProfileA.personal.fullName,
        email: parsedA.profile.personal?.email || initialProfileA.personal.email,
        phoneNumber: parsedA.profile.personal?.phoneNumber || initialProfileA.personal.phoneNumber,
      },
      btech: {
        ...initialProfileA.btech,
        cgpa: parsedA.profile.btech?.cgpa || initialProfileA.btech.cgpa,
      },
      customFields: initialProfileA.customFields,
    };
    await StorageService.saveProfile(updatedProfileA);

    const reloadedA = (await StorageService.getAll()).profiles[0];
    expect(reloadedA.personal.fullName).toBe('Arjun Malhotra');
    expect(reloadedA.customFields).toHaveLength(1);
    expect(reloadedA.customFields![0].title).toBe('Passport Number');

    // 3. User B registers and logs in
    const signupB = await AuthService.signUp({
      name: 'User Beta',
      email: 'user.beta@example.com',
      password: 'BetaPassword123!',
    });
    expect(signupB.success).toBe(true);

    // Storage for User B must be isolated - empty custom fields and separate profile
    const dataB = await StorageService.getAll();
    const profileB = dataB.profiles[0];
    expect(profileB.personal.fullName).toBe('User Beta');
    expect(profileB.personal.email).toBe('user.beta@example.com');
    expect(profileB.customFields || []).toHaveLength(0);
  });

  // Scenario 19: Field-level Precision, Recall, and F1-Score Benchmark against verified reference data
  it('Scenario 19: Field-level Precision, Recall, and F1-Score Benchmark on multi-format resumes', () => {
    interface EvaluationField {
      path: string;
      expected: string | string[];
      extractor: (profile: Partial<UserProfile>) => string | string[] | undefined;
    }

    interface ResumeTestCase {
      name: string;
      rawText: string;
      groundTruth: EvaluationField[];
    }

    const testSuite: ResumeTestCase[] = [
      {
        name: 'Standard Engineering Graduate',
        rawText: `
Aditya Prakash Sharma
Email: aditya.sharma2024@gmail.com
Phone: +91 9823456781
Location: Bangalore, Karnataka, India
LinkedIn: https://linkedin.com/in/aditya-sharma-dev
GitHub: https://github.com/adityasharma-code

EDUCATION
Bachelor of Technology in Information Technology
Vellore Institute of Technology
Passing Year: 2024
CGPA: 9.24
PRN: 20BIT0142

Class 12th (HSC)
Delhi Public School
Year of Passing: 2020
Percentage: 94.6%

Class 10th (SSC)
Delhi Public School
Year of Passing: 2018
Percentage: 92.0%

SKILLS
TypeScript, React, Python, Docker, Kubernetes, AWS, PostgreSQL

EXPERIENCE
Software Engineering Intern
Amazon Web Services
May 2023 - July 2023
Contributed to cloud infrastructure tooling and telemetry pipelines.

PROJECTS
CloudScale Orchestrator
Technologies: Go, Kubernetes, gRPC
Link: https://github.com/adityasharma-code/cloudscale
Distributed container orchestration engine.
        `,
        groundTruth: [
          { path: 'personal.fullName', expected: 'Aditya Prakash Sharma', extractor: (p) => p.personal?.fullName },
          { path: 'personal.email', expected: 'aditya.sharma2024@gmail.com', extractor: (p) => p.personal?.email },
          { path: 'personal.phoneNumber', expected: '9823456781', extractor: (p) => p.personal?.phoneNumber },
          { path: 'personal.linkedin', expected: 'https://linkedin.com/in/aditya-sharma-dev', extractor: (p) => p.personal?.linkedin },
          { path: 'personal.github', expected: 'https://github.com/adityasharma-code', extractor: (p) => p.personal?.github },
          { path: 'class10.percentage', expected: '92.0', extractor: (p) => p.class10?.percentage },
          { path: 'class10.passingYear', expected: '2018', extractor: (p) => p.class10?.passingYear },
          { path: 'class12.percentage', expected: '94.6', extractor: (p) => p.class12?.percentage },
          { path: 'class12.passingYear', expected: '2020', extractor: (p) => p.class12?.passingYear },
          { path: 'btech.degree', expected: 'B.Tech', extractor: (p) => p.btech?.degree },
          { path: 'btech.branch', expected: 'Information Technology', extractor: (p) => p.btech?.branch },
          { path: 'btech.cgpa', expected: '9.24', extractor: (p) => p.btech?.cgpa },
          { path: 'btech.passingYear', expected: '2024', extractor: (p) => p.btech?.passingYear },
          { path: 'btech.prn', expected: '20BIT0142', extractor: (p) => p.btech?.prn },
          { path: 'experiences[0].company', expected: 'Amazon Web Services', extractor: (p) => p.experiences?.[0]?.company },
          { path: 'projects[0].title', expected: 'CloudScale Orchestrator', extractor: (p) => p.projects?.[0]?.title },
        ],
      },
      {
        name: 'Diploma Lateral Entry Resume',
        rawText: `
Neha Rajesh Joshi
Email: neha.joshi@gmail.com
Phone: 9811223344
Location: Pune, Maharashtra

EDUCATION
Bachelor of Technology in Computer Engineering
College of Engineering Pune
Passing Year: 2023
CGPA: 8.75

Diploma in Computer Technology
Government Polytechnic Pune
Passing Year: 2020
Percentage: 89.2%

Class 10th
Maharashtra State Board
Passing Year: 2017
Percentage: 88.0%

SKILLS
Java, Spring Boot, React, MySQL, Microservices

EXPERIENCE
Associate Software Engineer
Persistent Systems
Aug 2023 - Present
Backend microservices development using Spring Boot and Kafka.
        `,
        groundTruth: [
          { path: 'personal.fullName', expected: 'Neha Rajesh Joshi', extractor: (p) => p.personal?.fullName },
          { path: 'personal.email', expected: 'neha.joshi@gmail.com', extractor: (p) => p.personal?.email },
          { path: 'personal.phoneNumber', expected: '9811223344', extractor: (p) => p.personal?.phoneNumber },
          { path: 'class10.percentage', expected: '88.0', extractor: (p) => p.class10?.percentage },
          { path: 'class12.qualificationType', expected: 'Diploma', extractor: (p) => p.class12?.qualificationType },
          { path: 'class12.percentage', expected: '89.2', extractor: (p) => p.class12?.percentage },
          { path: 'btech.degree', expected: 'B.Tech', extractor: (p) => p.btech?.degree },
          { path: 'btech.cgpa', expected: '8.75', extractor: (p) => p.btech?.cgpa },
          { path: 'btech.passingYear', expected: '2023', extractor: (p) => p.btech?.passingYear },
          { path: 'experiences[0].company', expected: 'Persistent Systems', extractor: (p) => p.experiences?.[0]?.company },
        ],
      },
      {
        name: 'Higher Education M.Tech Resume',
        rawText: `
Vikramaditya Rao
Email: vikram.rao@alumni.iitm.ac.in
Phone: +91 9444012345
Location: Chennai, Tamil Nadu

EDUCATION
Master of Technology in Computer Science and Engineering
Indian Institute of Technology Madras
Passing Year: 2022
CGPA: 9.40

Bachelor of Engineering in Electronics and Communication
Anna University
Passing Year: 2020
CGPA: 8.60

Class 12th
Central Board of Secondary Education
Passing Year: 2016
Percentage: 93.4%

Class 10th
Central Board of Secondary Education
Passing Year: 2014
Percentage: 91.2%
        `,
        groundTruth: [
          { path: 'personal.fullName', expected: 'Vikramaditya Rao', extractor: (p) => p.personal?.fullName },
          { path: 'personal.email', expected: 'vikram.rao@alumni.iitm.ac.in', extractor: (p) => p.personal?.email },
          { path: 'personal.phoneNumber', expected: '9444012345', extractor: (p) => p.personal?.phoneNumber },
          { path: 'higherEducation[0].qualification', expected: 'M.Tech', extractor: (p) => p.higherEducation?.[0]?.qualification },
          { path: 'higherEducation[0].percentageOrCgpa', expected: '9.40', extractor: (p) => p.higherEducation?.[0]?.percentageOrCgpa },
          { path: 'higherEducation[0].passingYear', expected: '2022', extractor: (p) => p.higherEducation?.[0]?.passingYear },
          { path: 'btech.degree', expected: 'B.E.', extractor: (p) => p.btech?.degree },
          { path: 'btech.cgpa', expected: '8.60', extractor: (p) => p.btech?.cgpa },
          { path: 'class12.percentage', expected: '93.4', extractor: (p) => p.class12?.percentage },
          { path: 'class10.percentage', expected: '91.2', extractor: (p) => p.class10?.percentage },
        ],
      },
    ];

    let totalTruePositives = 0;
    let totalFalsePositives = 0;
    let totalFalseNegatives = 0;

    for (const testCase of testSuite) {
      const parsed = ResumeParser.parseResumeText(testCase.rawText);

      for (const field of testCase.groundTruth) {
        const actual = field.extractor(parsed.profile);
        if (actual === undefined || actual === '' || (Array.isArray(actual) && actual.length === 0)) {
          totalFalseNegatives++;
        } else if (
          typeof field.expected === 'string' &&
          typeof actual === 'string' &&
          (actual.toLowerCase().trim() === field.expected.toLowerCase().trim() ||
            actual.toLowerCase().includes(field.expected.toLowerCase().trim()))
        ) {
          totalTruePositives++;
        } else if (
          Array.isArray(field.expected) &&
          Array.isArray(actual) &&
          field.expected.every((exp) => actual.includes(exp))
        ) {
          totalTruePositives++;
        } else {
          totalFalsePositives++;
        }
      }
    }

    const precision = totalTruePositives / (totalTruePositives + totalFalsePositives);
    const recall = totalTruePositives / (totalTruePositives + totalFalseNegatives);
    const f1Score = (2 * precision * recall) / (precision + recall);

    // Verify benchmark targets
    expect(precision).toBeGreaterThanOrEqual(0.90); // >= 90% Precision
    expect(recall).toBeGreaterThanOrEqual(0.85);    // >= 85% Recall
    expect(f1Score).toBeGreaterThanOrEqual(0.88);   // >= 88% F1-Score
  });

  // Scenario 20: Regression Test - "Python, NLP" is mapped to Skills and NEVER to Current Location / Address
  it('Scenario 20: Maps "Python, NLP" to Skills and NEVER to Current Location / Address', () => {
    const resumeWithSkillsHeader = `
Rohan Deshmukh
Email: rohan.deshmukh@gmail.com
Phone: +91 9876501234
Python, NLP
LinkedIn: https://linkedin.com/in/rohan-deshmukh

EDUCATION
Bachelor of Technology in Computer Science
Pune Institute of Computer Technology
Passing Year: 2024
CGPA: 8.90
    `;

    const res = ResumeParser.parseResumeText(resumeWithSkillsHeader);

    // Address MUST NOT be "Python, NLP"
    expect(res.profile.personal?.currentLocation).not.toContain('Python');
    expect(res.profile.personal?.currentLocation).not.toContain('NLP');
    expect(res.profile.personal?.currentLocation).toBe('');

    // Skills MUST contain Python and NLP
    expect(res.profile.skills).toContain('Python');
    expect(res.profile.skills).toContain('NLP');

    // Name, email, education must be cleanly preserved
    expect(res.profile.personal?.fullName).toBe('Rohan Deshmukh');
    expect(res.profile.personal?.email).toBe('rohan.deshmukh@gmail.com');
    expect(res.profile.btech?.cgpa).toBe('8.90');
  });

  // Scenario 21: Regression Test - Valid address extraction when present
  it('Scenario 21: Accurately extracts valid address such as "Pune, Maharashtra, India"', () => {
    const resumeWithValidAddress = `
Tanvi Kulkarni
Email: tanvi.kulkarni@gmail.com
Phone: 9823012345
Pune, Maharashtra, India

SKILLS
Python, NLP, React, Node.js

EDUCATION
Bachelor of Engineering in Information Technology
Government College of Engineering
Passing Year: 2023
CGPA: 9.10
    `;

    const res = ResumeParser.parseResumeText(resumeWithValidAddress);

    // Valid address must be preserved
    expect(res.profile.personal?.currentLocation).toBe('Pune, Maharashtra, India');

    // Skills must contain Python and NLP
    expect(res.profile.skills).toContain('Python');
    expect(res.profile.skills).toContain('NLP');
    expect(res.profile.skills).toContain('React');
  });

  // Scenario 22: Regression Test - Missing address leaves address field completely empty without guessing
  it('Scenario 22: Leaves address field completely empty when no location is present', () => {
    const resumeWithoutLocation = `
Sameer Joshi
Email: sameer.joshi@example.com
Phone: 9811223344

EDUCATION
Bachelor of Technology in Mechanical Engineering
National Institute of Technology
Passing Year: 2022
CGPA: 8.20

SKILLS
AutoCAD, SolidWorks, Python, MATLAB
    `;

    const res = ResumeParser.parseResumeText(resumeWithoutLocation);

    // Address field must be empty string
    expect(res.profile.personal?.currentLocation).toBe('');

    // Marked as uncertain for manual user review
    expect(res.uncertainFields).toContain('personal.currentLocation');
    expect(res.fieldConfidence['personal.currentLocation']).toBe(0);
  });

  // Scenario 23: Regression Test - Skills and projects appearing near contact section are not assigned to address
  it('Scenario 23: Ensures skills and projects near contact section are not mistakenly assigned to address', () => {
    const resumeWithNearbySkillsAndProjects = `
Pooja Nair
pooja.nair@outlook.com | +91 9845012345
Technical Skills: Python, NLP, Java, React, SQL
Projects: FormPilot AI Assistant, HealthTracker App

EDUCATION
Bachelor of Technology in Computer Science
Passing Year: 2024
CGPA: 8.75
    `;

    const res = ResumeParser.parseResumeText(resumeWithNearbySkillsAndProjects);

    // Address must be empty and not contain any skill or project
    expect(res.profile.personal?.currentLocation).toBe('');
    expect(res.profile.personal?.currentLocation).not.toContain('Python');
    expect(res.profile.personal?.currentLocation).not.toContain('FormPilot');

    // Skills must be extracted
    expect(res.profile.skills).toContain('Python');
    expect(res.profile.skills).toContain('NLP');
    expect(res.profile.skills).toContain('Java');
    expect(res.profile.skills).toContain('React');
    expect(res.profile.skills).toContain('SQL');
  });

  // Scenario 24: Regression Test - Does not overwrite previously saved valid address with empty/invalid extracted value
  it('Scenario 24: Does not overwrite previously saved valid address with empty extracted location', () => {
    const existingProfile: UserProfile = {
      ...defaultProfile,
      personal: {
        ...defaultProfile.personal,
        fullName: 'Aarav Mehta',
        currentLocation: 'Bangalore, Karnataka, India', // Previously saved valid address
      },
    };

    // New resume has no address but has Python, NLP
    const newResumeWithoutAddress = `
Aarav Mehta
Email: aarav.mehta@example.com
Python, NLP
B.Tech CGPA: 9.0
    `;

    const extracted = ResumeParser.parseResumeText(newResumeWithoutAddress);
    expect(extracted.profile.personal?.currentLocation).toBe('');

    // Simulate safe profile merging: preserve existing address if extracted is empty
    const mergedProfile: UserProfile = {
      ...existingProfile,
      personal: {
        ...existingProfile.personal,
        email: extracted.profile.personal?.email || existingProfile.personal.email,
        currentLocation: extracted.profile.personal?.currentLocation || existingProfile.personal.currentLocation,
      },
      skills: Array.from(new Set([...(existingProfile.skills || []), ...(extracted.profile.skills || [])])),
    };

    expect(mergedProfile.personal.currentLocation).toBe('Bangalore, Karnataka, India');
    expect(mergedProfile.skills).toContain('Python');
    expect(mergedProfile.skills).toContain('NLP');
  });
});
