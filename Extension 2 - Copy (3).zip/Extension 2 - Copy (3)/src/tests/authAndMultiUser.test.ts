import { describe, it, expect, beforeEach } from 'vitest';
import { AuthService } from '../auth/authService';
import { StorageService, sanitizeProfile, sanitizeProfiles } from '../storage/storage';
import { CryptoUtils } from '../auth/crypto';

describe('Secure Multi-User Login, Signup & Storage Isolation System', () => {
  beforeEach(async () => {
    // Reset all auth and storage state before each test
    await AuthService._resetAuthForTesting();
    StorageService.clearMemoryCache();
  });

  it('Requirement 1: User Registration validates fields and enforces constraints', async () => {
    // Empty name
    const res1 = await AuthService.signUp({
      name: '',
      email: 'alice@example.com',
      password: 'Password123',
    });
    expect(res1.success).toBe(false);
    expect(res1.error).toContain('full name');

    // Invalid email format
    const res2 = await AuthService.signUp({
      name: 'Alice Smith',
      email: 'not-an-email',
      password: 'Password123',
    });
    expect(res2.success).toBe(false);
    expect(res2.error).toContain('valid email');

    // Short password
    const res3 = await AuthService.signUp({
      name: 'Alice Smith',
      email: 'alice@example.com',
      password: '123',
    });
    expect(res3.success).toBe(false);
    expect(res3.error).toContain('at least 6 characters');

    // Password mismatch
    const res4 = await AuthService.signUp({
      name: 'Alice Smith',
      email: 'alice@example.com',
      password: 'Password123',
      confirmPassword: 'MismatchPassword',
    });
    expect(res4.success).toBe(false);
    expect(res4.error).toContain('do not match');

    // Valid signup
    const resValid = await AuthService.signUp({
      name: 'Alice Smith',
      email: 'alice@example.com',
      password: 'Password123',
      confirmPassword: 'Password123',
    });
    expect(resValid.success).toBe(true);
    expect(resValid.user).toBeDefined();
    expect(resValid.user?.email).toBe('alice@example.com');
    expect(resValid.user?.name).toBe('Alice Smith');
    expect(resValid.session?.token).toBeDefined();
  });

  it('Requirement 1: Prevents duplicate registrations with the same email address', async () => {
    const res1 = await AuthService.signUp({
      name: 'First User',
      email: 'duplicate@example.com',
      password: 'SecretPassword1',
    });
    expect(res1.success).toBe(true);

    // Attempt second signup with exact same email
    const res2 = await AuthService.signUp({
      name: 'Second User',
      email: 'duplicate@example.com',
      password: 'SecretPassword2',
    });
    expect(res2.success).toBe(false);
    expect(res2.error).toContain('already exists');

    // Attempt signup with same email differing only in case and spaces
    const res3 = await AuthService.signUp({
      name: 'Third User',
      email: '  DUPLICATE@example.com ',
      password: 'SecretPassword3',
    });
    expect(res3.success).toBe(false);
    expect(res3.error).toContain('already exists');
  });

  it('Requirement 1 & 5: Passwords are cryptographically hashed using PBKDF2 with unique salts (never plain-text)', async () => {
    const salt1 = CryptoUtils.generateSalt();
    const salt2 = CryptoUtils.generateSalt();
    expect(salt1).not.toBe(salt2);

    const hash1 = await CryptoUtils.hashPassword('MySecurePassword', salt1);
    const hash2 = await CryptoUtils.hashPassword('MySecurePassword', salt2);

    // Hashes must be different because salts are different
    expect(hash1).not.toBe(hash2);
    expect(hash1).not.toContain('MySecurePassword');

    // Verify valid and invalid password checks
    const matchValid = await CryptoUtils.verifyPassword('MySecurePassword', salt1, hash1);
    expect(matchValid).toBe(true);

    const matchInvalid = await CryptoUtils.verifyPassword('WrongPassword', salt1, hash1);
    expect(matchInvalid).toBe(false);
  });

  it('Requirement 1: User Login validates credentials correctly', async () => {
    await AuthService.signUp({
      name: 'Charlie Brown',
      email: 'charlie@example.com',
      password: 'CorrectPassword123',
    });
    await AuthService.signOut();

    // Wrong email
    const resWrongEmail = await AuthService.signIn({
      email: 'nonexistent@example.com',
      password: 'CorrectPassword123',
    });
    expect(resWrongEmail.success).toBe(false);
    expect(resWrongEmail.error).toContain('Invalid email or password');

    // Wrong password
    const resWrongPass = await AuthService.signIn({
      email: 'charlie@example.com',
      password: 'IncorrectPassword',
    });
    expect(resWrongPass.success).toBe(false);
    expect(resWrongPass.error).toContain('Invalid email or password');

    // Correct login
    const resSuccess = await AuthService.signIn({
      email: 'charlie@example.com',
      password: 'CorrectPassword123',
    });
    expect(resSuccess.success).toBe(true);
    expect(resSuccess.user?.name).toBe('Charlie Brown');
  });

  it('Requirement 1: Forgot Password generates verification code and allows secure password reset', async () => {
    await AuthService.signUp({
      name: 'Reset Test User',
      email: 'reset@example.com',
      password: 'OldPassword123',
    });
    await AuthService.signOut();

    // Non-existent email
    const reqInvalid = await AuthService.resetPassword('unknown@example.com');
    expect(reqInvalid.success).toBe(false);

    // Valid reset request
    const reqValid = await AuthService.resetPassword('reset@example.com');
    expect(reqValid.success).toBe(true);
    expect(reqValid.resetToken).toBeDefined();

    const token = reqValid.resetToken!;

    // Confirm with invalid code
    const confirmBad = await AuthService.confirmPasswordReset('000000', 'NewPassword123');
    expect(confirmBad.success).toBe(false);

    // Confirm with valid code
    const confirmGood = await AuthService.confirmPasswordReset(token, 'NewPassword123');
    expect(confirmGood.success).toBe(true);

    // Now verify old password fails and new password works
    const oldLogin = await AuthService.signIn({ email: 'reset@example.com', password: 'OldPassword123' });
    expect(oldLogin.success).toBe(false);

    const newLogin = await AuthService.signIn({ email: 'reset@example.com', password: 'NewPassword123' });
    expect(newLogin.success).toBe(true);
  });

  it('Requirement 2 & 4: Separate Accounts & Data Isolation - User A and User B never leak data', async () => {
    // 1. Sign up User A (Alice)
    const signupA = await AuthService.signUp({
      name: 'Alice Wonder',
      email: 'alice@wonder.com',
      password: 'AlicePassword123',
    });
    expect(signupA.success).toBe(true);
    const userA = signupA.user!;

    // Alice adds a custom field
    const activeProfA = await StorageService.getActiveProfile();
    await StorageService.addCustomField(activeProfA.id, {
      title: "Alice's Secret Key",
      value: 'SECRET-ALICE-999',
      category: 'Identification',
      aliases: ['secret key'],
    });

    // Alice adds a job application
    await StorageService.saveApplication({
      id: 'app_alice_1',
      company: 'Alice Tech Corp',
      jobTitle: 'Senior Architect',
      status: 'Interview',
      dateApplied: '2026-10-14',
    });

    // Alice adds a learned mapping
    await StorageService.saveLearnedMapping({
      id: 'lm_alice_1',
      domain: 'alice-jobs.org',
      fieldLabel: 'Internal Alice Code',
      targetProperty: 'custom.secret',
    });

    // Verify Alice's data is present
    const aliceFields = await StorageService.getCustomFields();
    expect(aliceFields.length).toBe(1);
    expect(aliceFields[0].value).toBe('SECRET-ALICE-999');

    const aliceApps = await StorageService.getApplications();
    expect(aliceApps.length).toBe(1);
    expect(aliceApps[0].company).toBe('Alice Tech Corp');

    // 2. Sign out Alice
    await AuthService.signOut();
    StorageService.clearMemoryCache();

    // 3. Sign up User B (Bob)
    const signupB = await AuthService.signUp({
      name: 'Bob Builder',
      email: 'bob@builder.com',
      password: 'BobPassword123',
    });
    expect(signupB.success).toBe(true);
    const userB = signupB.user!;

    // Bob must have an independent, clean initial profile
    const profB = await StorageService.getActiveProfile();
    expect(profB.personal.fullName).toBe('Bob Builder');
    expect(profB.personal.email).toBe('bob@builder.com');

    // Bob must have ZERO of Alice's custom fields
    const bobFields = await StorageService.getCustomFields();
    expect(bobFields.length).toBe(0);

    // Bob must have ZERO of Alice's applications
    const bobApps = await StorageService.getApplications();
    expect(bobApps.length).toBe(0);

    // Bob must have ZERO of Alice's learned mappings
    const bobMappings = await StorageService.getLearnedMappings();
    expect(bobMappings.length).toBe(0);

    // 4. Bob adds his own data
    await StorageService.addCustomField(profB.id, {
      title: "Bob's License",
      value: 'BOB-LICENSE-555',
      category: 'Certificates',
      aliases: ['contractor license'],
    });

    await StorageService.saveApplication({
      id: 'app_bob_1',
      company: 'Bob Construction Ltd',
      jobTitle: 'Lead Builder',
      status: 'Applied',
      dateApplied: '2026-10-15',
    });

    const bobFieldsUpdated = await StorageService.getCustomFields();
    expect(bobFieldsUpdated.length).toBe(1);
    expect(bobFieldsUpdated[0].value).toBe('BOB-LICENSE-555');

    // 5. Sign out Bob and log Alice back in
    await AuthService.signOut();
    StorageService.clearMemoryCache();

    await AuthService.signIn({
      email: 'alice@wonder.com',
      password: 'AlicePassword123',
    });

    // Verify Alice sees only HER original data and NONE of Bob's data
    const aliceRestoredFields = await StorageService.getCustomFields();
    expect(aliceRestoredFields.length).toBe(1);
    expect(aliceRestoredFields[0].title).toBe("Alice's Secret Key");
    expect(aliceRestoredFields[0].value).toBe('SECRET-ALICE-999');
    expect(aliceRestoredFields.some((f) => f.title === "Bob's License")).toBe(false);

    const aliceRestoredApps = await StorageService.getApplications();
    expect(aliceRestoredApps.length).toBe(1);
    expect(aliceRestoredApps[0].company).toBe('Alice Tech Corp');
    expect(aliceRestoredApps.some((a) => a.company === 'Bob Construction Ltd')).toBe(false);
  });

  it('Requirement 3: Logout clears session and restores login screen state', async () => {
    await AuthService.signUp({
      name: 'Session User',
      email: 'session@example.com',
      password: 'SessionPassword123',
    });

    const currUser = await AuthService.getCurrentUser();
    expect(currUser).toBeDefined();

    await AuthService.signOut();

    const loggedOutUser = await AuthService.getCurrentUser();
    expect(loggedOutUser).toBeNull();

    const session = await AuthService.getCurrentSession();
    expect(session).toBeNull();
  });

  it('Dashboard Fix: Newly registered user initializes a complete UserProfile schema preventing dashboard render crashes', async () => {
    // 1. Sign up a new user
    const res = await AuthService.signUp({
      name: 'Priya Sharma',
      email: 'priya.sharma@example.com',
      password: 'SecurePassword123',
    });
    expect(res.success).toBe(true);
    expect(res.user).toBeDefined();

    // 2. Fetch the newly registered user's active profile
    const activeProfile = await StorageService.getActiveProfile();
    expect(activeProfile).toBeDefined();

    // 3. Verify personal fields are derived and present
    expect(activeProfile.personal).toBeDefined();
    expect(activeProfile.personal.fullName).toBe('Priya Sharma');
    expect(activeProfile.personal.firstName).toBe('Priya');
    expect(activeProfile.personal.lastName).toBe('Sharma');
    expect(activeProfile.personal.email).toBe('priya.sharma@example.com');

    // 4. Verify class10, class12, and btech schemas are present and never undefined
    // (This was the root cause that crashed Dashboard.tsx when accessing profile.class10.board)
    expect(activeProfile.class10).toBeDefined();
    expect(activeProfile.class10.board).toBeDefined();
    expect(activeProfile.class10.school).toBeDefined();
    expect(activeProfile.class10.passingYear).toBeDefined();
    expect(activeProfile.class10.percentage).toBeDefined();

    expect(activeProfile.class12).toBeDefined();
    expect(activeProfile.class12.qualificationType).toBe('12th');
    expect(activeProfile.class12.boardOrInstitution).toBeDefined();
    expect(activeProfile.class12.stream).toBeDefined();
    expect(activeProfile.class12.passingYear).toBeDefined();
    expect(activeProfile.class12.percentage).toBeDefined();

    expect(activeProfile.btech).toBeDefined();
    expect(activeProfile.btech.degree).toBe('B.Tech');
    expect(activeProfile.btech.branch).toBeDefined();
    expect(activeProfile.btech.college).toBeDefined();
    expect(activeProfile.btech.passingYear).toBeDefined();
    expect(activeProfile.btech.cgpa).toBeDefined();
    expect(activeProfile.btech.activeBacklogs).toBe('0');
    expect(activeProfile.btech.deadBacklogs).toBe('0');
    expect(activeProfile.btech.prn).toBeDefined();

    // 5. Verify arrays are initialized and never undefined
    expect(Array.isArray(activeProfile.higherEducation)).toBe(true);
    expect(Array.isArray(activeProfile.skills)).toBe(true);
    expect(Array.isArray(activeProfile.experiences)).toBe(true);
    expect(Array.isArray(activeProfile.projects)).toBe(true);
    expect(Array.isArray(activeProfile.customAnswers)).toBe(true);
    expect(Array.isArray(activeProfile.customFields)).toBe(true);

    // 6. Verify empty tracker and empty custom fields load cleanly without throwing
    const allData = await StorageService.getAll();
    expect(Array.isArray(allData.applications)).toBe(true);
    expect(allData.applications.length).toBe(0);
    expect(Array.isArray(allData.learnedMappings)).toBe(true);
    expect(allData.learnedMappings.length).toBe(0);
  });

  it('Dashboard Fix: sanitizeProfile safely handles partial or corrupted profile shapes without crashing', () => {
    // Completely empty object
    const sanitizedEmpty = sanitizeProfile({});
    expect(sanitizedEmpty.personal.fullName).toBe('');
    expect(sanitizedEmpty.class10.board).toBe('');
    expect(sanitizedEmpty.class12.qualificationType).toBe('12th');
    expect(sanitizedEmpty.btech.degree).toBe('B.Tech');
    expect(Array.isArray(sanitizedEmpty.higherEducation)).toBe(true);
    expect(Array.isArray(sanitizedEmpty.skills)).toBe(true);

    // Null or undefined
    const sanitizedNull = sanitizeProfile(null);
    expect(sanitizedNull.id).toBeDefined();
    expect(sanitizedNull.class10.board).toBe('');

    // Legacy shape with nested 'education' or 'tenth'
    const legacyProfile = {
      id: 'legacy_1',
      name: 'Legacy User',
      education: {
        tenth: { board: 'CBSE', school: 'DPS', percentage: '92%' },
        twelfth: { board: 'State Board', percentage: '88%' },
      },
      skills: ['JavaScript', 'React'],
    };

    const sanitizedLegacy = sanitizeProfile(legacyProfile);
    expect(sanitizedLegacy.class10.board).toBe('CBSE');
    expect(sanitizedLegacy.class10.school).toBe('DPS');
    expect(sanitizedLegacy.class10.percentage).toBe('92%');
    expect(sanitizedLegacy.class12.boardOrInstitution).toBe('State Board');
    expect(sanitizedLegacy.btech.degree).toBe('B.Tech');
    expect(sanitizedLegacy.skills).toEqual(['JavaScript', 'React']);
  });
});
