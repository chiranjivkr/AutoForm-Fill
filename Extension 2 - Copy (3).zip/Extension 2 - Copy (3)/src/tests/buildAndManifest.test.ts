import { describe, it, expect } from 'vitest';
import fs from 'fs';
import path from 'path';

describe('Build & Manifest V3 Verification (Scenarios 16 & 17)', () => {
  const distDir = path.resolve('dist');

  it('Scenario 16: Manifest file exists, is valid Manifest V3, and defines required permissions', () => {
    const manifestPath = path.join(distDir, 'manifest.json');
    expect(fs.existsSync(manifestPath)).toBe(true);

    const manifestContent = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    expect(manifestContent.manifest_version).toBe(3);
    expect(manifestContent.name).toContain('FormPilot AI');
    expect(manifestContent.version).toBe('1.0.0');

    // Permissions
    expect(manifestContent.permissions).toContain('storage');
    expect(manifestContent.permissions).toContain('activeTab');

    // Background service worker
    expect(manifestContent.background?.service_worker).toBe('background.js');
    expect(manifestContent.background?.type).toBe('module');

    // UI entry points
    expect(manifestContent.action?.default_popup).toBe('popup.html');
    expect(manifestContent.options_ui?.page).toBe('options.html');
  });

  it('Scenario 17: All extension assets referenced in manifest exist on disk with valid bundles', () => {
    const filesToCheck = [
      'popup.html',
      'options.html',
      'background.js',
      'content.js',
      'content.css',
      'icons/icon16.png',
      'icons/icon48.png',
      'icons/icon128.png',
    ];

    for (const f of filesToCheck) {
      const fullPath = path.join(distDir, f);
      expect(fs.existsSync(fullPath)).toBe(true);
      const stat = fs.statSync(fullPath);
      expect(stat.size).toBeGreaterThan(0);
    }

    // Verify content script is non-empty and runnable
    const contentJs = fs.readFileSync(path.join(distDir, 'content.js'), 'utf-8');
    expect(contentJs.length).toBeGreaterThan(1000);

    // Verify service worker is non-empty
    const bgJs = fs.readFileSync(path.join(distDir, 'background.js'), 'utf-8');
    expect(bgJs.length).toBeGreaterThan(500);
  });
});
