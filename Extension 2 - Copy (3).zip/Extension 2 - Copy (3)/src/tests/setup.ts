import { vi } from 'vitest';

// Global mock for chrome extension APIs in test environment
const mockStorage: Record<string, any> = {};

const chromeMock = {
  storage: {
    local: {
      get: vi.fn((keys, callback) => {
        if (!keys) {
          callback({ ...mockStorage });
        } else if (typeof keys === 'string') {
          callback({ [keys]: mockStorage[keys] });
        } else if (Array.isArray(keys)) {
          const res: any = {};
          keys.forEach((k) => (res[k] = mockStorage[k]));
          callback(res);
        } else {
          callback({ ...mockStorage });
        }
      }),
      set: vi.fn((items, callback) => {
        Object.assign(mockStorage, items);
        if (callback) callback();
      }),
      remove: vi.fn((keys, callback) => {
        const keyList = Array.isArray(keys) ? keys : [keys];
        keyList.forEach((k) => delete mockStorage[k]);
        if (callback) callback();
      }),
      clear: vi.fn((callback) => {
        Object.keys(mockStorage).forEach((k) => delete mockStorage[k]);
        if (callback) callback();
      }),
    },
    onChanged: {
      addListener: vi.fn(),
      removeListener: vi.fn(),
    },
  },
  runtime: {
    lastError: null,
    sendMessage: vi.fn(),
    onMessage: {
      addListener: vi.fn(),
      removeListener: vi.fn(),
    },
    openOptionsPage: vi.fn(),
  },
  tabs: {
    query: vi.fn((q, cb) => cb([{ id: 1, url: 'https://example.com' }])),
    sendMessage: vi.fn(),
  },
  contextMenus: {
    create: vi.fn(),
    onClicked: {
      addListener: vi.fn(),
    },
  },
};

(globalThis as any).chrome = chromeMock;
