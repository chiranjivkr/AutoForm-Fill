import { describe, it, expect } from 'vitest';
import { StorageService } from '../storage/storage';
import { JobApplication } from '../types/tracker';
import { MappingEngine } from '../services/mappingEngine';
import { defaultProfile, UserProfile } from '../types/profile';

describe('Application Tracker & Form Learning', () => {
  // Scenario 14: Application Tracker operations work correctly
  it('Scenario 14: Application Tracker supports create, read, and delete operations', async () => {
    const testApp: JobApplication = {
      id: 'app_test_101',
      company: 'Amazon Web Services',
      jobTitle: 'Cloud Support Associate',
      applicationLink: 'https://amazon.jobs/101',
      dateApplied: '2025-01-15',
      deadline: '2025-02-01',
      status: 'Interview',
      notes: 'Round 1 technical phone screen scheduled',
      documents: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save application
    await StorageService.saveApplication(testApp);

    // Retrieve applications
    const apps = await StorageService.getApplications();
    const found = apps.find((a) => a.id === 'app_test_101');
    expect(found).toBeDefined();
    expect(found?.company).toBe('Amazon Web Services');
    expect(found?.status).toBe('Interview');

    // Delete application
    await StorageService.deleteApplication('app_test_101');
    const remaining = await StorageService.getApplications();
    expect(remaining.find((a) => a.id === 'app_test_101')).toBeUndefined();
  });

  // Scenario 15: Form Learning stores and reuses corrections appropriately
  it('Scenario 15: Form Learning stores corrections and prioritizes them in mapping', async () => {
    const customProfile: UserProfile = {
      ...defaultProfile,
      btech: {
        ...defaultProfile.btech,
        prn: 'SPECIAL_PRN_999',
      },
    };

    // Teach FormPilot that an unusual field label "College Unique Identity" maps to "btech.prn"
    await StorageService.saveLearnedMapping({
      fieldLabel: 'College Unique Identity',
      normalizedPattern: 'college unique identity',
      targetProperty: 'btech.prn',
      userConfirmed: true,
      domainScope: undefined, // Global
    });

    const learnedRules = await StorageService.getLearnedMappings();
    expect(learnedRules.some((r) => r.normalizedPattern === 'college unique identity')).toBe(true);

    // Map the unusual field
    const res = MappingEngine.mapField(
      { label: 'College Unique Identity', type: 'text' },
      customProfile,
      learnedRules
    );

    expect(res?.targetProperty).toBe('btech.prn');
    expect(res?.value).toBe('SPECIAL_PRN_999');
    expect(res?.reason).toContain('Learned user mapping rule');
  });
});
