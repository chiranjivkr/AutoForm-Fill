import { describe, it, expect, beforeEach } from 'vitest';
import { StorageService } from '../storage/storage';
import { MappingEngine } from '../services/mappingEngine';
import { UserProfile, defaultProfile, CustomProfileField } from '../types/profile';

describe('Adaptive Personal Profile Schema - Custom Profile Fields', () => {
  beforeEach(async () => {
    // Clean test state before each run
    await StorageService.clearAllData();
  });

  it('Requirement 1 & 2: Custom Profile Fields support Add, Read, Update, and Delete in StorageService', async () => {
    const profileA: UserProfile = {
      ...defaultProfile,
      id: 'prof_test_user_1',
      name: 'User One',
      customFields: [],
    };
    await StorageService.saveProfile(profileA);
    await StorageService.setActiveProfileId('prof_test_user_1');

    // 1. Add Custom Field
    const addedField = await StorageService.addCustomField('prof_test_user_1', {
      title: 'University Registration Number',
      value: '2021BCSE042',
      category: 'Education',
      aliases: ['urn', 'reg no', 'univ roll'],
    });

    expect(addedField).toBeDefined();
    expect(addedField?.id).toBeDefined();
    expect(addedField?.title).toBe('University Registration Number');
    expect(addedField?.value).toBe('2021BCSE042');
    expect(addedField?.category).toBe('Education');
    expect(addedField?.aliases).toContain('urn');

    // 2. Read Custom Fields
    let customFields = await StorageService.getCustomFields('prof_test_user_1');
    expect(customFields.length).toBe(1);
    expect(customFields[0].title).toBe('University Registration Number');

    // 3. Update Custom Field
    const updated = await StorageService.updateCustomField('prof_test_user_1', addedField!.id, {
      value: '2021BCSE042-UPDATED',
      category: 'Identification',
    });
    expect(updated).toBe(true);

    customFields = await StorageService.getCustomFields('prof_test_user_1');
    expect(customFields[0].value).toBe('2021BCSE042-UPDATED');
    expect(customFields[0].category).toBe('Identification');

    // 4. Delete Custom Field
    const deleted = await StorageService.deleteCustomField('prof_test_user_1', addedField!.id);
    expect(deleted).toBe(true);

    customFields = await StorageService.getCustomFields('prof_test_user_1');
    expect(customFields.length).toBe(0);
  });

  it('Requirement 3: Individual User Profile Isolation - Custom fields never leak between profiles', async () => {
    const profileAlice: UserProfile = {
      ...defaultProfile,
      id: 'prof_alice',
      name: 'Alice Smith',
      customFields: [],
    };

    const profileBob: UserProfile = {
      ...defaultProfile,
      id: 'prof_bob',
      name: 'Bob Jones',
      customFields: [],
    };

    await StorageService.saveProfile(profileAlice);
    await StorageService.saveProfile(profileBob);

    // Add different custom fields to Alice and Bob
    await StorageService.addCustomField('prof_alice', {
      title: 'NCC Certificate',
      value: 'NCC-ALICE-A-GRADE',
      category: 'Certificates',
      aliases: ['ncc certificate'],
    });

    await StorageService.addCustomField('prof_bob', {
      title: 'Portfolio Website',
      value: 'https://bobjones.dev',
      category: 'Professional',
      aliases: ['portfolio url'],
    });

    const aliceFields = await StorageService.getCustomFields('prof_alice');
    const bobFields = await StorageService.getCustomFields('prof_bob');

    expect(aliceFields.length).toBe(1);
    expect(aliceFields[0].title).toBe('NCC Certificate');
    expect(aliceFields[0].value).toBe('NCC-ALICE-A-GRADE');

    expect(bobFields.length).toBe(1);
    expect(bobFields[0].title).toBe('Portfolio Website');
    expect(bobFields[0].value).toBe('https://bobjones.dev');

    // Alice's fields must not contain Bob's fields and vice versa
    expect(aliceFields.find((f) => f.title === 'Portfolio Website')).toBeUndefined();
    expect(bobFields.find((f) => f.title === 'NCC Certificate')).toBeUndefined();
  });

  it('Requirement 4: Smart Autofill Integration - Maps custom fields by exact title and aliases', () => {
    const profile: UserProfile = {
      ...defaultProfile,
      customFields: [
        {
          id: 'cf_ncc_101',
          title: "NCC 'C' Certificate",
          value: 'KA/2021/88719',
          category: 'Certificates',
          aliases: ['ncc cert', 'ncc cadet number', 'ncc certificate'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: 'cf_gate_rank',
          title: 'GATE Score',
          value: '745',
          category: 'Education',
          aliases: ['gate exam score', 'gate marks'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
    };

    // 1. Direct title match
    const matchByTitle = MappingEngine.mapField({ label: "NCC 'C' Certificate", type: 'text' }, profile);
    expect(matchByTitle).toBeDefined();
    expect(matchByTitle?.targetProperty).toBe('custom.cf_ncc_101');
    expect(matchByTitle?.value).toBe('KA/2021/88719');
    expect(matchByTitle?.confidence).toBeGreaterThanOrEqual(0.95);

    // 2. Alias match
    const matchByAlias = MappingEngine.mapField({ label: 'NCC Cadet Number', type: 'text' }, profile);
    expect(matchByAlias).toBeDefined();
    expect(matchByAlias?.targetProperty).toBe('custom.cf_ncc_101');
    expect(matchByAlias?.value).toBe('KA/2021/88719');

    // 3. Second custom field alias match
    const matchGate = MappingEngine.mapField({ label: 'GATE Exam Score (AIR/Marks)', type: 'number' }, profile);
    expect(matchGate).toBeDefined();
    expect(matchGate?.targetProperty).toBe('custom.cf_gate_rank');
    expect(matchGate?.value).toBe('745');
  });

  it('Requirement 4 & 8: Smart Autofill prevents false positives on unrelated fields', () => {
    const profile: UserProfile = {
      ...defaultProfile,
      customFields: [
        {
          id: 'cf_entrance_rank',
          title: 'State Entrance Rank',
          value: '1420',
          category: 'Education',
          aliases: ['cet rank', 'entrance exam rank'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
    };

    // Unrelated field with common words
    const unrelatedField1 = MappingEngine.mapField(
      { label: 'Describe your favorite hobbies or extra-curricular activities', type: 'textarea' },
      profile
    );
    expect(unrelatedField1).toBeNull();

    // Field containing "rank" in an unrelated context
    const unrelatedField2 = MappingEngine.mapField(
      { label: 'What is your current company hierarchy rank / designation?', type: 'text' },
      profile
    );
    expect(unrelatedField2).toBeNull();
  });

  it('Requirement 7: Correction-Based Learning stores and reuses custom field associations', async () => {
    const profile: UserProfile = {
      ...defaultProfile,
      customFields: [
        {
          id: 'cf_special_id',
          title: 'Special Student Enrollment Key',
          value: 'ENROLL-XYZ-2024',
          category: 'Identification',
          aliases: ['enrollment key'],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
    };

    // Teach FormPilot that an obscure portal label "Unique Institutional Token" maps to this custom field
    await StorageService.saveLearnedMapping({
      id: 'lm_test_custom_1',
      domain: 'recruitment.gov.in',
      formSignature: 'Government Recruitment Application',
      fieldLabel: 'Unique Institutional Token',
      fieldPath: 'txt_token_unique',
      targetProperty: 'custom.cf_special_id',
      confidence: 1.0,
      userVerified: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    const learnedRules = await StorageService.getLearnedMappings();

    const mapped = MappingEngine.mapField(
      { label: 'Unique Institutional Token', name: 'txt_token_unique', type: 'text' },
      profile,
      learnedRules
    );

    expect(mapped).toBeDefined();
    expect(mapped?.targetProperty).toBe('custom.cf_special_id');
    expect(mapped?.value).toBe('ENROLL-XYZ-2024');
    expect(mapped?.confidence).toBe(1.0);
  });

  it('Value retrieval: MappingEngine.getValueByPath correctly resolves custom.<id> and customFields.<id>', () => {
    const profile: UserProfile = {
      ...defaultProfile,
      customFields: [
        {
          id: 'cf_passport',
          title: 'Passport Number',
          value: 'J1234567',
          category: 'Identification',
          aliases: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
    };

    expect(MappingEngine.getValueByPath(profile, 'custom.cf_passport')).toBe('J1234567');
    expect(MappingEngine.getValueByPath(profile, 'customFields.cf_passport')).toBe('J1234567');
    expect(MappingEngine.getValueByPath(profile, 'custom.Passport Number')).toBe('J1234567');
    expect(MappingEngine.getValueByPath(profile, 'custom.non_existent_field')).toBe('');
  });
});
