import { useState, useEffect, useCallback } from 'react';
import { User, AuthSession, SignUpData, LoginCredentials, AuthResponse } from './types';
import { AuthService } from './authService';

export function useAuth() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let mounted = true;

    // Load initial session
    AuthService.getCurrentSession()
      .then((currSession) => {
        if (mounted) {
          setSession(currSession);
          setUser(currSession ? currSession.user : null);
          setLoading(false);
        }
      })
      .catch(() => {
        if (mounted) setLoading(false);
      });

    // Subscribe to session changes across all extension tabs/popups
    const unsubscribe = AuthService.onAuthStateChange((newSession) => {
      if (mounted) {
        setSession(newSession);
        setUser(newSession ? newSession.user : null);
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  const signIn = useCallback(async (credentials: LoginCredentials): Promise<AuthResponse> => {
    setLoading(true);
    const res = await AuthService.signIn(credentials);
    if (res.success && res.session) {
      setSession(res.session);
      setUser(res.user || null);
    }
    setLoading(false);
    return res;
  }, []);

  const signUp = useCallback(async (data: SignUpData): Promise<AuthResponse> => {
    setLoading(true);
    const res = await AuthService.signUp(data);
    if (res.success && res.session) {
      setSession(res.session);
      setUser(res.user || null);
    }
    setLoading(false);
    return res;
  }, []);

  const signOut = useCallback(async (): Promise<void> => {
    setLoading(true);
    await AuthService.signOut();
    setSession(null);
    setUser(null);
    setLoading(false);
  }, []);

  const resetPassword = useCallback(async (email: string): Promise<AuthResponse> => {
    return AuthService.resetPassword(email);
  }, []);

  const confirmPasswordReset = useCallback(
    async (token: string, newPassword: string): Promise<AuthResponse> => {
      return AuthService.confirmPasswordReset(token, newPassword);
    },
    []
  );

  return {
    user,
    session,
    isAuthenticated: !!session && !!user,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
    confirmPasswordReset,
  };
}
