import {
  User,
  StoredUserAccount,
  AuthSession,
  SignUpData,
  LoginCredentials,
  AuthResponse,
  LegacyMigrationStatus,
} from './types';
import { CryptoUtils } from './crypto';
import { getSupabaseClient, isSupabaseConfigured } from './supabaseClient';
import { UserProfile, defaultProfile } from '../types/profile';

const STORAGE_USERS_KEY = 'formpilot_users';
const STORAGE_SESSION_KEY = 'formpilot_auth_session';
const STORAGE_MIGRATION_KEY = 'formpilot_legacy_migrated';
const SESSION_DURATION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

type AuthListener = (session: AuthSession | null) => void;
const authListeners: Set<AuthListener> = new Set();

// Memory fallback for tests and non-extension environments
let memorySession: AuthSession | null = null;
let memoryUsers: Record<string, StoredUserAccount> = {};
let memoryMigration: LegacyMigrationStatus = { migrated: false };

const isChromeStorage = (): boolean => {
  return typeof chrome !== 'undefined' && !!chrome?.storage?.local;
};

async function getStorageItem<T>(key: string, defaultVal: T): Promise<T> {
  if (isChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (res) => {
        if (chrome.runtime.lastError || res[key] === undefined) {
          resolve(defaultVal);
        } else {
          resolve(res[key]);
        }
      });
    });
  }
  if (typeof localStorage !== 'undefined') {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultVal;
    } catch {
      return defaultVal;
    }
  }
  if (key === STORAGE_USERS_KEY) return (memoryUsers as any) || defaultVal;
  if (key === STORAGE_SESSION_KEY) return (memorySession as any) || defaultVal;
  if (key === STORAGE_MIGRATION_KEY) return (memoryMigration as any) || defaultVal;
  return defaultVal;
}

async function setStorageItem<T>(key: string, value: T): Promise<void> {
  if (isChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, () => resolve());
    });
  }
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage write error:', e);
    }
  }
  if (key === STORAGE_USERS_KEY) memoryUsers = (value as any) || {};
  if (key === STORAGE_SESSION_KEY) memorySession = (value as any) || null;
  if (key === STORAGE_MIGRATION_KEY) memoryMigration = (value as any) || { migrated: false };
}

async function removeStorageItem(key: string): Promise<void> {
  if (isChromeStorage()) {
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], () => resolve());
    });
  }
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.removeItem(key);
    } catch {}
  }
  if (key === STORAGE_USERS_KEY) memoryUsers = {};
  if (key === STORAGE_SESSION_KEY) memorySession = null;
  if (key === STORAGE_MIGRATION_KEY) memoryMigration = { migrated: false };
}

// Setup storage change listener for multi-view sync (Popup <-> Dashboard <-> Content)
if (isChromeStorage() && chrome.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes[STORAGE_SESSION_KEY]) {
      const newSession: AuthSession | null = changes[STORAGE_SESSION_KEY].newValue || null;
      notifyListeners(newSession);
    }
  });
} else if (typeof window !== 'undefined' && window.addEventListener) {
  window.addEventListener('storage', (event) => {
    if (event.key === STORAGE_SESSION_KEY) {
      try {
        const newSession = event.newValue ? JSON.parse(event.newValue) : null;
        notifyListeners(newSession);
      } catch {}
    }
  });
}

function notifyListeners(session: AuthSession | null) {
  authListeners.forEach((listener) => {
    try {
      listener(session);
    } catch (e) {
      console.error('Error in auth listener:', e);
    }
  });
}

export const AuthService = {
  /**
   * Validate email format
   */
  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  },

  /**
   * Register a new user account
   */
  async signUp(data: SignUpData): Promise<AuthResponse> {
    const name = data.name ? data.name.trim() : '';
    const email = data.email ? data.email.trim().toLowerCase() : '';
    const password = data.password || '';

    // Validation
    if (!name || name.length < 2) {
      return { success: false, error: 'Please enter a valid full name (at least 2 characters).' };
    }
    if (!this.isValidEmail(email)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }
    if (data.confirmPassword !== undefined && password !== data.confirmPassword) {
      return { success: false, error: 'Passwords do not match.' };
    }

    // Supabase Auth Integration (if configured)
    if (isSupabaseConfigured()) {
      const supabase = getSupabaseClient()!;
      const { data: supaData, error: supaErr } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { name },
        },
      });

      if (supaErr) {
        return { success: false, error: supaErr.message };
      }

      if (supaData.user) {
        const user: User = {
          id: supaData.user.id,
          email: supaData.user.email || email,
          name: (supaData.user.user_metadata?.name as string) || name,
          createdAt: supaData.user.created_at || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        const session: AuthSession = {
          user,
          token: supaData.session?.access_token || CryptoUtils.generateToken(),
          expiresAt: Date.now() + SESSION_DURATION_MS,
          provider: 'supabase',
        };

        await setStorageItem(STORAGE_SESSION_KEY, session);
        await this.initializeUserStorage(user);
        notifyListeners(session);
        return { success: true, user, session };
      }
    }

    // Local Cryptographic Auth Engine
    const users = await getStorageItem<Record<string, StoredUserAccount>>(STORAGE_USERS_KEY, {});

    // Duplicate email check
    const existing = Object.values(users).find((u) => u.email.toLowerCase() === email);
    if (existing) {
      return {
        success: false,
        error: 'An account with this email address already exists. Please log in instead.',
      };
    }

    // Hash password with unique salt
    const salt = CryptoUtils.generateSalt();
    const passwordHash = await CryptoUtils.hashPassword(password, salt);
    const userId = 'usr_' + CryptoUtils.generateUuid();
    const now = new Date().toISOString();

    const newUser: StoredUserAccount = {
      id: userId,
      email,
      name,
      passwordHash,
      salt,
      createdAt: now,
      updatedAt: now,
    };

    users[userId] = newUser;
    await setStorageItem(STORAGE_USERS_KEY, users);

    // Create session
    const sessionUser: User = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      createdAt: newUser.createdAt,
      updatedAt: newUser.updatedAt,
    };

    const session: AuthSession = {
      user: sessionUser,
      token: CryptoUtils.generateToken(),
      expiresAt: Date.now() + SESSION_DURATION_MS,
      provider: 'local',
    };

    await setStorageItem(STORAGE_SESSION_KEY, session);
    await this.initializeUserStorage(sessionUser);
    notifyListeners(session);

    return { success: true, user: sessionUser, session };
  },

  /**
   * Log in existing user
   */
  async signIn(credentials: LoginCredentials): Promise<AuthResponse> {
    const email = credentials.email ? credentials.email.trim().toLowerCase() : '';
    const password = credentials.password || '';

    if (!email || !password) {
      return { success: false, error: 'Email and password are required.' };
    }

    // Supabase Auth Integration
    if (isSupabaseConfigured()) {
      const supabase = getSupabaseClient()!;
      const { data: supaData, error: supaErr } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (supaErr) {
        return { success: false, error: supaErr.message };
      }

      if (supaData.user) {
        const user: User = {
          id: supaData.user.id,
          email: supaData.user.email || email,
          name: (supaData.user.user_metadata?.name as string) || email.split('@')[0],
          createdAt: supaData.user.created_at || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        const session: AuthSession = {
          user,
          token: supaData.session?.access_token || CryptoUtils.generateToken(),
          expiresAt: Date.now() + SESSION_DURATION_MS,
          provider: 'supabase',
        };

        await setStorageItem(STORAGE_SESSION_KEY, session);
        await this.initializeUserStorage(user);
        notifyListeners(session);
        return { success: true, user, session };
      }
    }

    // Local Cryptographic Auth Engine
    const users = await getStorageItem<Record<string, StoredUserAccount>>(STORAGE_USERS_KEY, {});
    const user = Object.values(users).find((u) => u.email.toLowerCase() === email);

    if (!user) {
      return { success: false, error: 'Invalid email or password.' };
    }

    const isValid = await CryptoUtils.verifyPassword(password, user.salt, user.passwordHash);
    if (!isValid) {
      return { success: false, error: 'Invalid email or password.' };
    }

    const sessionUser: User = {
      id: user.id,
      email: user.email,
      name: user.name,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };

    const session: AuthSession = {
      user: sessionUser,
      token: CryptoUtils.generateToken(),
      expiresAt: Date.now() + SESSION_DURATION_MS,
      provider: 'local',
    };

    await setStorageItem(STORAGE_SESSION_KEY, session);
    await this.initializeUserStorage(sessionUser);
    notifyListeners(session);

    return { success: true, user: sessionUser, session };
  },

  /**
   * Log out active session
   */
  async signOut(): Promise<void> {
    if (isSupabaseConfigured()) {
      try {
        const supabase = getSupabaseClient()!;
        await supabase.auth.signOut();
      } catch (e) {
        console.warn('Supabase signOut error:', e);
      }
    }

    await removeStorageItem(STORAGE_SESSION_KEY);
    notifyListeners(null);
  },

  /**
   * Get currently active session if valid
   */
  async getCurrentSession(): Promise<AuthSession | null> {
    const session = await getStorageItem<AuthSession | null>(STORAGE_SESSION_KEY, null);
    if (!session) return null;

    if (Date.now() > session.expiresAt) {
      // Session has expired
      await removeStorageItem(STORAGE_SESSION_KEY);
      notifyListeners(null);
      return null;
    }

    return session;
  },

  /**
   * Get current authenticated user
   */
  async getCurrentUser(): Promise<User | null> {
    const session = await this.getCurrentSession();
    return session ? session.user : null;
  },

  /**
   * Get current authenticated user ID
   */
  async getCurrentUserId(): Promise<string | null> {
    const session = await this.getCurrentSession();
    return session ? session.user.id : null;
  },

  /**
   * Send password reset request
   */
  async resetPassword(email: string): Promise<AuthResponse> {
    const cleanEmail = email ? email.trim().toLowerCase() : '';
    if (!this.isValidEmail(cleanEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    if (isSupabaseConfigured()) {
      const supabase = getSupabaseClient()!;
      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail);
      if (error) {
        return { success: false, error: error.message };
      }
      return {
        success: true,
        message: 'Password reset link sent! Check your inbox for instructions.',
      };
    }

    const users = await getStorageItem<Record<string, StoredUserAccount>>(STORAGE_USERS_KEY, {});
    const user = Object.values(users).find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      // Return clear error as required
      return { success: false, error: 'No account registered with this email address.' };
    }

    // Generate 6-digit cryptographic verification code
    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    user.resetToken = resetCode;
    user.resetExpires = Date.now() + 15 * 60 * 1000; // 15 minutes validity
    user.updatedAt = new Date().toISOString();

    users[user.id] = user;
    await setStorageItem(STORAGE_USERS_KEY, users);

    return {
      success: true,
      resetToken: resetCode,
      message: `Reset code generated: ${resetCode}. Use this code to reset your password within 15 minutes.`,
    };
  },

  /**
   * Confirm password reset with token/code
   */
  async confirmPasswordReset(token: string, newPassword: string): Promise<AuthResponse> {
    const cleanToken = token ? token.trim() : '';
    if (!cleanToken) {
      return { success: false, error: 'Reset code is required.' };
    }
    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'New password must be at least 6 characters long.' };
    }

    const users = await getStorageItem<Record<string, StoredUserAccount>>(STORAGE_USERS_KEY, {});
    const user = Object.values(users).find(
      (u) => u.resetToken === cleanToken && u.resetExpires && u.resetExpires > Date.now()
    );

    if (!user) {
      return { success: false, error: 'Invalid or expired password reset code. Please request a new one.' };
    }

    // Hash new password with fresh salt
    const salt = CryptoUtils.generateSalt();
    const passwordHash = await CryptoUtils.hashPassword(newPassword, salt);

    user.passwordHash = passwordHash;
    user.salt = salt;
    delete user.resetToken;
    delete user.resetExpires;
    user.updatedAt = new Date().toISOString();

    users[user.id] = user;
    await setStorageItem(STORAGE_USERS_KEY, users);

    return {
      success: true,
      message: 'Password successfully updated! You can now log in with your new password.',
    };
  },

  /**
   * Subscribes to authentication state changes across the extension
   */
  onAuthStateChange(listener: AuthListener): () => void {
    authListeners.add(listener);
    return () => {
      authListeners.delete(listener);
    };
  },

  /**
   * Initializes user storage upon registration or login.
   * If fresh user: creates isolated empty profile.
   * Safe migration: If legacy unmigrated data exists, safely associates with first user only.
   */
  async initializeUserStorage(user: User): Promise<void> {
    const userStorageKey = `user_data_${user.id}`;

    // Check if user already has data stored
    let existingUserData: any = null;
    if (isChromeStorage()) {
      existingUserData = await new Promise((resolve) => {
        chrome.storage.local.get([userStorageKey], (res) => resolve(res[userStorageKey]));
      });
    } else if (typeof localStorage !== 'undefined') {
      try {
        const raw = localStorage.getItem(userStorageKey);
        if (raw) existingUserData = JSON.parse(raw);
      } catch {}
    }

    if (existingUserData && existingUserData.profiles && existingUserData.profiles.length > 0) {
      // User data already properly initialized
      return;
    }

    // Check for legacy unassociated data
    const migrationStatus = await getStorageItem<LegacyMigrationStatus>(STORAGE_MIGRATION_KEY, {
      migrated: false,
    });

    let legacyData: any = null;
    if (!migrationStatus.migrated) {
      if (isChromeStorage()) {
        legacyData = await new Promise((resolve) => {
          chrome.storage.local.get(null, (res) => {
            if (res && res.profiles && Array.isArray(res.profiles) && res.profiles.length > 0) {
              resolve(res);
            } else {
              resolve(null);
            }
          });
        });
      } else if (typeof localStorage !== 'undefined') {
        try {
          const raw = localStorage.getItem('formpilot_storage');
          if (raw) legacyData = JSON.parse(raw);
        } catch {}
      }
    }

    // Only migrate legacy data if it has real user customizations and is the first user
    const hasMeaningfulLegacy =
      legacyData &&
      legacyData.profiles &&
      legacyData.profiles.some(
        (p: any) =>
          p.personal?.fullName ||
          (p.personal?.email && p.personal.email.toLowerCase() === user.email.toLowerCase()) ||
          (p.customFields && p.customFields.length > 0) ||
          (legacyData.applications && legacyData.applications.length > 0)
      );

    if (hasMeaningfulLegacy && !migrationStatus.migrated) {
      // Safely migrate to this first user account
      const migratedProfiles = legacyData.profiles.map((p: any) => ({
        ...p,
        personal: {
          ...p.personal,
          fullName: p.personal?.fullName || user.name,
          email: p.personal?.email || user.email,
        },
      }));

      const newUserData = {
        profiles: migratedProfiles,
        activeProfileId: legacyData.activeProfileId || migratedProfiles[0]?.id || 'default',
        jobProfiles: legacyData.jobProfiles || [],
        activeJobProfileId: legacyData.activeJobProfileId || '',
        applications: legacyData.applications || [],
        learnedMappings: legacyData.learnedMappings || [],
        aiSettings: legacyData.aiSettings || { provider: 'rule-based', apiKey: '', enabled: true },
        settings: legacyData.settings || { autoDetect: true, showFieldHelper: true, notifyOnFill: true },
      };

      await setStorageItem(userStorageKey, newUserData);

      // Mark legacy data as migrated so NO other account will ever inherit it
      await setStorageItem(STORAGE_MIGRATION_KEY, {
        migrated: true,
        migratedToUserId: user.id,
        migratedAt: new Date().toISOString(),
      });

      // Safely remove legacy root keys to prevent accidental leakage
      if (isChromeStorage()) {
        chrome.storage.local.remove([
          'profiles',
          'activeProfileId',
          'jobProfiles',
          'activeJobProfileId',
          'applications',
          'learnedMappings',
          'aiSettings',
          'settings',
        ]);
      } else if (typeof localStorage !== 'undefined') {
        localStorage.removeItem('formpilot_storage');
      }

      return;
    }

    // Otherwise: Initialize an independent, empty profile for this account
    const fullName = user.name || '';
    const firstName = fullName ? fullName.split(' ')[0] : '';
    const lastName = fullName ? fullName.split(' ').slice(1).join(' ') : '';

    const initialProfile: UserProfile = {
      ...JSON.parse(JSON.stringify(defaultProfile)),
      id: `prof_${user.id}`,
      name: 'Primary Profile',
      updatedAt: new Date().toISOString(),
      personal: {
        ...defaultProfile.personal,
        fullName,
        firstName,
        lastName,
        email: user.email || '',
        phoneNumber: '',
        whatsappNumber: '',
        currentLocation: '',
        linkedin: '',
        github: '',
        portfolio: '',
      },
      class10: {
        board: '',
        school: '',
        passingYear: '',
        percentage: '',
      },
      class12: {
        qualificationType: '12th',
        boardOrInstitution: '',
        stream: '',
        passingYear: '',
        percentage: '',
      },
      btech: {
        degree: 'B.Tech',
        branch: '',
        college: '',
        passingYear: '',
        cgpa: '',
        activeBacklogs: '0',
        deadBacklogs: '0',
        prn: '',
      },
      higherEducation: [],
      skills: [],
      experiences: [],
      projects: [],
      customAnswers: JSON.parse(JSON.stringify(defaultProfile.customAnswers)),
      customFields: [],
    };

    const emptyUserData = {
      profiles: [initialProfile],
      activeProfileId: initialProfile.id,
      jobProfiles: [],
      activeJobProfileId: '',
      applications: [],
      learnedMappings: [],
      aiSettings: {
        provider: 'rule-based',
        apiKey: '',
        enabled: true,
      },
      settings: {
        autoDetect: true,
        showFieldHelper: true,
        notifyOnFill: true,
      },
    };

    await setStorageItem(userStorageKey, emptyUserData);
  },

  /**
   * Helper for testing: clears all user accounts, sessions, and migration flags
   */
  async _resetAuthForTesting(): Promise<void> {
    await removeStorageItem(STORAGE_USERS_KEY);
    await removeStorageItem(STORAGE_SESSION_KEY);
    await removeStorageItem(STORAGE_MIGRATION_KEY);
    memoryUsers = {};
    memorySession = null;
    memoryMigration = { migrated: false };
    notifyListeners(null);
  },
};
