export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface StoredUserAccount extends User {
  passwordHash: string;
  salt: string;
  resetToken?: string;
  resetExpires?: number;
}

export interface AuthSession {
  user: User;
  token: string;
  expiresAt: number;
  provider: 'local' | 'supabase';
}

export interface SignUpData {
  name: string;
  email: string;
  password: string;
  confirmPassword?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  user?: User;
  session?: AuthSession;
  error?: string;
  message?: string;
  resetToken?: string;
}

export interface LegacyMigrationStatus {
  migrated: boolean;
  migratedToUserId?: string;
  migratedAt?: string;
}
