/**
 * Web Crypto utilities for secure password hashing and token generation.
 * PBKDF2 with SHA-256, 100,000 iterations, and unique cryptographic salt per user.
 * Plain-text passwords are NEVER stored.
 */

function getCrypto(): Crypto {
  if (typeof globalThis !== 'undefined' && globalThis.crypto) {
    return globalThis.crypto;
  }
  if (typeof window !== 'undefined' && window.crypto) {
    return window.crypto;
  }
  throw new Error('Web Crypto API is not available in this environment');
}

function bufferToHex(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBuffer(hex: string): Uint8Array {
  const match = hex.match(/.{1,2}/g);
  if (!match) return new Uint8Array(0);
  return new Uint8Array(match.map((byte) => parseInt(byte, 16)));
}

export const CryptoUtils = {
  /**
   * Generates a 16-byte random salt in hex representation.
   */
  generateSalt(): string {
    const cryptoObj = getCrypto();
    const array = new Uint8Array(16);
    cryptoObj.getRandomValues(array);
    return bufferToHex(array);
  },

  /**
   * Generates a secure random session/reset token.
   */
  generateToken(): string {
    const cryptoObj = getCrypto();
    const array = new Uint8Array(32);
    cryptoObj.getRandomValues(array);
    return bufferToHex(array);
  },

  /**
   * Generates a standard UUID v4.
   */
  generateUuid(): string {
    const cryptoObj = getCrypto();
    if (typeof cryptoObj.randomUUID === 'function') {
      return cryptoObj.randomUUID();
    }
    const array = new Uint8Array(16);
    cryptoObj.getRandomValues(array);
    // RFC4122 v4
    array[6] = (array[6] & 0x0f) | 0x40;
    array[8] = (array[8] & 0x3f) | 0x80;
    const hex = bufferToHex(array);
    return `${hex.substring(0, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20, 32)}`;
  },

  /**
   * Securely hashes a password using PBKDF2 with SHA-256 and salt.
   */
  async hashPassword(password: string, saltHex: string): Promise<string> {
    const cryptoObj = getCrypto();
    const encoder = new TextEncoder();
    const passwordBuffer = encoder.encode(password);
    const saltBuffer = hexToBuffer(saltHex);

    const baseKey = await cryptoObj.subtle.importKey(
      'raw',
      passwordBuffer,
      { name: 'PBKDF2' },
      false,
      ['deriveBits']
    );

    const derivedBits = await cryptoObj.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt: saltBuffer as any,
        iterations: 100000,
        hash: 'SHA-256',
      },
      baseKey,
      256
    );

    return bufferToHex(derivedBits);
  },

  /**
   * Constant-time comparison between input password and stored hash.
   */
  async verifyPassword(password: string, saltHex: string, expectedHash: string): Promise<boolean> {
    const computedHash = await this.hashPassword(password, saltHex);
    if (computedHash.length !== expectedHash.length) {
      return false;
    }
    let diff = 0;
    for (let i = 0; i < computedHash.length; i++) {
      diff |= computedHash.charCodeAt(i) ^ expectedHash.charCodeAt(i);
    }
    return diff === 0;
  },
};
