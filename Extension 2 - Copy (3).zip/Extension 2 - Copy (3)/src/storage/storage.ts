import { UserProfile, defaultProfile, JobProfile } from '../types/profile';
import { JobApplication } from '../types/tracker';
import { LearnedMapping } from '../types/learning';
import { AISettings } from '../types/ai';
import { AuthService } from '../auth/authService';

export interface StorageData {
  profiles: UserProfile[];
  activeProfileId: string;
  jobProfiles: JobProfile[];
  activeJobProfileId: string;
  applications: JobApplication[];
  learnedMappings: LearnedMapping[];
  aiSettings: AISettings;
  settings: {
    autoDetect: boolean;
    showFieldHelper: boolean;
    notifyOnFill: boolean;
  };
}

export const defaultStorageData: StorageData = {
  profiles: [defaultProfile],
  activeProfileId: 'default',
  jobProfiles: [],
  activeJobProfileId: '',
  applications: [],
  learnedMappings: [],
  aiSettings: {
    provider: 'rule-based',
    apiKey: '',
    enabled: true,
  },
  settings: {
    autoDetect: true,
    showFieldHelper: true,
    notifyOnFill: true,
  },
};

// In-memory cache partitioned strictly by user ID to avoid cross-user data leakage
const userMemoryCache: Map<string, StorageData> = new Map();

// Clear memory cache automatically upon logout to prevent any sensitive data leakage
AuthService.onAuthStateChange((session) => {
  if (!session) {
    userMemoryCache.clear();
  }
});

const isChromeStorageAvailable = (): boolean => {
  return typeof chrome !== 'undefined' && !!chrome?.storage?.local;
};

async function resolveUserId(explicitUserId?: string): Promise<string> {
  if (explicitUserId) return explicitUserId;
  const currentUserId = await AuthService.getCurrentUserId();
  return currentUserId || 'default_local_user';
}

function getUserKey(userId: string): string {
  return `user_data_${userId}`;
}

export function sanitizeProfile(raw: any): UserProfile {
  const def: UserProfile = JSON.parse(JSON.stringify(defaultProfile));
  if (!raw || typeof raw !== 'object') {
    return def;
  }

  const rawPersonal = raw.personal || {};
  const rawEducation = raw.education || {};
  const rawClass10 = raw.class10 || rawEducation.tenth || {};
  const rawClass12 = raw.class12 || rawEducation.twelfth || rawEducation.diploma || {};
  const rawBtech = raw.btech || rawEducation.btech || rawEducation.graduation || {};

  const fullName =
    typeof rawPersonal.fullName === 'string'
      ? rawPersonal.fullName
      : typeof raw.name === 'string'
      ? raw.name
      : '';
  const firstName =
    typeof rawPersonal.firstName === 'string'
      ? rawPersonal.firstName
      : fullName
      ? fullName.split(' ')[0]
      : '';
  const lastName =
    typeof rawPersonal.lastName === 'string'
      ? rawPersonal.lastName
      : fullName
      ? fullName.split(' ').slice(1).join(' ')
      : '';

  return {
    id: raw.id || def.id,
    name: raw.name || def.name,
    updatedAt: raw.updatedAt || new Date().toISOString(),
    personal: {
      fullName,
      firstName,
      lastName,
      email: typeof rawPersonal.email === 'string' ? rawPersonal.email : '',
      phoneNumber:
        typeof rawPersonal.phoneNumber === 'string'
          ? rawPersonal.phoneNumber
          : typeof rawPersonal.phone === 'string'
          ? rawPersonal.phone
          : '',
      whatsappNumber: typeof rawPersonal.whatsappNumber === 'string' ? rawPersonal.whatsappNumber : '',
      currentLocation:
        typeof rawPersonal.currentLocation === 'string'
          ? rawPersonal.currentLocation
          : typeof rawPersonal.address === 'string'
          ? rawPersonal.address
          : '',
      linkedin:
        typeof rawPersonal.linkedin === 'string'
          ? rawPersonal.linkedin
          : typeof rawPersonal.linkedinUrl === 'string'
          ? rawPersonal.linkedinUrl
          : '',
      github:
        typeof rawPersonal.github === 'string'
          ? rawPersonal.github
          : typeof rawPersonal.githubUrl === 'string'
          ? rawPersonal.githubUrl
          : '',
      portfolio:
        typeof rawPersonal.portfolio === 'string'
          ? rawPersonal.portfolio
          : typeof rawPersonal.portfolioUrl === 'string'
          ? rawPersonal.portfolioUrl
          : '',
      summary:
        typeof rawPersonal.summary === 'string'
          ? rawPersonal.summary
          : typeof raw.summary === 'string'
          ? raw.summary
          : '',
    },
    class10: {
      board: rawClass10.board || '',
      school: rawClass10.school || rawClass10.schoolName || '',
      passingYear: rawClass10.passingYear || '',
      percentage: rawClass10.percentage || rawClass10.percentageOrCgpa || '',
    },
    class12: {
      qualificationType:
        rawClass12.qualificationType === 'Diploma' || rawEducation.diploma?.collegeName ? 'Diploma' : '12th',
      boardOrInstitution:
        rawClass12.boardOrInstitution ||
        rawClass12.board ||
        rawClass12.school ||
        rawClass12.schoolName ||
        rawClass12.collegeName ||
        '',
      stream: rawClass12.stream || '',
      passingYear: rawClass12.passingYear || '',
      percentage: rawClass12.percentage || rawClass12.percentageOrCgpa || '',
    },
    btech: {
      degree: rawBtech.degree || def.btech.degree,
      branch: rawBtech.branch || '',
      college: rawBtech.college || '',
      passingYear: rawBtech.passingYear || '',
      cgpa: rawBtech.cgpa || '',
      activeBacklogs: rawBtech.activeBacklogs || '0',
      deadBacklogs: rawBtech.deadBacklogs || '0',
      prn: rawBtech.prn || '',
    },
    higherEducation: Array.isArray(raw.higherEducation)
      ? raw.higherEducation
      : Array.isArray(rawEducation.higherEducation)
      ? rawEducation.higherEducation
      : [],
    skills: Array.isArray(raw.skills) ? raw.skills : [],
    experiences: Array.isArray(raw.experiences)
      ? raw.experiences
      : Array.isArray(raw.workExperience)
      ? raw.workExperience
      : [],
    projects: Array.isArray(raw.projects) ? raw.projects : [],
    certifications: Array.isArray(raw.certifications) ? raw.certifications : [],
    achievements: Array.isArray(raw.achievements) ? raw.achievements : [],
    customAnswers:
      Array.isArray(raw.customAnswers) && raw.customAnswers.length > 0
        ? raw.customAnswers
        : def.customAnswers,
    customFields: Array.isArray(raw.customFields) ? raw.customFields : [],
  };
}

export function sanitizeProfiles(rawProfiles: any[]): UserProfile[] {
  if (!rawProfiles || !Array.isArray(rawProfiles) || rawProfiles.length === 0) {
    return [JSON.parse(JSON.stringify(defaultProfile))];
  }
  return rawProfiles.map((p) => sanitizeProfile(p));
}

export const StorageService = {
  /**
   * Resolves currently active user ID
   */
  async getActiveUserId(): Promise<string> {
    return resolveUserId();
  },

  /**
   * Clears the in-memory cache across all accounts
   */
  clearMemoryCache(): void {
    userMemoryCache.clear();
  },

  /**
   * Retrieves full storage state for the authenticated user
   */
  async getAll(explicitUserId?: string): Promise<StorageData> {
    const userId = await resolveUserId(explicitUserId);
    const userKey = getUserKey(userId);

    if (isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.get([userKey], (result) => {
          if (chrome.runtime.lastError) {
            console.warn('Chrome storage read error:', chrome.runtime.lastError);
            const cached = userMemoryCache.get(userId) || JSON.parse(JSON.stringify(defaultStorageData));
            resolve(cached);
            return;
          }

          const raw = result[userKey];
          if (!raw) {
            // Check memory cache or initialize default
            if (userMemoryCache.has(userId)) {
              resolve(userMemoryCache.get(userId)!);
              return;
            }
            const freshDefault: StorageData = JSON.parse(JSON.stringify(defaultStorageData));
            userMemoryCache.set(userId, freshDefault);
            resolve(freshDefault);
            return;
          }

          const sanitized: StorageData = {
            profiles: sanitizeProfiles(raw.profiles),
            activeProfileId: raw.activeProfileId || raw.profiles?.[0]?.id || 'default',
            jobProfiles: raw.jobProfiles || [],
            activeJobProfileId: raw.activeJobProfileId || '',
            applications: raw.applications || [],
            learnedMappings: raw.learnedMappings || [],
            aiSettings: { ...defaultStorageData.aiSettings, ...(raw.aiSettings || {}) },
            settings: { ...defaultStorageData.settings, ...(raw.settings || {}) },
          };

          userMemoryCache.set(userId, sanitized);
          resolve(sanitized);
        });
      });
    }

    // LocalStorage or Memory Fallback (Vitest / local preview)
    if (typeof localStorage !== 'undefined') {
      try {
        const rawStr = localStorage.getItem(userKey);
        if (rawStr) {
          const parsed = JSON.parse(rawStr);
          const sanitized: StorageData = {
            profiles: sanitizeProfiles(parsed.profiles),
            activeProfileId: parsed.activeProfileId || parsed.profiles?.[0]?.id || 'default',
            jobProfiles: parsed.jobProfiles || [],
            activeJobProfileId: parsed.activeJobProfileId || '',
            applications: parsed.applications || [],
            learnedMappings: parsed.learnedMappings || [],
            aiSettings: { ...defaultStorageData.aiSettings, ...(parsed.aiSettings || {}) },
            settings: { ...defaultStorageData.settings, ...(parsed.settings || {}) },
          };
          userMemoryCache.set(userId, sanitized);
          return sanitized;
        }
      } catch (e) {
        console.warn('LocalStorage read error:', e);
      }
    }

    const cached = userMemoryCache.get(userId) || JSON.parse(JSON.stringify(defaultStorageData));
    userMemoryCache.set(userId, cached);
    return cached;
  },

  /**
   * Persists partial or full storage state strictly for the authenticated user
   */
  async saveAll(data: Partial<StorageData>, explicitUserId?: string): Promise<void> {
    const userId = await resolveUserId(explicitUserId);
    const userKey = getUserKey(userId);
    const existing = await this.getAll(userId);

    const merged: StorageData = {
      ...existing,
      ...data,
      profiles: data.profiles ? sanitizeProfiles(data.profiles) : existing.profiles,
      aiSettings: data.aiSettings ? { ...existing.aiSettings, ...data.aiSettings } : existing.aiSettings,
      settings: data.settings ? { ...existing.settings, ...data.settings } : existing.settings,
    };

    userMemoryCache.set(userId, merged);

    if (isChromeStorageAvailable()) {
      return new Promise((resolve, reject) => {
        chrome.storage.local.set({ [userKey]: merged }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }

    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(userKey, JSON.stringify(merged));
      } catch (e) {
        console.warn('LocalStorage save error:', e);
      }
    }
  },

  /**
   * Get active profile of the current authenticated user
   */
  async getActiveProfile(explicitUserId?: string): Promise<UserProfile> {
    const data = await this.getAll(explicitUserId);
    const active = data.profiles.find((p) => p.id === data.activeProfileId);
    const profile = active || data.profiles[0] || defaultProfile;
    return sanitizeProfile(profile);
  },

  /**
   * Set active profile ID for the current authenticated user
   */
  async setActiveProfileId(id: string, explicitUserId?: string): Promise<void> {
    await this.saveAll({ activeProfileId: id }, explicitUserId);
  },

  /**
   * Save or update a profile for the current authenticated user
   */
  async saveProfile(profile: UserProfile, explicitUserId?: string): Promise<void> {
    const data = await this.getAll(explicitUserId);
    const cleanProfile: UserProfile = sanitizeProfile(profile);
    const index = data.profiles.findIndex((p) => p.id === cleanProfile.id);
    let updatedProfiles: UserProfile[];

    if (index >= 0) {
      updatedProfiles = [...data.profiles];
      updatedProfiles[index] = { ...cleanProfile, updatedAt: new Date().toISOString() };
    } else {
      updatedProfiles = [...data.profiles, { ...cleanProfile, updatedAt: new Date().toISOString() }];
    }

    await this.saveAll({ profiles: updatedProfiles, activeProfileId: cleanProfile.id }, explicitUserId);
  },

  /**
   * Get custom fields for a specific profile (or active profile)
   */
  async getCustomFields(
    profileId?: string,
    explicitUserId?: string
  ): Promise<import('../types/profile').CustomProfileField[]> {
    const data = await this.getAll(explicitUserId);
    const targetId = profileId || data.activeProfileId;
    const targetProfile = data.profiles.find((p) => p.id === targetId) || data.profiles[0];
    return targetProfile?.customFields || [];
  },

  /**
   * Add a custom profile field to a profile of the authenticated user
   */
  async addCustomField(
    profileId: string,
    field: Omit<import('../types/profile').CustomProfileField, 'id' | 'createdAt' | 'updatedAt'>,
    explicitUserId?: string
  ): Promise<import('../types/profile').CustomProfileField> {
    const data = await this.getAll(explicitUserId);
    const pIndex = data.profiles.findIndex((p) => p.id === profileId);
    if (pIndex < 0) throw new Error('Profile not found: ' + profileId);

    const now = new Date().toISOString();
    const newField: import('../types/profile').CustomProfileField = {
      ...field,
      id: 'cf_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: now,
      updatedAt: now,
    };

    const target = data.profiles[pIndex];
    const currentFields = Array.isArray(target.customFields) ? target.customFields : [];
    target.customFields = [...currentFields, newField];
    target.updatedAt = now;

    await this.saveAll({ profiles: data.profiles }, explicitUserId);
    return newField;
  },

  /**
   * Update an existing custom field
   */
  async updateCustomField(
    profileId: string,
    fieldOrId: string | import('../types/profile').CustomProfileField,
    updates?: Partial<import('../types/profile').CustomProfileField>,
    explicitUserId?: string
  ): Promise<boolean> {
    const data = await this.getAll(explicitUserId);
    const pIndex = data.profiles.findIndex((p) => p.id === profileId);
    if (pIndex < 0) return false;

    const target = data.profiles[pIndex];
    const currentFields = Array.isArray(target.customFields) ? [...target.customFields] : [];
    const targetId = typeof fieldOrId === 'string' ? fieldOrId : fieldOrId.id;
    const fIndex = currentFields.findIndex((f) => f.id === targetId);

    if (fIndex < 0) return false;

    const existing = currentFields[fIndex];
    const merged: import('../types/profile').CustomProfileField =
      typeof fieldOrId === 'string'
        ? { ...existing, ...(updates || {}), updatedAt: new Date().toISOString() }
        : { ...existing, ...fieldOrId, ...(updates || {}), updatedAt: new Date().toISOString() };

    currentFields[fIndex] = merged;
    target.customFields = currentFields;
    target.updatedAt = new Date().toISOString();

    await this.saveAll({ profiles: data.profiles }, explicitUserId);
    return true;
  },

  /**
   * Delete a custom field
   */
  async deleteCustomField(
    profileId: string,
    fieldId: string,
    explicitUserId?: string
  ): Promise<boolean> {
    const data = await this.getAll(explicitUserId);
    const pIndex = data.profiles.findIndex((p) => p.id === profileId);
    if (pIndex < 0) return false;

    const target = data.profiles[pIndex];
    if (Array.isArray(target.customFields)) {
      const prevLen = target.customFields.length;
      target.customFields = target.customFields.filter((f) => f.id !== fieldId);
      if (target.customFields.length !== prevLen) {
        target.updatedAt = new Date().toISOString();
        await this.saveAll({ profiles: data.profiles }, explicitUserId);
        return true;
      }
    }
    return false;
  },

  /**
   * Get job applications for authenticated user
   */
  async getApplications(explicitUserId?: string): Promise<JobApplication[]> {
    const data = await this.getAll(explicitUserId);
    return data.applications || [];
  },

  /**
   * Save a job application for authenticated user
   */
  async saveApplication(app: JobApplication, explicitUserId?: string): Promise<void> {
    const data = await this.getAll(explicitUserId);
    const index = data.applications.findIndex((a) => a.id === app.id);
    let updated: JobApplication[];

    if (index >= 0) {
      updated = [...data.applications];
      updated[index] = { ...app, updatedAt: new Date().toISOString() };
    } else {
      updated = [
        ...data.applications,
        { ...app, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      ];
    }

    await this.saveAll({ applications: updated }, explicitUserId);
  },

  /**
   * Delete an application
   */
  async deleteApplication(id: string, explicitUserId?: string): Promise<void> {
    const data = await this.getAll(explicitUserId);
    const updated = data.applications.filter((a) => a.id !== id);
    await this.saveAll({ applications: updated }, explicitUserId);
  },

  /**
   * Get learned mappings for authenticated user
   */
  async getLearnedMappings(explicitUserId?: string): Promise<LearnedMapping[]> {
    const data = await this.getAll(explicitUserId);
    return data.learnedMappings || [];
  },

  /**
   * Save learned mapping for authenticated user
   */
  async saveLearnedMapping(
    mapping: Partial<LearnedMapping> & { targetProperty: string },
    explicitUserId?: string
  ): Promise<void> {
    const data = await this.getAll(explicitUserId);
    const normPattern =
      mapping.normalizedPattern ||
      (mapping.fieldLabel
        ? mapping.fieldLabel
            .toLowerCase()
            .replace(/[\*\:\?\!\#\(\)\[\]\{\}\_\-\/\\]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
        : '');

    const existingIndex = data.learnedMappings.findIndex(
      (m) =>
        (m.normalizedPattern === normPattern || (mapping.fieldLabel && m.fieldLabel === mapping.fieldLabel)) &&
        (!mapping.domainScope || m.domainScope === mapping.domainScope)
    );

    let updated: LearnedMapping[];
    if (existingIndex >= 0) {
      updated = [...data.learnedMappings];
      updated[existingIndex] = {
        ...updated[existingIndex],
        ...mapping,
        normalizedPattern: normPattern || updated[existingIndex].normalizedPattern,
        targetProperty: mapping.targetProperty,
        userConfirmed: true,
        timesApplied: (updated[existingIndex].timesApplied || 0) + 1,
        lastUsedAt: new Date().toISOString(),
      };
    } else {
      const newRule: LearnedMapping = {
        id: mapping.id || 'rule_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        fieldLabel: mapping.fieldLabel || '',
        normalizedPattern: normPattern,
        domainScope: mapping.domainScope || mapping.domain,
        domain: mapping.domain,
        formSignature: mapping.formSignature,
        fieldPath: mapping.fieldPath,
        confidence: mapping.confidence ?? 1.0,
        userVerified: mapping.userVerified ?? true,
        targetProperty: mapping.targetProperty,
        userConfirmed: mapping.userConfirmed ?? true,
        timesApplied: 1,
        lastUsedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      updated = [...data.learnedMappings, newRule];
    }

    await this.saveAll({ learnedMappings: updated }, explicitUserId);
  },

  /**
   * Delete learned mapping
   */
  async deleteLearnedMapping(id: string, explicitUserId?: string): Promise<void> {
    const data = await this.getAll(explicitUserId);
    const updated = data.learnedMappings.filter((m) => m.id !== id);
    await this.saveAll({ learnedMappings: updated }, explicitUserId);
  },

  /**
   * Get AI settings for authenticated user
   */
  async getAISettings(explicitUserId?: string): Promise<AISettings> {
    const data = await this.getAll(explicitUserId);
    return data.aiSettings;
  },

  /**
   * Save AI settings for authenticated user
   */
  async saveAISettings(settings: AISettings, explicitUserId?: string): Promise<void> {
    await this.saveAll({ aiSettings: settings }, explicitUserId);
  },

  /**
   * Export authenticated user's data
   */
  async exportAllData(explicitUserId?: string): Promise<string> {
    const data = await this.getAll(explicitUserId);
    return JSON.stringify(data, null, 2);
  },

  /**
   * Import data into authenticated user's account
   */
  async importAllData(jsonStr: string, explicitUserId?: string): Promise<boolean> {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.profiles || !Array.isArray(parsed.profiles)) {
        throw new Error('Invalid backup file: profiles missing');
      }
      await this.saveAll(parsed, explicitUserId);
      return true;
    } catch (e) {
      console.error('Import error:', e);
      return false;
    }
  },

  /**
   * Clear all data for specified user, or reset active user's storage
   */
  async clearAllData(explicitUserId?: string): Promise<void> {
    const userId = await resolveUserId(explicitUserId);
    const userKey = getUserKey(userId);

    userMemoryCache.delete(userId);

    if (isChromeStorageAvailable()) {
      await new Promise<void>((resolve) => {
        chrome.storage.local.remove([userKey], () => resolve());
      });
    }

    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem(userKey);
      } catch {}
    }
  },
};
