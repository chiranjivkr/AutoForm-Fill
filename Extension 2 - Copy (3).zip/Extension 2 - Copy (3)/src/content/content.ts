import { FormDetector } from '../services/formDetector';
import { FieldHelperService } from '../services/fieldHelper';
import { StorageService } from '../storage/storage';
import { DetectedField, FormDetectionSummary, FillResult } from '../types/form';
import { ExtensionMessage } from '../types/messages';
import { AuthService } from '../auth/authService';
import { defaultProfile } from '../types/profile';

let currentFields: DetectedField[] = [];
let floatingUiContainer: HTMLDivElement | null = null;
let activeHelperPopover: HTMLDivElement | null = null;
let isPanelOpen = false;

/**
 * Scans page and computes full detection summary with active profile and learned mappings.
 */
async function scanPage(): Promise<FormDetectionSummary> {
  // Never scan extension internal pages
  if (
    typeof window !== 'undefined' &&
    window.location &&
    (window.location.protocol === 'chrome-extension:' ||
      window.location.pathname.endsWith('options.html') ||
      window.location.pathname.endsWith('popup.html'))
  ) {
    return {
      detectedCount: 0,
      matchedCount: 0,
      filledCount: 0,
      verifiedCount: 0,
      failedCount: 0,
      fields: [],
      url: window.location.href,
      formTitle: document.title,
      timestamp: new Date().toISOString(),
    };
  }

  let currentUser = null;
  try {
    currentUser = await AuthService.getCurrentUser();
  } catch (err) {
    console.warn('FormPilot auth check failed during scan:', err);
  }
  const isAuthenticated = !!currentUser;

  if (!isAuthenticated) {
    const emptyProfile = {
      ...defaultProfile,
      personal: { fullName: '', email: '', phone: '' } as any,
      customFields: [],
    };
    currentFields = FormDetector.detectAll(document, emptyProfile, []);

    const summary: FormDetectionSummary = {
      detectedCount: currentFields.length,
      matchedCount: 0,
      filledCount: 0,
      verifiedCount: 0,
      failedCount: 0,
      fields: currentFields.map((f) => ({ ...f, mappedProperty: undefined, mappedValue: undefined })),
      url: window.location.href,
      formTitle: document.title,
      timestamp: new Date().toISOString(),
    };

    updateFloatingUi(summary, false);
    return summary;
  }

  const profile = await StorageService.getActiveProfile(currentUser.id);
  const learnedMappings = await StorageService.getLearnedMappings(currentUser.id);

  currentFields = FormDetector.detectAll(document, profile, learnedMappings);

  const matched = currentFields.filter((f) => !!f.mappedProperty && !!f.mappedValue);
  const filled = currentFields.filter((f) => f.verificationStatus === 'verified' || f.verificationStatus === 'mismatch');
  const verified = currentFields.filter((f) => f.verificationStatus === 'verified');
  const failed = currentFields.filter((f) => f.verificationStatus === 'failed');

  const summary: FormDetectionSummary = {
    detectedCount: currentFields.length,
    matchedCount: matched.length,
    filledCount: filled.length,
    verifiedCount: verified.length,
    failedCount: failed.length,
    fields: currentFields,
    url: window.location.href,
    formTitle: document.title,
    timestamp: new Date().toISOString(),
  };

  updateFloatingUi(summary, true);
  setupFieldHelperIcons();

  return summary;
}

/**
 * Fills requested fields and runs verification.
 */
async function fillRequestedFields(fieldsToFill: DetectedField[]): Promise<{ results: FillResult[]; summary: FormDetectionSummary }> {
  const currentUser = await AuthService.getCurrentUser();
  if (!currentUser) {
    return { results: [], summary: await scanPage() };
  }

  const results: FillResult[] = [];

  for (const field of fieldsToFill) {
    if (!field.mappedValue) continue;

    const res = await FormDetector.fillAndVerify(document, field, field.mappedValue);
    results.push(res);

    // Update in-memory field status
    const inMem = currentFields.find((f) => f.id === field.id);
    if (inMem) {
      inMem.verificationStatus = res.status;
      inMem.actualResultValue = res.actualValue;
      inMem.verificationMessage = res.error;
    }
  }

  const summary = await scanPage();
  return { results, summary };
}

let activeInlineCustomFieldId: string | null = null;

/**
 * Renders or updates in-page floating FormPilot widget
 */
function updateFloatingUi(summary: FormDetectionSummary, isAuthenticated = true) {
  if (summary.detectedCount === 0) {
    if (floatingUiContainer) {
      floatingUiContainer.remove();
      floatingUiContainer = null;
    }
    return;
  }

  if (!floatingUiContainer) {
    floatingUiContainer = document.createElement('div');
    floatingUiContainer.id = 'formpilot-floating-root';
    document.body.appendChild(floatingUiContainer);
  }

  if (!isAuthenticated) {
    floatingUiContainer.innerHTML = `
      <button class="fp-badge-button" id="fp-toggle-badge" style="background: #334155;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </svg>
        <span>FormPilot AI</span>
        <span class="fp-badge-count" style="background: rgba(255,255,255,0.2); color: #fff;">Sign In</span>
      </button>

      ${
        isPanelOpen
          ? `
        <div class="fp-panel">
          <div class="fp-header">
            <div class="fp-header-title">
              <span>FormPilot AI</span>
            </div>
            <button class="fp-close-btn" id="fp-close-panel">&times;</button>
          </div>
          <div style="padding: 20px; text-align: center;">
            <div style="font-weight: 700; font-size: 13px; color: #0f172a; margin-bottom: 6px;">Sign In Required</div>
            <p style="font-size: 11px; color: #64748b; line-height: 1.4; margin-bottom: 16px;">
              Please sign in to FormPilot AI to securely autofill forms, access your profile, and enable smart AI suggestions.
            </p>
            <button id="fp-open-signin-btn" class="fp-btn-primary" style="width: 100%; justify-content: center; cursor: pointer; padding: 8px 12px; font-weight: 600; font-size: 12px;">
              Sign In to FormPilot
            </button>
          </div>
        </div>
      `
          : ''
      }
    `;

    const badgeBtn = floatingUiContainer.querySelector('#fp-toggle-badge');
    badgeBtn?.addEventListener('click', () => {
      isPanelOpen = !isPanelOpen;
      updateFloatingUi(summary, false);
    });

    const closeBtn = floatingUiContainer.querySelector('#fp-close-panel');
    closeBtn?.addEventListener('click', () => {
      isPanelOpen = false;
      updateFloatingUi(summary, false);
    });

    const signinBtn = floatingUiContainer.querySelector('#fp-open-signin-btn');
    signinBtn?.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD' });
      }
    });

    return;
  }

  const matchedCount = summary.matchedCount;
  const verifiedCount = summary.verifiedCount;

  floatingUiContainer.innerHTML = `
    <button class="fp-badge-button" id="fp-toggle-badge">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
      </svg>
      <span>FormPilot AI</span>
      <span class="fp-badge-count">${matchedCount}/${summary.detectedCount}</span>
    </button>

    ${
      isPanelOpen
        ? `
      <div class="fp-panel">
        <div class="fp-header">
          <div class="fp-header-title">
            <span>FormPilot Autofill Review</span>
            <span class="fp-badge-count">${summary.detectedCount} fields</span>
          </div>
          <button class="fp-close-btn" id="fp-close-panel">&times;</button>
        </div>

        <div class="fp-stats-bar">
          <div class="fp-stat-item">
            <span class="fp-stat-num">${summary.detectedCount}</span>
            <span class="fp-stat-label">Detected</span>
          </div>
          <div class="fp-stat-item">
            <span class="fp-stat-num">${matchedCount}</span>
            <span class="fp-stat-label">Matched</span>
          </div>
          <div class="fp-stat-item">
            <span class="fp-stat-num" style="color: #16A34A">${verifiedCount}</span>
            <span class="fp-stat-label">Verified</span>
          </div>
          <div class="fp-stat-item">
            <span class="fp-stat-num" style="color: #DC2626">${summary.failedCount}</span>
            <span class="fp-stat-label">Failed</span>
          </div>
        </div>

        <div class="fp-fields-list">
          ${currentFields
            .map(
              (f) => `
            <div class="fp-field-card" style="flex-direction: column; align-items: stretch; gap: 4px;">
              <div style="display: flex; align-items: center; justify-content: space-between;">
                <div class="fp-field-info">
                  <input type="checkbox" ${f.selectedForFill && f.mappedValue ? 'checked' : ''} data-fp-chk="${f.id}" />
                  <div>
                    <div class="fp-field-name" title="${f.label}">${f.label}</div>
                    <div class="fp-field-val">${f.mappedValue ? `→ ${f.mappedValue}` : '<span style="color:#94a3b8">Unfamiliar field</span>'}</div>
                  </div>
                </div>
                <div class="fp-field-actions">
                  ${!f.mappedValue && activeInlineCustomFieldId !== f.id ? `<button class="fp-btn-add-custom" data-fp-open-custom="${f.id}">+ Custom</button>` : ''}
                  <span class="fp-status-tag fp-status-${f.verificationStatus}">${f.verificationStatus}</span>
                </div>
              </div>

              ${activeInlineCustomFieldId === f.id ? `
                <div class="fp-custom-field-inline-form">
                  <input type="text" class="fp-custom-input" id="fp-custom-title-${f.id}" value="${f.label.replace(/"/g, '&quot;')}" placeholder="Field title" />
                  <input type="text" class="fp-custom-input" id="fp-custom-val-${f.id}" placeholder="Enter value to fill..." />
                  <div class="fp-custom-actions">
                    <button type="button" class="fp-btn-cancel-custom" data-fp-cancel-custom="${f.id}">Cancel</button>
                    <button type="button" class="fp-btn-fill-once" data-fp-fill-once="${f.id}">Fill Once</button>
                    <button type="button" class="fp-btn-save-fill" data-fp-save-fill="${f.id}">Save & Fill</button>
                  </div>
                </div>
              ` : ''}
            </div>
          `
            )
            .join('')}
        </div>

        <div class="fp-footer">
          <button class="fp-btn-primary" id="fp-action-fill">Autofill & Verify</button>
          <button class="fp-btn-secondary" id="fp-action-refresh">Rescan</button>
        </div>
      </div>
    `
        : ''
    }
  `;

  // Attach event listeners
  const badgeBtn = floatingUiContainer.querySelector('#fp-toggle-badge');
  badgeBtn?.addEventListener('click', () => {
    isPanelOpen = !isPanelOpen;
    updateFloatingUi(summary);
  });

  const closeBtn = floatingUiContainer.querySelector('#fp-close-panel');
  closeBtn?.addEventListener('click', () => {
    isPanelOpen = false;
    updateFloatingUi(summary);
  });

  const fillBtn = floatingUiContainer.querySelector('#fp-action-fill');
  fillBtn?.addEventListener('click', async () => {
    const selected = currentFields.filter((f) => f.selectedForFill && f.mappedValue);
    await fillRequestedFields(selected);
  });

  const refreshBtn = floatingUiContainer.querySelector('#fp-action-refresh');
  refreshBtn?.addEventListener('click', async () => {
    await scanPage();
  });

  // Checkbox toggles
  const chks = floatingUiContainer.querySelectorAll<HTMLInputElement>('[data-fp-chk]');
  chks.forEach((chk) => {
    chk.addEventListener('change', () => {
      const fId = chk.getAttribute('data-fp-chk');
      const target = currentFields.find((f) => f.id === fId);
      if (target) {
        target.selectedForFill = chk.checked;
      }
    });
  });

  // Custom field open button
  floatingUiContainer.querySelectorAll<HTMLButtonElement>('[data-fp-open-custom]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      activeInlineCustomFieldId = btn.getAttribute('data-fp-open-custom');
      updateFloatingUi(summary);
    });
  });

  // Custom field cancel button
  floatingUiContainer.querySelectorAll<HTMLButtonElement>('[data-fp-cancel-custom]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      activeInlineCustomFieldId = null;
      updateFloatingUi(summary);
    });
  });

  // Custom field Fill Once
  floatingUiContainer.querySelectorAll<HTMLButtonElement>('[data-fp-fill-once]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const fId = btn.getAttribute('data-fp-fill-once');
      const f = currentFields.find((item) => item.id === fId);
      const valInput = floatingUiContainer?.querySelector<HTMLInputElement>(`#fp-custom-val-${fId}`);
      const val = valInput?.value.trim() || '';
      if (f && val) {
        await FormDetector.fillAndVerify(document, f, val);
        activeInlineCustomFieldId = null;
        await scanPage();
      }
    });
  });

  // Custom field Save & Fill
  floatingUiContainer.querySelectorAll<HTMLButtonElement>('[data-fp-save-fill]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const fId = btn.getAttribute('data-fp-save-fill');
      const f = currentFields.find((item) => item.id === fId);
      const titleInput = floatingUiContainer?.querySelector<HTMLInputElement>(`#fp-custom-title-${fId}`);
      const valInput = floatingUiContainer?.querySelector<HTMLInputElement>(`#fp-custom-val-${fId}`);
      const title = titleInput?.value.trim() || f?.label || '';
      const val = valInput?.value.trim() || '';
      if (f && title && val) {
        const activeProf = await StorageService.getActiveProfile();
        if (activeProf && activeProf.id) {
          const added = await StorageService.addCustomField(activeProf.id, {
            title,
            value: val,
            category: 'Other',
            aliases: [f.label],
          });
          if (added) {
            await StorageService.saveLearnedMapping({
              id: 'lm_' + Date.now(),
              domain: window.location.hostname,
              formSignature: document.title || window.location.hostname,
              fieldLabel: f.label,
              fieldPath: f.name || f.id,
              targetProperty: `custom.${added.id}`,
              confidence: 1.0,
              userVerified: true,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            });
          }
        }
        await FormDetector.fillAndVerify(document, f, val);
        activeInlineCustomFieldId = null;
        await scanPage();
      }
    });
  });
}

/**
 * On-Demand Field Helper Setup:
 * Places a discrete '?' help trigger near inputs.
 * Strictly remains closed until user explicitly clicks it.
 * Never fills data or suggests saved values.
 */
function setupFieldHelperIcons() {
  const inputs = document.querySelectorAll<HTMLElement>(
    'input:not([type="hidden"]):not([type="submit"]), textarea, select, [role="listitem"]'
  );

  inputs.forEach((inputEl) => {
    // Avoid re-attaching
    if (inputEl.getAttribute('data-fp-helper-attached')) return;
    inputEl.setAttribute('data-fp-helper-attached', 'true');

    // Attach click listener for help icon trigger
    const label = FormDetector.extractLabel(inputEl, document) || inputEl.getAttribute('placeholder') || '';
    if (!label) return;

    // Show on focus / hover without being intrusive
    inputEl.addEventListener('focus', (e) => {
      showHelperTrigger(inputEl, label);
    });
  });
}

let activeTriggerIcon: HTMLDivElement | null = null;

function showHelperTrigger(el: HTMLElement, label: string) {
  if (activeTriggerIcon) {
    activeTriggerIcon.remove();
  }

  const rect = el.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return;

  const icon = document.createElement('div');
  icon.className = 'fp-field-helper-icon';
  icon.innerHTML = '?';
  icon.title = 'FormPilot: What does this field mean?';
  icon.style.position = 'absolute';
  icon.style.left = `${window.scrollX + rect.right - 24}px`;
  icon.style.top = `${window.scrollY + rect.top + rect.height / 2 - 9}px`;
  icon.style.zIndex = '2147483645';

  icon.addEventListener('click', (evt) => {
    evt.preventDefault();
    evt.stopPropagation();
    openFieldHelperPopover(icon, label);
  });

  document.body.appendChild(icon);
  activeTriggerIcon = icon;
}

function openFieldHelperPopover(anchor: HTMLElement, label: string) {
  if (activeHelperPopover) {
    activeHelperPopover.remove();
  }

  const help = FieldHelperService.getExplanation(label);
  const rect = anchor.getBoundingClientRect();

  const popover = document.createElement('div');
  popover.className = 'fp-helper-popover';
  popover.style.left = `${Math.max(10, window.scrollX + rect.left - 260)}px`;
  popover.style.top = `${window.scrollY + rect.bottom + 8}px`;

  popover.innerHTML = `
    <button class="fp-helper-close" id="fp-helper-close-btn">&times;</button>
    <div class="fp-helper-title">Field Explanation</div>
    <div class="fp-helper-text">${help.explanation}</div>
    ${help.recommendedFormat ? `<div class="fp-helper-format">Recommended: ${help.recommendedFormat}</div>` : ''}
  `;

  popover.querySelector('#fp-helper-close-btn')?.addEventListener('click', () => {
    popover.remove();
    activeHelperPopover = null;
  });

  document.body.appendChild(popover);
  activeHelperPopover = popover;

  // Auto-dismiss on click outside
  const onOutsideClick = (e: MouseEvent) => {
    if (!popover.contains(e.target as Node) && e.target !== anchor) {
      popover.remove();
      activeHelperPopover = null;
      document.removeEventListener('click', onOutsideClick);
    }
  };
  setTimeout(() => document.addEventListener('click', onOutsideClick), 50);
}

// Global Chrome runtime messaging listener
if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message: ExtensionMessage, sender, sendResponse) => {
    if (message.type === 'PING') {
      sendResponse({ status: 'pong', url: window.location.href, title: document.title });
      return true;
    }

    if (message.type === 'DETECT_FORMS') {
      scanPage()
        .then((summary) => sendResponse({ summary }))
        .catch((err) => {
          console.warn('FormPilot scanPage error:', err);
          sendResponse({ summary: null, error: err?.message || 'Detection failed' });
        });
      return true; // Keep channel open for async response
    }

    if (message.type === 'FILL_FIELDS') {
      AuthService.getCurrentUser().then((currentUser) => {
        if (!currentUser) {
          sendResponse({ error: 'Authentication required. Please log in to FormPilot AI.' });
          return;
        }
        const payload = message.payload as { fields: DetectedField[] };
        fillRequestedFields(payload.fields)
          .then((res) => sendResponse(res))
          .catch((err) => sendResponse({ error: err?.message }));
      });
      return true;
    }

    if (message.type === 'FILL_SINGLE_FIELD') {
      AuthService.getCurrentUser().then((currentUser) => {
        if (!currentUser) {
          sendResponse({ error: 'Authentication required. Please log in to FormPilot AI.' });
          return;
        }
        const payload = message.payload as { fieldId: string; value: string };
        const target = currentFields.find((f) => f.id === payload.fieldId);
        if (target) {
          FormDetector.fillAndVerify(document, target, payload.value).then((res) => {
            target.verificationStatus = res.status;
            target.actualResultValue = res.actualValue;
            target.verificationMessage = res.error;
            scanPage().then((summary) => sendResponse({ result: res, summary }));
          });
        } else {
          sendResponse({ error: 'Field not found' });
        }
      });
      return true;
    }

    if (message.type === 'GET_FIELD_HELP') {
      const payload = message.payload as { label: string; context?: string };
      const explanation = FieldHelperService.getExplanation(payload.label, payload.context);
      sendResponse({ explanation });
      return true;
    }
  });
}

// Listen for authentication changes across extension tabs
AuthService.onAuthStateChange(() => {
  scanPage().catch(() => {});
});

let observerTimeout: ReturnType<typeof setTimeout> | null = null;
function setupMutationObserver() {
  if (typeof MutationObserver === 'undefined' || !document.body) return;

  const observer = new MutationObserver((mutations) => {
    // Avoid reacting on extension pages
    if (
      typeof window !== 'undefined' &&
      window.location &&
      (window.location.protocol === 'chrome-extension:' ||
        window.location.pathname.endsWith('options.html') ||
        window.location.pathname.endsWith('popup.html'))
    ) {
      return;
    }

    let shouldRescan = false;
    for (const m of mutations) {
      const target = m.target as HTMLElement;
      if (
        target &&
        (target.id === 'formpilot-floating-root' ||
          target.closest?.('#formpilot-floating-root, .fp-helper-popover, .fp-field-helper-icon') ||
          target.hasAttribute?.('data-formpilot-id') ||
          target.hasAttribute?.('data-formpilot-radio-group'))
      ) {
        continue;
      }

      if (m.type === 'childList') {
        for (let i = 0; i < m.addedNodes.length; i++) {
          const node = m.addedNodes[i];
          if (node instanceof HTMLElement) {
            if (
              node.id === 'formpilot-floating-root' ||
              node.classList?.contains('fp-field-helper-icon') ||
              node.classList?.contains('fp-helper-popover')
            ) {
              continue;
            }
            if (
              node.matches?.('input, textarea, select, [role="listitem"], [role="radiogroup"], .geS5n, .Qr7O8') ||
              node.querySelector?.('input, textarea, select, [role="listitem"], [role="radiogroup"], .geS5n, .Qr7O8')
            ) {
              shouldRescan = true;
              break;
            }
          }
        }
      } else if (m.type === 'attributes') {
        if (
          target &&
          !target.id?.startsWith('fp') &&
          !target.hasAttribute('data-formpilot-id') &&
          (m.attributeName === 'style' || m.attributeName === 'class' || m.attributeName === 'hidden')
        ) {
          if (
            target.matches?.('input, textarea, select, form, [role="form"]') ||
            target.querySelector?.('input, textarea, select')
          ) {
            shouldRescan = true;
          }
        }
      }

      if (shouldRescan) break;
    }

    if (shouldRescan) {
      if (observerTimeout) clearTimeout(observerTimeout);
      observerTimeout = setTimeout(() => {
        scanPage().catch(() => {});
      }, 500);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style', 'class', 'hidden'],
  });
}

function initContentScript() {
  scanPage().catch(() => {});
  setupMutationObserver();
}

// Initial detection when page is ready
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(initContentScript, 300);
} else {
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(initContentScript, 300);
  });
}


