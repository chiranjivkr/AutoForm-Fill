import React, { useState, useEffect } from 'react';
import {
  User,
  GraduationCap,
  FileText,
  Briefcase,
  Sparkles,
  BrainCircuit,
  Settings,
  Plus,
  Trash2,
  Save,
  Upload,
  Download,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  Shield,
  Copy,
  Search,
  BookOpen,
  Edit3,
  Layers,
  Tag,
  Award,
  RotateCcw,
  X,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { StorageService, sanitizeProfile, sanitizeProfiles, defaultStorageData } from '../storage/storage';
import {
  UserProfile,
  defaultProfile,
  PersonalInfo,
  Class10Info,
  Class12Info,
  BTechInfo,
  HigherEducationItem,
  WorkExperienceItem,
  ProjectItem,
  JobProfile,
  CustomProfileField,
} from '../types/profile';
import { JobApplication, ApplicationStatus } from '../types/tracker';
import { LearnedMapping } from '../types/learning';
import { AISettings } from '../types/ai';
import { ResumeParser, ExtractedResumeData } from '../services/resumeParser';
import { AIAnswerGenerator } from '../services/aiAnswerGenerator';
import { useAuth } from '../auth/useAuth';
import { AuthView } from '../components/auth/AuthView';
import { UserBadge } from '../components/auth/UserBadge';

type DashboardTab =
  | 'profile'
  | 'resume'
  | 'custom_fields'
  | 'job_profiles'
  | 'tracker'
  | 'ai_answers'
  | 'learning'
  | 'settings';

const VALID_TABS: DashboardTab[] = [
  'profile',
  'resume',
  'custom_fields',
  'job_profiles',
  'tracker',
  'ai_answers',
  'learning',
  'settings',
];

const getInitialTab = (): DashboardTab => {
  try {
    if (typeof window !== 'undefined' && window.location) {
      const params = new URLSearchParams(window.location.search);
      const tab = params.get('tab') as DashboardTab | null;
      if (tab && VALID_TABS.includes(tab)) {
        return tab;
      }
    }
  } catch {
    // fallback
  }
  return 'profile';
};

export const Dashboard: React.FC = () => {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<DashboardTab>(getInitialTab);

  const handleTabChange = (tab: DashboardTab) => {
    setActiveTab(tab);
    if (typeof window !== 'undefined' && window.history?.replaceState) {
      try {
        const url = new URL(window.location.href);
        url.searchParams.set('tab', tab);
        window.history.replaceState(null, '', url.toString());
      } catch {
        // ignore
      }
    }
  };

  useEffect(() => {
    const handlePopState = () => {
      setActiveTab(getInitialTab());
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // State
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [jobProfiles, setJobProfiles] = useState<JobProfile[]>([]);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [learnedMappings, setLearnedMappings] = useState<LearnedMapping[]>([]);
  const [aiSettings, setAiSettings] = useState<AISettings>({
    provider: 'rule-based',
    apiKey: '',
    enabled: true,
  });

  // UI state
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Resume extraction state
  const [resumeText, setResumeText] = useState('');
  const [extractedData, setExtractedData] = useState<ExtractedResumeData | null>(null);
  const [reviewedProfile, setReviewedProfile] = useState<UserProfile | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [overwriteConfirmModal, setOverwriteConfirmModal] = useState(false);
  const [showRawText, setShowRawText] = useState(false);
  const [rawTextSearch, setRawTextSearch] = useState('');

  // Tracker state
  const [trackerFilter, setTrackerFilter] = useState<{ status: string; search: string }>({
    status: 'All',
    search: '',
  });
  const [showAddAppModal, setShowAddAppModal] = useState(false);
  const [newApp, setNewApp] = useState<Partial<JobApplication>>({
    company: '',
    jobTitle: '',
    applicationLink: '',
    status: 'Applied',
    dateApplied: new Date().toISOString().split('T')[0],
    notes: '',
  });

  // AI Answer Generator state
  const [aiQuestion, setAiQuestion] = useState('Why should we hire you?');
  const [aiJobTitle, setAiJobTitle] = useState('');
  const [aiCompany, setAiCompany] = useState('');
  const [generatedAnswer, setGeneratedAnswer] = useState('');
  const [isGeneratingAnswer, setIsGeneratingAnswer] = useState(false);

  // Custom Fields state
  const [customFieldSearch, setCustomFieldSearch] = useState('');
  const [customFieldCategoryFilter, setCustomFieldCategoryFilter] = useState('All');
  const [showCustomFieldModal, setShowCustomFieldModal] = useState(false);
  const [editingCustomField, setEditingCustomField] = useState<CustomProfileField | null>(null);
  const [customFieldForm, setCustomFieldForm] = useState<{
    title: string;
    value: string;
    category: 'Education' | 'Identification' | 'Certificates' | 'Professional' | 'Other';
    aliases: string;
  }>({
    title: '',
    value: '',
    category: 'Other',
    aliases: '',
  });

  useEffect(() => {
    if (isAuthenticated) {
      loadAllData();
    }
  }, [isAuthenticated, user?.id]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadAllData = async () => {
    try {
      const data = await StorageService.getAll();
      const safeProfiles = sanitizeProfiles(data?.profiles || []);
      setProfiles(safeProfiles);
      const active =
        safeProfiles.find((p) => p.id === data?.activeProfileId) ||
        safeProfiles[0] ||
        defaultProfile;
      setProfile(sanitizeProfile(active));
      setJobProfiles(data?.jobProfiles || []);
      setApplications(data?.applications || []);
      setLearnedMappings(data?.learnedMappings || []);
      if (data?.aiSettings) {
        setAiSettings(data.aiSettings);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setProfile(defaultProfile);
      setProfiles([defaultProfile]);
      setJobProfiles([]);
      setApplications([]);
      setLearnedMappings([]);
    }
  };

  const saveProfile = async () => {
    setIsSaving(true);
    try {
      const sanitized = sanitizeProfile(profile);
      await StorageService.saveProfile(sanitized);
      setProfile(sanitized);
      showToast('Profile saved successfully!');
    } catch (err) {
      showToast('Error saving profile.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleProfileSwitch = async (id: string) => {
    const selected = profiles.find((p) => p.id === id);
    if (selected) {
      const sanitized = sanitizeProfile(selected);
      setProfile(sanitized);
      await StorageService.saveAll({ activeProfileId: id });
      showToast(`Switched to ${sanitized.name}`);
    }
  };

  const handleOpenAddCustomField = () => {
    setEditingCustomField(null);
    setCustomFieldForm({
      title: '',
      value: '',
      category: 'Other',
      aliases: '',
    });
    setShowCustomFieldModal(true);
  };

  const handleOpenEditCustomField = (cf: CustomProfileField) => {
    setEditingCustomField(cf);
    setCustomFieldForm({
      title: cf.title,
      value: cf.value,
      category: cf.category || 'Other',
      aliases: (cf.aliases || []).join(', '),
    });
    setShowCustomFieldModal(true);
  };

  const handleSaveCustomField = async () => {
    if (!customFieldForm.title.trim() || !customFieldForm.value.trim()) {
      showToast('Field Title and Value are required.');
      return;
    }

    const aliasesList = customFieldForm.aliases
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const now = new Date().toISOString();
    let updatedCustomFields: CustomProfileField[];

    if (editingCustomField) {
      updatedCustomFields = (profile.customFields || []).map((cf) =>
        cf.id === editingCustomField.id
          ? {
              ...cf,
              title: customFieldForm.title.trim(),
              value: customFieldForm.value.trim(),
              category: customFieldForm.category,
              aliases: aliasesList,
              updatedAt: now,
            }
          : cf
      );
    } else {
      const newField: CustomProfileField = {
        id: 'cf_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        title: customFieldForm.title.trim(),
        value: customFieldForm.value.trim(),
        category: customFieldForm.category,
        aliases: aliasesList,
        createdAt: now,
        updatedAt: now,
      };
      updatedCustomFields = [...(profile.customFields || []), newField];
    }

    const updatedProfile: UserProfile = {
      ...profile,
      customFields: updatedCustomFields,
      updatedAt: now,
    };

    setProfile(updatedProfile);
    await StorageService.saveProfile(updatedProfile);
    setShowCustomFieldModal(false);
    showToast(editingCustomField ? 'Custom field updated!' : 'Custom field added to profile!');
  };

  const handleDeleteCustomField = async (id: string) => {
    const updatedCustomFields = (profile.customFields || []).filter((cf) => cf.id !== id);
    const updatedProfile: UserProfile = {
      ...profile,
      customFields: updatedCustomFields,
      updatedAt: new Date().toISOString(),
    };
    setProfile(updatedProfile);
    await StorageService.saveProfile(updatedProfile);
    showToast('Custom field removed.');
  };

  // Higher Education operations
  const addHigherEducation = () => {
    const safe = sanitizeProfile(profile);
    const newItem: HigherEducationItem = {
      id: 'he_' + Date.now(),
      qualification: 'M.Tech',
      institution: '',
      specialization: '',
      passingYear: '',
      percentageOrCgpa: '',
    };
    setProfile({
      ...safe,
      higherEducation: [...(safe.higherEducation || []), newItem],
    });
  };

  const removeHigherEducation = (id: string) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      higherEducation: (safe.higherEducation || []).filter((h) => h.id !== id),
    });
  };

  const updateHigherEducation = (id: string, field: keyof HigherEducationItem, val: string) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      higherEducation: (safe.higherEducation || []).map((h) => (h.id === id ? { ...h, [field]: val } : h)),
    });
  };

  // Experience operations
  const addExperience = () => {
    const safe = sanitizeProfile(profile);
    const newItem: WorkExperienceItem = {
      id: 'exp_' + Date.now(),
      company: '',
      role: '',
      startDate: '',
      endDate: '',
      description: '',
      isInternship: false,
    };
    setProfile({
      ...safe,
      experiences: [...(safe.experiences || []), newItem],
    });
  };

  const removeExperience = (id: string) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      experiences: (safe.experiences || []).filter((e) => e.id !== id),
    });
  };

  const updateExperience = (id: string, field: keyof WorkExperienceItem, val: any) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      experiences: (safe.experiences || []).map((e) => (e.id === id ? { ...e, [field]: val } : e)),
    });
  };

  // Project operations
  const addProject = () => {
    const safe = sanitizeProfile(profile);
    const newItem: ProjectItem = {
      id: 'proj_' + Date.now(),
      title: '',
      technologies: '',
      link: '',
      description: '',
    };
    setProfile({
      ...safe,
      projects: [...(safe.projects || []), newItem],
    });
  };

  const removeProject = (id: string) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      projects: (safe.projects || []).filter((p) => p.id !== id),
    });
  };

  const updateProject = (id: string, field: keyof ProjectItem, val: string) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      projects: (safe.projects || []).map((p) => (p.id === id ? { ...p, [field]: val } : p)),
    });
  };

  // Certifications operations
  const addCertification = (cert: string) => {
    if (!cert.trim()) return;
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      certifications: [...(safe.certifications || []), cert.trim()],
    });
  };

  const removeCertification = (idx: number) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      certifications: (safe.certifications || []).filter((_, i) => i !== idx),
    });
  };

  // Achievements operations
  const addAchievement = (ach: string) => {
    if (!ach.trim()) return;
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      achievements: [...(safe.achievements || []), ach.trim()],
    });
  };

  const removeAchievement = (idx: number) => {
    const safe = sanitizeProfile(profile);
    setProfile({
      ...safe,
      achievements: (safe.achievements || []).filter((_, i) => i !== idx),
    });
  };

  // Reviewed Profile operations (for Resume Review Screen)
  const updateReviewedPersonal = (field: keyof PersonalInfo, val: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      personal: {
        ...reviewedProfile.personal,
        [field]: val,
      },
    });
  };

  const updateReviewedClass10 = (field: keyof Class10Info, val: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      class10: {
        ...reviewedProfile.class10,
        [field]: val,
      },
    });
  };

  const updateReviewedClass12 = (field: keyof Class12Info, val: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      class12: {
        ...reviewedProfile.class12,
        [field]: val,
      },
    });
  };

  const updateReviewedBtech = (field: keyof BTechInfo, val: any) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      btech: {
        ...reviewedProfile.btech,
        [field]: val,
      },
    });
  };

  const addReviewedSkill = (skill: string) => {
    if (!reviewedProfile || !skill.trim()) return;
    const clean = skill.trim();
    if ((reviewedProfile.skills || []).includes(clean)) return;
    setReviewedProfile({
      ...reviewedProfile,
      skills: [...(reviewedProfile.skills || []), clean],
    });
  };

  const removeReviewedSkill = (idx: number) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      skills: (reviewedProfile.skills || []).filter((_, i) => i !== idx),
    });
  };

  const addReviewedExperience = () => {
    if (!reviewedProfile) return;
    const newExp: WorkExperienceItem = {
      id: 'exp_' + Date.now(),
      company: '',
      role: '',
      startDate: '',
      endDate: '',
      description: '',
      isInternship: false,
      isCurrent: false,
    };
    setReviewedProfile({
      ...reviewedProfile,
      experiences: [...(reviewedProfile.experiences || []), newExp],
    });
  };

  const updateReviewedExperience = (id: string, field: keyof WorkExperienceItem, val: any) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      experiences: (reviewedProfile.experiences || []).map((exp) =>
        exp.id === id ? { ...exp, [field]: val } : exp
      ),
    });
  };

  const removeReviewedExperience = (id: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      experiences: (reviewedProfile.experiences || []).filter((exp) => exp.id !== id),
    });
  };

  const addReviewedProject = () => {
    if (!reviewedProfile) return;
    const newProj: ProjectItem = {
      id: 'proj_' + Date.now(),
      title: '',
      role: '',
      technologies: '',
      description: '',
      link: '',
      date: '',
    };
    setReviewedProfile({
      ...reviewedProfile,
      projects: [...(reviewedProfile.projects || []), newProj],
    });
  };

  const updateReviewedProject = (id: string, field: keyof ProjectItem, val: any) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      projects: (reviewedProfile.projects || []).map((p) =>
        p.id === id ? { ...p, [field]: val } : p
      ),
    });
  };

  const removeReviewedProject = (id: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      projects: (reviewedProfile.projects || []).filter((p) => p.id !== id),
    });
  };

  const addReviewedCertification = (cert: string) => {
    if (!reviewedProfile || !cert.trim()) return;
    setReviewedProfile({
      ...reviewedProfile,
      certifications: [...(reviewedProfile.certifications || []), cert.trim()],
    });
  };

  const removeReviewedCertification = (idx: number) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      certifications: (reviewedProfile.certifications || []).filter((_, i) => i !== idx),
    });
  };

  const addReviewedAchievement = (ach: string) => {
    if (!reviewedProfile || !ach.trim()) return;
    setReviewedProfile({
      ...reviewedProfile,
      achievements: [...(reviewedProfile.achievements || []), ach.trim()],
    });
  };

  const removeReviewedAchievement = (idx: number) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      achievements: (reviewedProfile.achievements || []).filter((_, i) => i !== idx),
    });
  };

  const isFieldUncertain = (fieldPath: string) => {
    if (!extractedData?.uncertainFields) return false;
    return extractedData.uncertainFields.includes(fieldPath);
  };

  const getFriendlyUncertainName = (fieldPath: string) => {
    const map: Record<string, string> = {
      'personal.fullName': 'Full Name',
      'personal.email': 'Email Address',
      'personal.phoneNumber': 'Phone Number',
      'personal.currentLocation': 'Current Location / Address',
      'class10.percentage': 'Class 10 Percentage',
      'class12.percentage': 'Class 12 / Diploma Percentage',
      'btech.cgpa': 'Degree CGPA',
      'btech.prn': 'Roll / PRN Number',
    };
    return map[fieldPath] || fieldPath;
  };

  const addReviewedHigherEducation = () => {
    if (!reviewedProfile) return;
    const newItem: HigherEducationItem = {
      id: 'he_' + Date.now(),
      qualification: 'M.Tech',
      institution: '',
      specialization: '',
      passingYear: '',
      percentageOrCgpa: '',
    };
    setReviewedProfile({
      ...reviewedProfile,
      higherEducation: [...(reviewedProfile.higherEducation || []), newItem],
    });
  };

  const removeReviewedHigherEducation = (id: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      higherEducation: (reviewedProfile.higherEducation || []).filter((h) => h.id !== id),
    });
  };

  const updateReviewedHigherEducation = (id: string, field: keyof HigherEducationItem, val: string) => {
    if (!reviewedProfile) return;
    setReviewedProfile({
      ...reviewedProfile,
      higherEducation: (reviewedProfile.higherEducation || []).map((h) =>
        h.id === id ? { ...h, [field]: val } : h
      ),
    });
  };

  const overallConfidence = React.useMemo(() => {
    if (!extractedData?.fieldConfidence) return 0;
    const scores = Object.values(extractedData.fieldConfidence);
    if (scores.length === 0) return 0;
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    return Math.round(avg * 100);
  }, [extractedData]);

  // Resume extraction handlers
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsExtracting(true);
    try {
      let rawText = '';
      let isScannedPdf = false;
      let pageCount = 1;
      if (file.name.endsWith('.pdf')) {
        const res = await ResumeParser.extractTextFromPdf(file);
        rawText = res.text;
        isScannedPdf = res.isScanned;
        pageCount = res.pages;
        if (res.isScanned) {
          showToast('Notice: Scanned PDF detected. Text extraction may be limited without OCR.');
        }
      } else if (file.name.endsWith('.docx')) {
        rawText = await ResumeParser.extractTextFromDocx(file);
      } else {
        rawText = await file.text();
      }

      setResumeText(rawText);
      const parsed = ResumeParser.parseResumeText(rawText);
      if (isScannedPdf) {
        parsed.isScannedPdf = true;
        parsed.needsOcr = true;
      }
      parsed.pageCount = pageCount;
      setExtractedData(parsed);
      setReviewedProfile(sanitizeProfile(parsed.profile));
      showToast('Resume parsed successfully! Review and edit extracted data below.');
    } catch (err: any) {
      showToast('Failed to parse resume: ' + (err.message || 'Unknown error'));
    } finally {
      setIsExtracting(false);
    }
  };

  const handlePastedResumeExtract = () => {
    if (!resumeText.trim()) {
      showToast('Please paste resume text first.');
      return;
    }
    setIsExtracting(true);
    const parsed = ResumeParser.parseResumeText(resumeText);
    setExtractedData(parsed);
    setReviewedProfile(sanitizeProfile(parsed.profile));
    setIsExtracting(false);
    showToast('Extracted information from pasted text.');
  };

  const applyExtractedToProfile = async (overwriteAll: boolean) => {
    const source = reviewedProfile || (extractedData?.profile ? sanitizeProfile(extractedData.profile) : null);
    if (!source) return;
    const base = sanitizeProfile(profile);

    let merged: UserProfile;
    if (overwriteAll) {
      merged = {
        ...source,
        id: base.id,
        name: base.name,
        updatedAt: new Date().toISOString(),
        personal: {
          ...source.personal,
          currentLocation: source.personal?.currentLocation || base.personal?.currentLocation || '',
        },
        customAnswers: base.customAnswers,
        customFields: base.customFields,
      };
    } else {
      // Fill empty only
      merged = {
        ...base,
        personal: {
          fullName: base.personal.fullName || source.personal.fullName,
          firstName: base.personal.firstName || source.personal.firstName,
          lastName: base.personal.lastName || source.personal.lastName,
          email: base.personal.email || source.personal.email,
          phoneNumber: base.personal.phoneNumber || source.personal.phoneNumber,
          whatsappNumber: base.personal.whatsappNumber || source.personal.whatsappNumber,
          currentLocation: base.personal.currentLocation || source.personal.currentLocation,
          linkedin: base.personal.linkedin || source.personal.linkedin,
          github: base.personal.github || source.personal.github,
          portfolio: base.personal.portfolio || source.personal.portfolio,
          summary: base.personal.summary || source.personal.summary,
        },
        class10: {
          board: base.class10.board || source.class10.board,
          school: base.class10.school || source.class10.school,
          passingYear: base.class10.passingYear || source.class10.passingYear,
          percentage: base.class10.percentage || source.class10.percentage,
        },
        class12: {
          qualificationType: source.class12.qualificationType || base.class12.qualificationType,
          boardOrInstitution: base.class12.boardOrInstitution || source.class12.boardOrInstitution,
          stream: base.class12.stream || source.class12.stream,
          passingYear: base.class12.passingYear || source.class12.passingYear,
          percentage: base.class12.percentage || source.class12.percentage,
        },
        btech: {
          degree: base.btech.degree || source.btech.degree,
          branch: base.btech.branch || source.btech.branch,
          college: base.btech.college || source.btech.college,
          passingYear: base.btech.passingYear || source.btech.passingYear,
          cgpa: base.btech.cgpa || source.btech.cgpa,
          activeBacklogs: base.btech.activeBacklogs || source.btech.activeBacklogs,
          deadBacklogs: base.btech.deadBacklogs || source.btech.deadBacklogs,
          prn: base.btech.prn || source.btech.prn,
        },
        skills: Array.from(new Set([...(base.skills || []), ...(source.skills || [])])),
        experiences: base.experiences && base.experiences.length > 0 ? base.experiences : source.experiences || [],
        projects: base.projects && base.projects.length > 0 ? base.projects : source.projects || [],
        higherEducation: base.higherEducation && base.higherEducation.length > 0 ? base.higherEducation : source.higherEducation || [],
        certifications: Array.from(new Set([...(base.certifications || []), ...(source.certifications || [])])),
        achievements: Array.from(new Set([...(base.achievements || []), ...(source.achievements || [])])),
        updatedAt: new Date().toISOString(),
      };
    }

    setProfile(merged);
    await StorageService.saveProfile(merged);
    setOverwriteConfirmModal(false);
    showToast('Approved resume data saved to your profile successfully!');
    setActiveTab('profile');
  };

  const handleInitiateSaveToProfile = () => {
    const source = reviewedProfile || (extractedData?.profile ? sanitizeProfile(extractedData.profile) : null);
    if (!source) return;
    const base = sanitizeProfile(profile);
    const hasExistingData = !!(
      base.personal.fullName ||
      base.personal.email ||
      base.btech.cgpa ||
      base.class10.percentage
    );
    if (hasExistingData) {
      setOverwriteConfirmModal(true);
    } else {
      applyExtractedToProfile(true);
    }
  };

  // Application tracker handlers
  const handleSaveApp = async () => {
    if (!newApp.company || !newApp.jobTitle) {
      showToast('Company and Job Title are required.');
      return;
    }
    const app: JobApplication = {
      id: 'app_' + Date.now(),
      company: newApp.company,
      jobTitle: newApp.jobTitle,
      applicationLink: newApp.applicationLink || '',
      deadline: newApp.deadline,
      dateApplied: newApp.dateApplied || new Date().toISOString().split('T')[0],
      status: (newApp.status as ApplicationStatus) || 'Applied',
      notes: newApp.notes || '',
      documents: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await StorageService.saveApplication(app);
    setApplications([...applications, app]);
    setShowAddAppModal(false);
    setNewApp({
      company: '',
      jobTitle: '',
      applicationLink: '',
      status: 'Applied',
      dateApplied: new Date().toISOString().split('T')[0],
      notes: '',
    });
    showToast('Application added to tracker!');
  };

  const handleDeleteApp = async (id: string) => {
    await StorageService.deleteApplication(id);
    setApplications(applications.filter((a) => a.id !== id));
    showToast('Application removed.');
  };

  // AI Answer Generator
  const handleGenerateAnswer = async () => {
    setIsGeneratingAnswer(true);
    try {
      const res = await AIAnswerGenerator.generateAnswer(
        {
          question: aiQuestion,
          jobTitle: aiJobTitle,
          company: aiCompany,
        },
        profile,
        aiSettings
      );
      setGeneratedAnswer(res.answer);
    } catch (e: any) {
      showToast('Error generating answer: ' + (e.message || 'Unknown error'));
    } finally {
      setIsGeneratingAnswer(false);
    }
  };

  const renderCustomFieldsSection = () => {
    const filtered = (profile.customFields || []).filter((cf) => {
      const matchesCategory =
        customFieldCategoryFilter === 'All' || cf.category === customFieldCategoryFilter;
      const q = customFieldSearch.toLowerCase().trim();
      const matchesSearch =
        !q ||
        cf.title.toLowerCase().includes(q) ||
        cf.value.toLowerCase().includes(q) ||
        (cf.aliases && cf.aliases.some((a) => a.toLowerCase().includes(q)));
      return matchesCategory && matchesSearch;
    });

    return (
      <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary" />
            <div>
              <h2 className="text-sm font-bold text-slate-900">Custom Profile Fields</h2>
              <p className="text-xs text-text-secondary">
                Add personalized fields (e.g. University Reg No, NCC Certificate, Entrance Rank) for smart autofill.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenAddCustomField}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Custom Field</span>
            </button>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search custom fields by title, value, or alias..."
              value={customFieldSearch}
              onChange={(e) => setCustomFieldSearch(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {['All', 'Education', 'Identification', 'Certificates', 'Professional', 'Other'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCustomFieldCategoryFilter(cat)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  customFieldCategoryFilter === cat
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Fields List */}
        {filtered.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
            <Tag className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-50" />
            <div className="text-xs font-bold text-slate-700 mb-1">
              {profile.customFields && profile.customFields.length > 0
                ? 'No matching custom fields found'
                : 'No custom fields added yet'}
            </div>
            <p className="text-[11px] text-text-secondary max-w-sm mx-auto mb-3">
              {profile.customFields && profile.customFields.length > 0
                ? 'Try clearing your search query or switching category filters.'
                : 'Create fields for anything not in the standard profile (e.g. Roll No, Certificate Numbers, Parents details) to enable smart autofill across forms.'}
            </p>
            <button
              type="button"
              onClick={handleOpenAddCustomField}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Your First Custom Field</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filtered.map((cf) => (
              <div
                key={cf.id}
                className="p-3.5 rounded-xl border border-border bg-slate-50/60 hover:bg-white hover:border-blue-200 hover:shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-xs text-slate-900">{cf.title}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-semibold bg-blue-100/70 text-blue-800 border border-blue-200/50">
                        {cf.category || 'Other'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenEditCustomField(cf)}
                        className="p-1 text-slate-400 hover:text-blue-600 rounded transition-colors cursor-pointer"
                        title="Edit custom field"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCustomField(cf.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                        title="Delete custom field"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-2 bg-white px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-mono text-slate-800 break-all select-all">
                    <span className="flex-1">{cf.value}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(cf.value);
                        showToast(`Copied "${cf.title}" value!`);
                      }}
                      className="text-slate-400 hover:text-slate-700 shrink-0 cursor-pointer"
                      title="Copy value"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {cf.aliases && cf.aliases.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap pt-1 border-t border-slate-200/60">
                    <span className="text-[10px] text-slate-500 font-medium">Aliases:</span>
                    {cf.aliases.map((al, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] px-1.5 py-0.5 bg-slate-200/70 text-slate-700 rounded font-mono"
                      >
                        {al}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-slate-500 font-sans">
        <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
        <span className="text-sm font-medium">Loading FormPilot AI Dashboard...</span>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 font-sans">
        <AuthView onSuccess={() => loadAllData()} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-text-primary flex flex-col font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-semibold flex items-center gap-2 animate-bounce">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <nav className="bg-white border-b border-border px-6 py-3.5 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900 tracking-tight leading-none">FormPilot AI</h1>
            <p className="text-xs text-text-secondary mt-0.5">Application & Form Automation Control Center</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <span className="text-xs font-semibold text-slate-500">Active Profile:</span>
            <select
              value={profile?.id || 'default'}
              onChange={(e) => handleProfileSwitch(e.target.value)}
              className="text-xs font-bold bg-transparent text-slate-800 focus:outline-none cursor-pointer"
            >
              {profiles.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name || 'Default Profile'} ({p.personal?.fullName || 'No Name'})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs font-medium text-slate-600 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <Shield className="w-3.5 h-3.5 text-emerald-600" />
            <span>Isolated Storage</span>
          </div>

          <button
            onClick={saveProfile}
            disabled={isSaving}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-sm shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving...' : 'Save Profile'}</span>
          </button>

          <UserBadge user={user} onLogout={() => {}} />
        </div>
      </nav>

      {/* Main Container with Sidebar + Content */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto p-6 gap-6">
        {/* Navigation Sidebar */}
        <aside className="w-60 shrink-0 flex flex-col gap-1.5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-text-secondary px-3 mb-1">
            Core Modules
          </div>

          <button
            onClick={() => handleTabChange('profile')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4" />
            <span>My Profile</span>
          </button>

          <button
            onClick={() => handleTabChange('resume')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'resume'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Import Resume</span>
          </button>

          <button
            onClick={() => handleTabChange('custom_fields')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'custom_fields'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <Layers className="w-4 h-4" />
              <span>Custom Fields</span>
            </div>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                activeTab === 'custom_fields' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              {(profile.customFields || []).length}
            </span>
          </button>

          <button
            onClick={() => handleTabChange('tracker')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'tracker'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <Briefcase className="w-4 h-4" />
              <span>Application Tracker</span>
            </div>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                activeTab === 'tracker' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              {applications.length}
            </span>
          </button>

          <button
            onClick={() => handleTabChange('ai_answers')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'ai_answers'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Answer Generator</span>
          </button>

          <button
            onClick={() => handleTabChange('learning')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'learning'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <BrainCircuit className="w-4 h-4" />
              <span>Form Learning</span>
            </div>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                activeTab === 'learning' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}
            >
              {learnedMappings.length}
            </span>
          </button>

          <button
            onClick={() => handleTabChange('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Settings & Privacy</span>
          </button>
        </aside>

        {/* Content Tabs Area */}
        <main className="flex-1 overflow-y-auto">
          {/* TAB 1: PROFILE MANAGER */}
          {activeTab === 'profile' && (
            <div className="flex flex-col gap-6">
              {/* Personal Information Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <User className="w-5 h-5 text-primary" />
                  <h2 className="text-sm font-bold text-slate-900">Personal Information</h2>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={profile.personal?.fullName || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: {
                            ...(profile.personal || defaultProfile.personal),
                            fullName: e.target.value,
                            firstName: e.target.value.split(' ')[0] || '',
                            lastName: e.target.value.split(' ').slice(1).join(' ') || '',
                          },
                        })
                      }
                      placeholder="e.g. Rahul Sharma"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">First Name</label>
                    <input
                      type="text"
                      value={profile.personal?.firstName || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), firstName: e.target.value },
                        })
                      }
                      placeholder="e.g. Rahul"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Last Name</label>
                    <input
                      type="text"
                      value={profile.personal?.lastName || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), lastName: e.target.value },
                        })
                      }
                      placeholder="e.g. Sharma"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={profile.personal?.email || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), email: e.target.value },
                        })
                      }
                      placeholder="rahul.sharma@example.com"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                    <input
                      type="tel"
                      value={profile.personal?.phoneNumber || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), phoneNumber: e.target.value },
                        })
                      }
                      placeholder="+91 9876543210"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">WhatsApp Number</label>
                    <input
                      type="tel"
                      value={profile.personal?.whatsappNumber || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), whatsappNumber: e.target.value },
                        })
                      }
                      placeholder="+91 9876543210"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Current Location / City</label>
                    <input
                      type="text"
                      value={profile.personal?.currentLocation || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), currentLocation: e.target.value },
                        })
                      }
                      placeholder="e.g. Pune, Maharashtra"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">LinkedIn Profile</label>
                    <input
                      type="url"
                      value={profile.personal?.linkedin || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), linkedin: e.target.value },
                        })
                      }
                      placeholder="https://linkedin.com/in/username"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">GitHub Profile</label>
                    <input
                      type="url"
                      value={profile.personal?.github || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), github: e.target.value },
                        })
                      }
                      placeholder="https://github.com/username"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="col-span-3">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio / Personal Website</label>
                    <input
                      type="url"
                      value={profile.personal?.portfolio || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), portfolio: e.target.value },
                        })
                      }
                      placeholder="https://myportfolio.dev"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="col-span-3">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Career Objective / Professional Summary</label>
                    <textarea
                      rows={3}
                      value={profile.personal?.summary || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          personal: { ...(profile.personal || defaultProfile.personal), summary: e.target.value },
                        })
                      }
                      placeholder="e.g. Passionate Software Engineer with experience in full-stack web development, React, Node.js, and automated testing..."
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>

              {/* Class 10 Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <GraduationCap className="w-5 h-5 text-primary" />
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Class 10 (Secondary / Matriculation)</h2>
                    <p className="text-[11px] text-text-secondary">Strictly mapped to Class 10 fields</p>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Board</label>
                    <input
                      type="text"
                      value={profile.class10?.board || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class10: { ...(profile.class10 || defaultProfile.class10), board: e.target.value },
                        })
                      }
                      placeholder="CBSE / ICSE / State Board"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">School Name</label>
                    <input
                      type="text"
                      value={profile.class10?.school || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class10: { ...(profile.class10 || defaultProfile.class10), school: e.target.value },
                        })
                      }
                      placeholder="Delhi Public School"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year</label>
                    <input
                      type="text"
                      value={profile.class10?.passingYear || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class10: { ...(profile.class10 || defaultProfile.class10), passingYear: e.target.value },
                        })
                      }
                      placeholder="e.g. 2018"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Percentage or CGPA</label>
                    <input
                      type="text"
                      value={profile.class10?.percentage || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class10: { ...(profile.class10 || defaultProfile.class10), percentage: e.target.value },
                        })
                      }
                      placeholder="e.g. 89.4% or 9.4"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>

              {/* Class 12 / Diploma Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Class 12 / Diploma</h2>
                      <p className="text-[11px] text-text-secondary">
                        Qualification type directly drives the 12th vs Diploma discriminator
                      </p>
                    </div>
                  </div>

                  {/* 12th vs Diploma selector */}
                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                    <button
                      type="button"
                      onClick={() =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), qualificationType: '12th' },
                        })
                      }
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                        (profile.class12?.qualificationType || '12th') === '12th'
                          ? 'bg-white text-primary shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Class 12 (HSC)
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), qualificationType: 'Diploma' },
                        })
                      }
                      className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                        profile.class12?.qualificationType === 'Diploma'
                          ? 'bg-white text-primary shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Diploma (Polytechnic)
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Board or Institution</label>
                    <input
                      type="text"
                      value={profile.class12?.boardOrInstitution || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), boardOrInstitution: e.target.value },
                        })
                      }
                      placeholder="CBSE / State Board / MSBTE"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Stream / Discipline</label>
                    <input
                      type="text"
                      value={profile.class12?.stream || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), stream: e.target.value },
                        })
                      }
                      placeholder="Science (PCM) / Computer Engg"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year</label>
                    <input
                      type="text"
                      value={profile.class12?.passingYear || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), passingYear: e.target.value },
                        })
                      }
                      placeholder="e.g. 2020"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Percentage or CGPA</label>
                    <input
                      type="text"
                      value={profile.class12?.percentage || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          class12: { ...(profile.class12 || defaultProfile.class12), percentage: e.target.value },
                        })
                      }
                      placeholder="e.g. 91.6% or 9.2"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>

              {/* B.Tech Section - Exactly ONE section */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <GraduationCap className="w-5 h-5 text-primary" />
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">B.Tech / Undergraduate Degree</h2>
                    <p className="text-[11px] text-text-secondary">Primary Graduation details and Permanent Registration Number (PRN)</p>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Degree</label>
                    <input
                      type="text"
                      value={profile.btech?.degree || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), degree: e.target.value },
                        })
                      }
                      placeholder="B.Tech / B.E."
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Branch / Discipline</label>
                    <input
                      type="text"
                      value={profile.btech?.branch || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), branch: e.target.value },
                        })
                      }
                      placeholder="Computer Science & Engineering"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">College or University</label>
                    <input
                      type="text"
                      value={profile.btech?.college || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), college: e.target.value },
                        })
                      }
                      placeholder="e.g. Indian Institute of Technology / NIT"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year (or Expected)</label>
                    <input
                      type="text"
                      value={profile.btech?.passingYear || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), passingYear: e.target.value },
                        })
                      }
                      placeholder="e.g. 2024"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">CGPA or Percentage</label>
                    <input
                      type="text"
                      value={profile.btech?.cgpa || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), cgpa: e.target.value },
                        })
                      }
                      placeholder="e.g. 8.65 or 82.5%"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">PRN (Registration Number)</label>
                    <input
                      type="text"
                      value={profile.btech?.prn || ''}
                      onChange={(e) =>
                        setProfile({
                          ...profile,
                          btech: { ...(profile.btech || defaultProfile.btech), prn: e.target.value },
                        })
                      }
                      placeholder="e.g. 2020BTECS00142"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Active Backlogs</label>
                      <input
                        type="text"
                        value={profile.btech?.activeBacklogs || '0'}
                        onChange={(e) =>
                          setProfile({
                            ...profile,
                            btech: { ...(profile.btech || defaultProfile.btech), activeBacklogs: e.target.value },
                          })
                        }
                        placeholder="0"
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Dead Backlogs</label>
                      <input
                        type="text"
                        value={profile.btech?.deadBacklogs || '0'}
                        onChange={(e) =>
                          setProfile({
                            ...profile,
                            btech: { ...(profile.btech || defaultProfile.btech), deadBacklogs: e.target.value },
                          })
                        }
                        placeholder="0"
                        className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Higher Education Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Higher Education</h2>
                      <p className="text-[11px] text-text-secondary">Add M.Tech, MBA, MCA, M.Sc., PhD or other post-graduate qualifications</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={addHigherEducation}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-primary border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Higher Education</span>
                  </button>
                </div>

                {(profile.higherEducation || []).length === 0 ? (
                  <div className="py-6 text-center text-xs text-text-secondary bg-slate-50 rounded-lg border border-dashed border-slate-200">
                    No higher education qualifications added yet. Click "+ Add Higher Education" if applicable.
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {(profile.higherEducation || []).map((he) => (
                      <div key={he.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 relative">
                        <button
                          type="button"
                          onClick={() => removeHigherEducation(he.id)}
                          className="absolute top-3 right-3 text-slate-400 hover:text-rose-600 transition-colors p-1"
                          title="Remove qualification"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="grid grid-cols-5 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Degree</label>
                            <input
                              type="text"
                              value={he.qualification}
                              onChange={(e) => updateHigherEducation(he.id, 'qualification', e.target.value)}
                              placeholder="M.Tech / MBA / PhD"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>
                          <div className="col-span-2">
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Institution</label>
                            <input
                              type="text"
                              value={he.institution}
                              onChange={(e) => updateHigherEducation(he.id, 'institution', e.target.value)}
                              placeholder="e.g. IISc Bangalore"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Specialization</label>
                            <input
                              type="text"
                              value={he.specialization}
                              onChange={(e) => updateHigherEducation(he.id, 'specialization', e.target.value)}
                              placeholder="Artificial Intelligence"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year / CGPA</label>
                            <div className="flex gap-1.5">
                              <input
                                type="text"
                                value={he.passingYear}
                                onChange={(e) => updateHigherEducation(he.id, 'passingYear', e.target.value)}
                                placeholder="Year"
                                className="w-1/2 text-xs px-2 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              />
                              <input
                                type="text"
                                value={he.percentageOrCgpa}
                                onChange={(e) => updateHigherEducation(he.id, 'percentageOrCgpa', e.target.value)}
                                placeholder="CGPA"
                                className="w-1/2 text-xs px-2 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Skills Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    <h2 className="text-sm font-bold text-slate-900">Technical Skills & Competencies</h2>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-3">
                  {(profile.skills || []).map((skill, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-full text-xs font-semibold"
                    >
                      {skill}
                      <button
                        type="button"
                        onClick={() =>
                          setProfile({
                            ...profile,
                            skills: (profile.skills || []).filter((_, i) => i !== idx),
                          })
                        }
                        className="hover:text-rose-600 transition-colors"
                      >
                        &times;
                      </button>
                    </span>
                  ))}
                </div>

                <div className="flex gap-2 max-w-md">
                  <input
                    type="text"
                    id="new-skill-input"
                    placeholder="Add a new skill (e.g. React, Python, Docker)"
                    className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        const val = (e.target as HTMLInputElement).value.trim();
                        if (val && !(profile.skills || []).includes(val)) {
                          setProfile({ ...profile, skills: [...(profile.skills || []), val] });
                          (e.target as HTMLInputElement).value = '';
                        }
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const input = document.getElementById('new-skill-input') as HTMLInputElement;
                      if (input && input.value.trim() && !(profile.skills || []).includes(input.value.trim())) {
                        setProfile({ ...profile, skills: [...(profile.skills || []), input.value.trim()] });
                        input.value = '';
                      }
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Work Experience & Internships Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Work Experience & Internships</h2>
                      <p className="text-[11px] text-text-secondary">Track employment history, internships, and corporate roles</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={addExperience}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-primary border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Experience</span>
                  </button>
                </div>

                {(profile.experiences || []).length === 0 ? (
                  <div className="py-6 text-center text-xs text-text-secondary bg-slate-50 rounded-lg border border-dashed border-slate-200">
                    No work experience or internships added yet. Click "+ Add Experience" or import your resume.
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {(profile.experiences || []).map((exp) => (
                      <div key={exp.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 relative">
                        <button
                          type="button"
                          onClick={() => removeExperience(exp.id)}
                          className="absolute top-3 right-3 text-slate-400 hover:text-rose-600 transition-colors p-1"
                          title="Remove experience"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="grid grid-cols-3 gap-3 mb-3 pr-8">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Company / Organization</label>
                            <input
                              type="text"
                              value={exp.company || ''}
                              onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                              placeholder="e.g. Google / Microsoft / Startup Inc."
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Job Title / Role</label>
                            <input
                              type="text"
                              value={exp.role || ''}
                              onChange={(e) => updateExperience(exp.id, 'role', e.target.value)}
                              placeholder="e.g. Software Engineer / SDE Intern"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>

                          <div className="flex gap-2">
                            <div className="flex-1">
                              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Dates / Duration</label>
                              <input
                                type="text"
                                value={exp.startDate ? `${exp.startDate} - ${exp.endDate || 'Present'}` : exp.endDate || ''}
                                onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                                placeholder="e.g. June 2022 - Aug 2022"
                                className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Description / Key Responsibilities</label>
                          <textarea
                            rows={2}
                            value={exp.description || ''}
                            onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                            placeholder="Describe your role, projects built, tools used, and key impact..."
                            className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Projects Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Projects & Key Work</h2>
                      <p className="text-[11px] text-text-secondary">Showcase personal, academic, or professional projects</p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={addProject}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-primary border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Project</span>
                  </button>
                </div>

                {(profile.projects || []).length === 0 ? (
                  <div className="py-6 text-center text-xs text-text-secondary bg-slate-50 rounded-lg border border-dashed border-slate-200">
                    No projects added yet. Click "+ Add Project" or import your resume.
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {(profile.projects || []).map((proj) => (
                      <div key={proj.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 relative">
                        <button
                          type="button"
                          onClick={() => removeProject(proj.id)}
                          className="absolute top-3 right-3 text-slate-400 hover:text-rose-600 transition-colors p-1"
                          title="Remove project"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="grid grid-cols-3 gap-3 mb-3 pr-8">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Project Title</label>
                            <input
                              type="text"
                              value={proj.title || ''}
                              onChange={(e) => updateProject(proj.id, 'title', e.target.value)}
                              placeholder="e.g. FormPilot AI Assistant"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Technologies / Tech Stack</label>
                            <input
                              type="text"
                              value={proj.technologies || ''}
                              onChange={(e) => updateProject(proj.id, 'technologies', e.target.value)}
                              placeholder="e.g. React, TypeScript, Tailwind"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>

                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Project / Repository Link</label>
                            <input
                              type="url"
                              value={proj.link || ''}
                              onChange={(e) => updateProject(proj.id, 'link', e.target.value)}
                              placeholder="https://github.com/..."
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Project Description</label>
                          <textarea
                            rows={2}
                            value={proj.description || ''}
                            onChange={(e) => updateProject(proj.id, 'description', e.target.value)}
                            placeholder="Describe what the project does, key technical challenges solved, and outcome..."
                            className="w-full text-xs px-2.5 py-1.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Certifications & Achievements Card */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <Award className="w-5 h-5 text-primary" />
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Certifications & Achievements</h2>
                    <p className="text-[11px] text-text-secondary">Recognitions, online certifications, awards, and licenses</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Certifications column */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-800 mb-2">Certifications</label>
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {(profile.certifications || []).length === 0 ? (
                        <span className="text-xs text-text-secondary italic">No certifications added.</span>
                      ) : (
                        (profile.certifications || []).map((c, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-xs"
                          >
                            <span>{c}</span>
                            <button
                              type="button"
                              onClick={() => removeCertification(idx)}
                              className="hover:text-rose-600 transition-colors"
                            >
                              &times;
                            </button>
                          </span>
                        ))
                      )}
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        id="new-cert-input"
                        placeholder="e.g. AWS Certified Developer"
                        className="flex-1 text-xs px-2.5 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = (e.target as HTMLInputElement).value.trim();
                            if (val) {
                              addCertification(val);
                              (e.target as HTMLInputElement).value = '';
                            }
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const input = document.getElementById('new-cert-input') as HTMLInputElement;
                          if (input && input.value.trim()) {
                            addCertification(input.value.trim());
                            input.value = '';
                          }
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Add
                      </button>
                    </div>
                  </div>

                  {/* Achievements column */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-800 mb-2">Honors & Achievements</label>
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {(profile.achievements || []).length === 0 ? (
                        <span className="text-xs text-text-secondary italic">No achievements added.</span>
                      ) : (
                        (profile.achievements || []).map((a, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs"
                          >
                            <span>{a}</span>
                            <button
                              type="button"
                              onClick={() => removeAchievement(idx)}
                              className="hover:text-rose-600 transition-colors"
                            >
                              &times;
                            </button>
                          </span>
                        ))
                      )}
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        id="new-ach-input"
                        placeholder="e.g. 1st Place Smart India Hackathon"
                        className="flex-1 text-xs px-2.5 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = (e.target as HTMLInputElement).value.trim();
                            if (val) {
                              addAchievement(val);
                              (e.target as HTMLInputElement).value = '';
                            }
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const input = document.getElementById('new-ach-input') as HTMLInputElement;
                          if (input && input.value.trim()) {
                            addAchievement(input.value.trim());
                            input.value = '';
                          }
                        }}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Adaptive Personal Profile Schema (Custom Profile Fields) Card */}
              {renderCustomFieldsSection()}
            </div>
          )}

          {/* TAB 2: RESUME IMPORT & EXTRACT */}
          {activeTab === 'resume' && (
            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-2 pb-3 border-b border-slate-100">
                  <FileText className="w-5 h-5 text-primary" />
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Import & Extract from Resume</h2>
                    <p className="text-xs text-text-secondary">
                      Upload your PDF or DOCX resume, or paste raw text. Parses education, contact info, skills, and projects locally.
                    </p>
                  </div>
                </div>

                {/* Upload box */}
                <div className="my-4 p-8 border-2 border-dashed border-blue-200 hover:border-primary rounded-2xl bg-blue-50/20 text-center transition-all">
                  <Upload className="w-8 h-8 text-primary mx-auto mb-2" />
                  <div className="text-sm font-bold text-slate-800 mb-1">Upload Resume (PDF or DOCX)</div>
                  <p className="text-xs text-text-secondary mb-4">Client-side document text extraction. No files uploaded to external servers.</p>

                  <label className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm cursor-pointer transition-colors">
                    <span>Browse File</span>
                    <input type="file" accept=".pdf,.docx,.txt" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>

                {/* Or paste resume text */}
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700">Or Paste Resume Text:</label>
                    <button
                      onClick={handlePastedResumeExtract}
                      disabled={isExtracting || !resumeText.trim()}
                      className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-md transition-colors cursor-pointer"
                    >
                      Extract From Text
                    </button>
                  </div>
                  <textarea
                    rows={6}
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    placeholder="Paste plain text of your resume here..."
                    className="w-full text-xs p-3 bg-slate-50 border border-border rounded-xl focus:outline-none focus:ring-1 focus:ring-primary font-mono"
                  />
                </div>
              </div>

              {/* Review Extracted Values Card */}
              {extractedData && reviewedProfile && (
                <div className="flex flex-col gap-6 animate-fade-in">
                  {/* Review Header Banner */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-5 h-5 text-emerald-600" />
                          <h3 className="text-base font-bold text-slate-900">Review Extracted Resume Details</h3>
                          <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Parsed Locally
                          </span>
                        </div>
                        <p className="text-xs text-text-secondary mt-1">
                          Carefully verify and update the extracted values below. Any fields needing manual verification are flagged.
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (extractedData) {
                              setReviewedProfile(sanitizeProfile(extractedData.profile));
                              showToast('Reset review data to original parsed values.');
                            }
                          }}
                          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="Reset edits to initial extraction"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Reset Edits</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setExtractedData(null);
                            setReviewedProfile(null);
                            showToast('Extracted resume data cleared.');
                          }}
                          className="px-3 py-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="Discard extraction"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Discard</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleInitiateSaveToProfile}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Save to My Profile</span>
                        </button>
                      </div>
                    </div>

                    {/* Scanned PDF / OCR Required Notice */}
                    {(extractedData.isScannedPdf || extractedData.needsOcr) && (
                      <div className="mt-4 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold text-sm text-rose-900 mb-0.5">Scanned Document Detected (OCR Required)</div>
                          <p className="leading-relaxed text-rose-800">
                            This document contains very little or no selectable digital text and appears to be a scanned image or photo.
                            FormPilot AI processes all documents <strong>locally in your browser</strong> to protect your data privacy and never transmits your resume to cloud OCR servers without your explicit consent.
                          </p>
                          <p className="mt-1.5 text-[11px] text-rose-700 font-semibold">
                            Tip: For optimal autofill accuracy, upload an exported/searchable PDF or DOCX file, convert with local OCR, or paste your plain text above.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Chronological / Consistency Warnings */}
                    {extractedData.conflictingFields && extractedData.conflictingFields.length > 0 && (
                      <div className="mt-3 p-4 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-900 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-orange-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold">Chronological Sequence Notice: </span>
                          <span>
                            {extractedData.conflictingFields.join('; ')}. Please check and verify the graduation and passing years before saving.
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Uncertain Fields Warning Banner */}
                    {extractedData.uncertainFields.length > 0 && (
                      <div className="mt-3 p-4 bg-amber-50/80 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold">Manual Review Advised: </span>
                          <span>
                            The parser could not confidently detect some information ({extractedData.uncertainFields.map(getFriendlyUncertainName).join(', ')}). Fields marked with the amber <span className="font-semibold text-amber-800 underline">Needs Review</span> badge below should be verified or completed before saving.
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Confidence Score & Raw Text Inspection Bar */}
                    <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-primary" />
                        <span className="font-semibold text-slate-700">Extraction Confidence:</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
                          overallConfidence >= 80
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : overallConfidence >= 50
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}>
                          {overallConfidence}%
                        </span>
                        <span className="text-[11px] text-text-secondary">
                          ({Object.keys(extractedData.fieldConfidence || {}).length} validated fields)
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowRawText(!showRawText)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>{showRawText ? 'Hide Original Extracted Text' : 'Inspect Original Extracted Text'}</span>
                        {showRawText ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    {/* Collapsible Raw Extracted Text Drawer */}
                    {showRawText && (
                      <div className="mt-4 p-4 bg-slate-900 text-slate-100 rounded-xl border border-slate-700 text-xs font-mono shadow-inner">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400 gap-2">
                          <div className="flex items-center gap-2 font-sans font-semibold text-slate-300 text-xs">
                            <FileText className="w-4 h-4 text-blue-400" />
                            <span>Original Extracted Text ({extractedData.rawText?.length || 0} characters)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={rawTextSearch}
                              onChange={(e) => setRawTextSearch(e.target.value)}
                              placeholder="Search extracted text..."
                              className="px-2.5 py-1 text-xs bg-slate-800 text-slate-200 border border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-primary font-sans"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(extractedData.rawText || '');
                                showToast('Copied original extracted text to clipboard.');
                              }}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs flex items-center gap-1 cursor-pointer font-sans"
                            >
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </button>
                          </div>
                        </div>
                        <div className="max-h-72 overflow-y-auto whitespace-pre-wrap leading-relaxed text-slate-300 selection:bg-blue-600 selection:text-white p-3 bg-slate-950/60 rounded border border-slate-800/80">
                          {rawTextSearch.trim()
                            ? extractedData.rawText
                                .split('\n')
                                .filter((line) => line.toLowerCase().includes(rawTextSearch.toLowerCase()))
                                .join('\n') || '<No matching lines found>'
                            : extractedData.rawText || '<No text extracted>'}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Section 1: Personal & Contact Details */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                      <User className="w-5 h-5 text-primary" />
                      <h4 className="text-sm font-bold text-slate-900">Personal & Contact Details</h4>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-700">Full Name</label>
                          {isFieldUncertain('personal.fullName') && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                              Needs Review
                            </span>
                          )}
                        </div>
                        <input
                          type="text"
                          value={reviewedProfile.personal?.fullName || ''}
                          onChange={(e) => updateReviewedPersonal('fullName', e.target.value)}
                          className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                            isFieldUncertain('personal.fullName')
                              ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                              : 'bg-slate-50 border-border focus:bg-white focus:ring-1 focus:ring-primary'
                          }`}
                          placeholder="e.g. John Doe"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">First Name</label>
                        <input
                          type="text"
                          value={reviewedProfile.personal?.firstName || ''}
                          onChange={(e) => updateReviewedPersonal('firstName', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="e.g. John"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Last Name</label>
                        <input
                          type="text"
                          value={reviewedProfile.personal?.lastName || ''}
                          onChange={(e) => updateReviewedPersonal('lastName', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="e.g. Doe"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-700">Email Address</label>
                          {isFieldUncertain('personal.email') && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                              Needs Review
                            </span>
                          )}
                        </div>
                        <input
                          type="email"
                          value={reviewedProfile.personal?.email || ''}
                          onChange={(e) => updateReviewedPersonal('email', e.target.value)}
                          className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                            isFieldUncertain('personal.email')
                              ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                              : 'bg-slate-50 border-border focus:bg-white focus:ring-1 focus:ring-primary'
                          }`}
                          placeholder="e.g. john@example.com"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-700">Phone Number</label>
                          {isFieldUncertain('personal.phoneNumber') && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                              Needs Review
                            </span>
                          )}
                        </div>
                        <input
                          type="tel"
                          value={reviewedProfile.personal?.phoneNumber || ''}
                          onChange={(e) => updateReviewedPersonal('phoneNumber', e.target.value)}
                          className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                            isFieldUncertain('personal.phoneNumber')
                              ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                              : 'bg-slate-50 border-border focus:bg-white focus:ring-1 focus:ring-primary'
                          }`}
                          placeholder="e.g. +91 9876543210"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">WhatsApp Number</label>
                        <input
                          type="tel"
                          value={reviewedProfile.personal?.whatsappNumber || ''}
                          onChange={(e) => updateReviewedPersonal('whatsappNumber', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="e.g. +91 9876543210"
                        />
                      </div>

                      <div className="md:col-span-3">
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-700">Current Location / Address</label>
                          {isFieldUncertain('personal.currentLocation') && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                              Needs Review
                            </span>
                          )}
                        </div>
                        <input
                          type="text"
                          value={reviewedProfile.personal?.currentLocation || ''}
                          onChange={(e) => updateReviewedPersonal('currentLocation', e.target.value)}
                          className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                            isFieldUncertain('personal.currentLocation')
                              ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                              : 'bg-slate-50 border-border focus:bg-white focus:ring-1 focus:ring-primary'
                          }`}
                          placeholder="e.g. Bangalore, Karnataka, India"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">LinkedIn Profile</label>
                        <input
                          type="url"
                          value={reviewedProfile.personal?.linkedin || ''}
                          onChange={(e) => updateReviewedPersonal('linkedin', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="https://linkedin.com/in/..."
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">GitHub Profile</label>
                        <input
                          type="url"
                          value={reviewedProfile.personal?.github || ''}
                          onChange={(e) => updateReviewedPersonal('github', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="https://github.com/..."
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">Portfolio Website</label>
                        <input
                          type="url"
                          value={reviewedProfile.personal?.portfolio || ''}
                          onChange={(e) => updateReviewedPersonal('portfolio', e.target.value)}
                          className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          placeholder="https://portfolio.me"
                        />
                      </div>

                      <div className="md:col-span-3">
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Career Objective / Professional Summary
                        </label>
                        <textarea
                          rows={3}
                          value={reviewedProfile.personal?.summary || ''}
                          onChange={(e) => updateReviewedPersonal('summary', e.target.value)}
                          className="w-full text-xs p-3 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary leading-relaxed"
                          placeholder="Brief overview of background, technical strengths, and career aspirations..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Education Qualifications */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                      <GraduationCap className="w-5 h-5 text-primary" />
                      <h4 className="text-sm font-bold text-slate-900">Educational Qualifications</h4>
                    </div>

                    <div className="space-y-6">
                      {/* Class 10 */}
                      <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                        <h5 className="text-xs font-bold text-slate-900 mb-3 flex items-center gap-2">
                          <span>Class 10 (Secondary)</span>
                        </h5>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Board</label>
                            <input
                              type="text"
                              value={reviewedProfile.class10?.board || ''}
                              onChange={(e) => updateReviewedClass10('board', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. CBSE / ICSE / State Board"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">School / Institution</label>
                            <input
                              type="text"
                              value={reviewedProfile.class10?.school || ''}
                              onChange={(e) => updateReviewedClass10('school', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. St. Xavier's High School"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year</label>
                            <input
                              type="text"
                              value={reviewedProfile.class10?.passingYear || ''}
                              onChange={(e) => updateReviewedClass10('passingYear', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. 2018"
                            />
                          </div>
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-semibold text-slate-700">Percentage / Marks</label>
                              {isFieldUncertain('class10.percentage') && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                                  <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                                  Review
                                </span>
                              )}
                            </div>
                            <input
                              type="text"
                              value={reviewedProfile.class10?.percentage || ''}
                              onChange={(e) => updateReviewedClass10('percentage', e.target.value)}
                              className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                                isFieldUncertain('class10.percentage')
                                  ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                                  : 'bg-white border-border focus:bg-white focus:ring-1 focus:ring-primary'
                              }`}
                              placeholder="e.g. 91.5%"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Class 12 / Diploma */}
                      <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                        <div className="flex items-center justify-between mb-3">
                          <h5 className="text-xs font-bold text-slate-900">
                            Class 12th / Diploma (Higher Secondary)
                          </h5>
                          <div className="flex items-center bg-white p-0.5 rounded-lg border border-slate-200 text-xs">
                            <button
                              type="button"
                              onClick={() => updateReviewedClass12('qualificationType', '12th')}
                              className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                                reviewedProfile.class12?.qualificationType === '12th'
                                  ? 'bg-blue-600 text-white shadow-xs'
                                  : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              12th (HSC)
                            </button>
                            <button
                              type="button"
                              onClick={() => updateReviewedClass12('qualificationType', 'Diploma')}
                              className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                                reviewedProfile.class12?.qualificationType === 'Diploma'
                                  ? 'bg-blue-600 text-white shadow-xs'
                                  : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              Diploma / Polytechnic
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              {reviewedProfile.class12?.qualificationType === 'Diploma' ? 'Polytechnic Board / College' : 'Board'}
                            </label>
                            <input
                              type="text"
                              value={reviewedProfile.class12?.boardOrInstitution || ''}
                              onChange={(e) => updateReviewedClass12('boardOrInstitution', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. CBSE / State Board / MSBTE"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Stream / Branch</label>
                            <input
                              type="text"
                              value={reviewedProfile.class12?.stream || ''}
                              onChange={(e) => updateReviewedClass12('stream', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. Science (PCM) / Computer Engg"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Passing Year</label>
                            <input
                              type="text"
                              value={reviewedProfile.class12?.passingYear || ''}
                              onChange={(e) => updateReviewedClass12('passingYear', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. 2020"
                            />
                          </div>
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-semibold text-slate-700">Percentage / Marks</label>
                              {isFieldUncertain('class12.percentage') && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                                  <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                                  Review
                                </span>
                              )}
                            </div>
                            <input
                              type="text"
                              value={reviewedProfile.class12?.percentage || ''}
                              onChange={(e) => updateReviewedClass12('percentage', e.target.value)}
                              className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                                isFieldUncertain('class12.percentage')
                                  ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                                  : 'bg-white border-border focus:bg-white focus:ring-1 focus:ring-primary'
                              }`}
                              placeholder="e.g. 88.4%"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Undergraduate Degree */}
                      <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                        <h5 className="text-xs font-bold text-slate-900 mb-3">Undergraduate Degree (B.Tech / B.E / BCA / B.Sc)</h5>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Degree Title</label>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.degree || ''}
                              onChange={(e) => updateReviewedBtech('degree', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. B.Tech / B.E. / BCA"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Branch / Major</label>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.branch || ''}
                              onChange={(e) => updateReviewedBtech('branch', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. Computer Science and Engineering"
                            />
                          </div>
                          <div className="md:col-span-2">
                            <label className="block text-xs font-semibold text-slate-700 mb-1">College / University</label>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.college || ''}
                              onChange={(e) => updateReviewedBtech('college', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. National Institute of Technology"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Graduation Year</label>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.passingYear || ''}
                              onChange={(e) => updateReviewedBtech('passingYear', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. 2024"
                            />
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-semibold text-slate-700">CGPA / Percentage</label>
                              {isFieldUncertain('btech.cgpa') && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                                  <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                                  Review
                                </span>
                              )}
                            </div>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.cgpa || ''}
                              onChange={(e) => updateReviewedBtech('cgpa', e.target.value)}
                              className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                                isFieldUncertain('btech.cgpa')
                                  ? 'border-amber-300 bg-amber-50/20 focus:bg-white focus:ring-1 focus:ring-amber-400'
                                  : 'bg-white border-border focus:bg-white focus:ring-1 focus:ring-primary'
                              }`}
                              placeholder="e.g. 8.65 or 85%"
                            />
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-semibold text-slate-700">Roll No / PRN</label>
                              {isFieldUncertain('btech.prn') && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-0.5">
                                  <AlertTriangle className="w-2.5 h-2.5 text-amber-600" />
                                  Review
                                </span>
                              )}
                            </div>
                            <input
                              type="text"
                              value={reviewedProfile.btech?.prn || ''}
                              onChange={(e) => updateReviewedBtech('prn', e.target.value)}
                              className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              placeholder="e.g. 2020BCSE042"
                            />
                          </div>

                          <div className="flex gap-2">
                            <div className="flex-1">
                              <label className="block text-xs font-semibold text-slate-700 mb-1">Active Backlogs</label>
                              <input
                                type="text"
                                value={reviewedProfile.btech?.activeBacklogs || '0'}
                                onChange={(e) => updateReviewedBtech('activeBacklogs', e.target.value)}
                                className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              />
                            </div>
                            <div className="flex-1">
                              <label className="block text-xs font-semibold text-slate-700 mb-1">Dead Backlogs</label>
                              <input
                                type="text"
                                value={reviewedProfile.btech?.deadBacklogs || '0'}
                                onChange={(e) => updateReviewedBtech('deadBacklogs', e.target.value)}
                                className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Postgraduate & Higher Education */}
                      <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                        <div className="flex items-center justify-between mb-3">
                          <h5 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                            <span>Postgraduate & Higher Education (M.Tech / MBA / MCA / PhD)</span>
                            {(reviewedProfile.higherEducation || []).length > 0 && (
                              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                                {(reviewedProfile.higherEducation || []).length} degree(s)
                              </span>
                            )}
                          </h5>
                          <button
                            type="button"
                            onClick={addReviewedHigherEducation}
                            className="px-2.5 py-1 bg-white hover:bg-blue-50 text-primary border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Add Degree</span>
                          </button>
                        </div>

                        {(reviewedProfile.higherEducation || []).length === 0 ? (
                          <div className="text-xs text-text-secondary italic py-2">
                            No postgraduate qualification extracted. Click "+ Add Degree" if you hold an M.Tech, MBA, MCA, or PhD.
                          </div>
                        ) : (
                          <div className="flex flex-col gap-3">
                            {(reviewedProfile.higherEducation || []).map((he, hIdx) => (
                              <div key={he.id || hIdx} className="p-3 bg-white rounded-lg border border-slate-200 relative">
                                <button
                                  type="button"
                                  onClick={() => removeReviewedHigherEducation(he.id)}
                                  className="absolute top-2 right-2 text-slate-400 hover:text-rose-600 transition-colors p-1"
                                  title="Remove qualification"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pr-6">
                                  <div>
                                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Degree Title</label>
                                    <input
                                      type="text"
                                      value={he.qualification || ''}
                                      onChange={(e) => updateReviewedHigherEducation(he.id, 'qualification', e.target.value)}
                                      placeholder="M.Tech / MBA / MCA"
                                      className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Institution / University</label>
                                    <input
                                      type="text"
                                      value={he.institution || ''}
                                      onChange={(e) => updateReviewedHigherEducation(he.id, 'institution', e.target.value)}
                                      placeholder="e.g. IIT Bombay"
                                      className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Specialization / Branch</label>
                                    <input
                                      type="text"
                                      value={he.specialization || ''}
                                      onChange={(e) => updateReviewedHigherEducation(he.id, 'specialization', e.target.value)}
                                      placeholder="Artificial Intelligence"
                                      className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">Passing Year / CGPA</label>
                                    <div className="flex gap-1.5">
                                      <input
                                        type="text"
                                        value={he.passingYear || ''}
                                        onChange={(e) => updateReviewedHigherEducation(he.id, 'passingYear', e.target.value)}
                                        placeholder="Year"
                                        className="w-1/2 text-xs px-2 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                      />
                                      <input
                                        type="text"
                                        value={he.percentageOrCgpa || ''}
                                        onChange={(e) => updateReviewedHigherEducation(he.id, 'percentageOrCgpa', e.target.value)}
                                        placeholder="CGPA/%"
                                        className="w-1/2 text-xs px-2 py-1.5 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Section 3: Technical Skills */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <Tag className="w-5 h-5 text-primary" />
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">Technical Skills & Technologies</h4>
                          <p className="text-xs text-text-secondary">Detected skills from resume. Add or remove items as needed.</p>
                        </div>
                      </div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">
                        {reviewedProfile.skills?.length || 0} skills
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4 p-3 bg-slate-50/70 rounded-xl border border-slate-200 min-h-[48px]">
                      {reviewedProfile.skills && reviewedProfile.skills.length > 0 ? (
                        reviewedProfile.skills.map((skill, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1.5 px-3 py-1 bg-white border border-slate-200 text-slate-800 text-xs font-medium rounded-lg shadow-2xs group"
                          >
                            <span>{skill}</span>
                            <button
                              type="button"
                              onClick={() => removeReviewedSkill(idx)}
                              className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                              title={`Remove ${skill}`}
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))
                      ) : (
                        <div className="text-xs text-slate-400 italic py-1">No skills extracted yet. Add some below.</div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        id="new-reviewed-skill-input"
                        placeholder="Add a new skill (e.g. React, Python, Docker)..."
                        className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = (e.target as HTMLInputElement).value;
                            if (val.trim()) {
                              addReviewedSkill(val.trim());
                              (e.target as HTMLInputElement).value = '';
                            }
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const el = document.getElementById('new-reviewed-skill-input') as HTMLInputElement;
                          if (el && el.value.trim()) {
                            addReviewedSkill(el.value.trim());
                            el.value = '';
                          }
                        }}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Add Skill
                      </button>
                    </div>
                  </div>

                  {/* Section 4: Work Experience & Internships */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <Briefcase className="w-5 h-5 text-primary" />
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">Work Experience & Internships</h4>
                          <p className="text-xs text-text-secondary">Extracted roles, companies, and responsibilities.</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={addReviewedExperience}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Position</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      {reviewedProfile.experiences && reviewedProfile.experiences.length > 0 ? (
                        reviewedProfile.experiences.map((exp, idx) => (
                          <div key={exp.id || idx} className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                            <div className="flex items-center justify-between gap-2 mb-3">
                              <span className="text-xs font-bold text-slate-800">Position #{idx + 1}</span>
                              <button
                                type="button"
                                onClick={() => removeReviewedExperience(exp.id)}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                                title="Remove this position"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Company / Organization</label>
                                <input
                                  type="text"
                                  value={exp.company}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'company', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. Infosys, Google, Startup"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Role / Job Title</label>
                                <input
                                  type="text"
                                  value={exp.role}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'role', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. Software Engineer Intern"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Start Date</label>
                                <input
                                  type="text"
                                  value={exp.startDate || ''}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'startDate', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. Jan 2023"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">End Date</label>
                                <input
                                  type="text"
                                  disabled={exp.isCurrent}
                                  value={exp.isCurrent ? 'Present' : exp.endDate || ''}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'endDate', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary disabled:bg-slate-100"
                                  placeholder="e.g. Jun 2023 or Present"
                                />
                              </div>
                            </div>

                            <div className="flex items-center gap-4 mb-3 text-xs">
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={!!exp.isCurrent}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'isCurrent', e.target.checked)}
                                  className="rounded text-blue-600 focus:ring-blue-500"
                                />
                                <span className="font-medium text-slate-700">Currently working here</span>
                              </label>
                              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={!!exp.isInternship}
                                  onChange={(e) => updateReviewedExperience(exp.id, 'isInternship', e.target.checked)}
                                  className="rounded text-blue-600 focus:ring-blue-500"
                                />
                                <span className="font-medium text-slate-700">Internship role</span>
                              </label>
                            </div>

                            <div>
                              <label className="block text-xs font-semibold text-slate-700 mb-1">Description / Key Highlights</label>
                              <textarea
                                rows={2}
                                value={exp.description || ''}
                                onChange={(e) => updateReviewedExperience(exp.id, 'description', e.target.value)}
                                className="w-full text-xs p-2.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary leading-relaxed"
                                placeholder="Key contributions, technologies used, and outcomes achieved..."
                              />
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-xs text-slate-400">
                          No work experience detected. Click "Add Position" above to add one.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Section 5: Projects */}
                  <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <Layers className="w-5 h-5 text-primary" />
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">Projects</h4>
                          <p className="text-xs text-text-secondary">Extracted projects, technologies, and repositories.</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={addReviewedProject}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Project</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      {reviewedProfile.projects && reviewedProfile.projects.length > 0 ? (
                        reviewedProfile.projects.map((proj, idx) => (
                          <div key={proj.id || idx} className="p-4 bg-slate-50/70 rounded-xl border border-slate-200">
                            <div className="flex items-center justify-between gap-2 mb-3">
                              <span className="text-xs font-bold text-slate-800">Project #{idx + 1}</span>
                              <button
                                type="button"
                                onClick={() => removeReviewedProject(proj.id)}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                                title="Remove this project"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Project Title</label>
                                <input
                                  type="text"
                                  value={proj.title}
                                  onChange={(e) => updateReviewedProject(proj.id, 'title', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. AI-Powered Expense Tracker"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Technologies Used</label>
                                <input
                                  type="text"
                                  value={proj.technologies || ''}
                                  onChange={(e) => updateReviewedProject(proj.id, 'technologies', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. React, Node.js, MongoDB"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Role in Project</label>
                                <input
                                  type="text"
                                  value={proj.role || ''}
                                  onChange={(e) => updateReviewedProject(proj.id, 'role', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="e.g. Fullstack Developer / Team Lead"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-semibold text-slate-700 mb-1">Project Link / Repo</label>
                                <input
                                  type="url"
                                  value={proj.link || ''}
                                  onChange={(e) => updateReviewedProject(proj.id, 'link', e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                                  placeholder="https://github.com/..."
                                />
                              </div>
                            </div>

                            <div>
                              <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                              <textarea
                                rows={2}
                                value={proj.description || ''}
                                onChange={(e) => updateReviewedProject(proj.id, 'description', e.target.value)}
                                className="w-full text-xs p-2.5 bg-white border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary leading-relaxed"
                                placeholder="Overview of problems solved, features implemented, and impact..."
                              />
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-xs text-slate-400">
                          No projects detected. Click "Add Project" above to include one.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Section 6: Certifications & Achievements */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Certifications Card */}
                    <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                      <div className="flex items-center gap-2 mb-3 pb-3 border-b border-slate-100">
                        <Award className="w-5 h-5 text-primary" />
                        <h4 className="text-sm font-bold text-slate-900">Certifications</h4>
                      </div>
                      <div className="space-y-2 mb-4">
                        {reviewedProfile.certifications && reviewedProfile.certifications.length > 0 ? (
                          reviewedProfile.certifications.map((cert, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs"
                            >
                              <span className="font-medium text-slate-800">{cert}</span>
                              <button
                                type="button"
                                onClick={() => removeReviewedCertification(idx)}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))
                        ) : (
                          <div className="text-xs text-slate-400 italic py-2">No certifications detected.</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          id="new-rev-cert-input"
                          placeholder="Add certification..."
                          className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              const val = (e.target as HTMLInputElement).value;
                              if (val.trim()) {
                                addReviewedCertification(val.trim());
                                (e.target as HTMLInputElement).value = '';
                              }
                            }
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const el = document.getElementById('new-rev-cert-input') as HTMLInputElement;
                            if (el && el.value.trim()) {
                              addReviewedCertification(el.value.trim());
                              el.value = '';
                            }
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          Add
                        </button>
                      </div>
                    </div>

                    {/* Achievements Card */}
                    <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                      <div className="flex items-center gap-2 mb-3 pb-3 border-b border-slate-100">
                        <Award className="w-5 h-5 text-emerald-600" />
                        <h4 className="text-sm font-bold text-slate-900">Key Achievements & Honors</h4>
                      </div>
                      <div className="space-y-2 mb-4">
                        {reviewedProfile.achievements && reviewedProfile.achievements.length > 0 ? (
                          reviewedProfile.achievements.map((ach, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs"
                            >
                              <span className="font-medium text-slate-800">{ach}</span>
                              <button
                                type="button"
                                onClick={() => removeReviewedAchievement(idx)}
                                className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))
                        ) : (
                          <div className="text-xs text-slate-400 italic py-2">No achievements detected.</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          id="new-rev-ach-input"
                          placeholder="Add achievement..."
                          className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              const val = (e.target as HTMLInputElement).value;
                              if (val.trim()) {
                                addReviewedAchievement(val.trim());
                                (e.target as HTMLInputElement).value = '';
                              }
                            }
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const el = document.getElementById('new-rev-ach-input') as HTMLInputElement;
                            if (el && el.value.trim()) {
                              addReviewedAchievement(el.value.trim());
                              el.value = '';
                            }
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Sticky Action Bar */}
                  <div className="sticky bottom-6 bg-white/95 backdrop-blur-md rounded-2xl border border-blue-200 p-4 shadow-xl flex items-center justify-between gap-4 z-20">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">
                        ✓
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">Ready to Save to Profile</div>
                        <div className="text-[11px] text-text-secondary">
                          {(reviewedProfile.skills || []).length} skills • {(reviewedProfile.experiences || []).length} experiences • {(reviewedProfile.projects || []).length} projects
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setExtractedData(null);
                          setReviewedProfile(null);
                        }}
                        className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleInitiateSaveToProfile}
                        className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/25 transition-all cursor-pointer"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Save to My Profile</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Confirmation Modal */}
              {overwriteConfirmModal && (
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                  <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-border">
                    <h3 className="text-base font-bold text-slate-900 mb-2">Apply Resume Data to Profile</h3>
                    <p className="text-xs text-text-secondary mb-4 leading-relaxed">
                      Choose how you want to merge this extracted information with your existing profile data.
                    </p>

                    <div className="flex flex-col gap-2.5">
                      <button
                        onClick={() => applyExtractedToProfile(false)}
                        className="w-full text-left p-3 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100/50 transition-colors"
                      >
                        <div className="text-xs font-bold text-blue-900">Fill Empty Fields Only (Preserve Existing)</div>
                        <div className="text-[11px] text-blue-700">Keeps your existing data and only fills missing slots.</div>
                      </button>

                      <button
                        onClick={() => applyExtractedToProfile(true)}
                        className="w-full text-left p-3 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
                      >
                        <div className="text-xs font-bold text-slate-800">Overwrite with Extracted Values</div>
                        <div className="text-[11px] text-text-secondary">Replaces existing values with newly extracted data.</div>
                      </button>

                      <button
                        onClick={() => setOverwriteConfirmModal(false)}
                        className="mt-2 text-center py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: CUSTOM FIELDS MANAGEMENT */}
          {activeTab === 'custom_fields' && (
            <div className="flex flex-col gap-6">
              {renderCustomFieldsSection()}
            </div>
          )}

          {/* TAB 3: APPLICATION TRACKER */}
          {activeTab === 'tracker' && (
            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Job Application Tracker</h2>
                      <p className="text-xs text-text-secondary">
                        Organize your job, internship, and government recruitment applications
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowAddAppModal(true)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Application</span>
                  </button>
                </div>

                {/* Filter and Search Bar */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search by company or job title..."
                      value={trackerFilter.search}
                      onChange={(e) => setTrackerFilter({ ...trackerFilter, search: e.target.value })}
                      className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <select
                    value={trackerFilter.status}
                    onChange={(e) => setTrackerFilter({ ...trackerFilter, status: e.target.value })}
                    className="text-xs bg-slate-50 border border-border rounded-lg px-3 py-2 font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Interested">Interested</option>
                    <option value="To Apply">To Apply</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Applied">Applied</option>
                    <option value="Assessment">Assessment</option>
                    <option value="Interview">Interview</option>
                    <option value="Selected">Selected</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>

                {/* Applications Table */}
                {applications.length === 0 ? (
                  <div className="py-12 text-center text-xs text-text-secondary bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    <Briefcase className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <div>No applications tracked yet. Click "+ Add Application" to start.</div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-700 font-semibold">
                          <th className="py-2.5 px-3">Company</th>
                          <th className="py-2.5 px-3">Job Title</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3">Date Applied</th>
                          <th className="py-2.5 px-3">Deadline</th>
                          <th className="py-2.5 px-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {applications
                          .filter((a) => {
                            const matchSearch =
                              a.company.toLowerCase().includes(trackerFilter.search.toLowerCase()) ||
                              a.jobTitle.toLowerCase().includes(trackerFilter.search.toLowerCase());
                            const matchStatus =
                              trackerFilter.status === 'All' || a.status === trackerFilter.status;
                            return matchSearch && matchStatus;
                          })
                          .map((app) => (
                            <tr key={app.id} className="border-b border-slate-100 hover:bg-slate-50/50">
                              <td className="py-3 px-3 font-semibold text-slate-900">{app.company}</td>
                              <td className="py-3 px-3 text-slate-700">
                                <div className="flex items-center gap-1.5">
                                  <span>{app.jobTitle}</span>
                                  {app.applicationLink && (
                                    <a
                                      href={app.applicationLink}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="text-primary hover:text-primary-hover"
                                    >
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  )}
                                </div>
                              </td>
                              <td className="py-3 px-3">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    app.status === 'Selected'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : app.status === 'Rejected'
                                      ? 'bg-rose-100 text-rose-800'
                                      : app.status === 'Interview'
                                      ? 'bg-purple-100 text-purple-800'
                                      : app.status === 'Assessment'
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-blue-100 text-blue-800'
                                  }`}
                                >
                                  {app.status}
                                </span>
                              </td>
                              <td className="py-3 px-3 text-text-secondary">{app.dateApplied || '—'}</td>
                              <td className="py-3 px-3 text-text-secondary">{app.deadline || '—'}</td>
                              <td className="py-3 px-3 text-right">
                                <button
                                  onClick={() => handleDeleteApp(app.id)}
                                  className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Add Application Modal */}
              {showAddAppModal && (
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                  <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-border">
                    <h3 className="text-base font-bold text-slate-900 mb-3">Add Application to Tracker</h3>

                    <div className="grid grid-cols-2 gap-3 text-xs mb-4">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Company / Organization *</label>
                        <input
                          type="text"
                          value={newApp.company}
                          onChange={(e) => setNewApp({ ...newApp, company: e.target.value })}
                          placeholder="e.g. Google / SSC"
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Job Title *</label>
                        <input
                          type="text"
                          value={newApp.jobTitle}
                          onChange={(e) => setNewApp({ ...newApp, jobTitle: e.target.value })}
                          placeholder="e.g. Software Engineer"
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="block font-semibold text-slate-700 mb-1">Application URL</label>
                        <input
                          type="url"
                          value={newApp.applicationLink}
                          onChange={(e) => setNewApp({ ...newApp, applicationLink: e.target.value })}
                          placeholder="https://..."
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Status</label>
                        <select
                          value={newApp.status}
                          onChange={(e) => setNewApp({ ...newApp, status: e.target.value as ApplicationStatus })}
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg font-semibold"
                        >
                          <option value="Interested">Interested</option>
                          <option value="To Apply">To Apply</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Applied">Applied</option>
                          <option value="Assessment">Assessment</option>
                          <option value="Interview">Interview</option>
                          <option value="Selected">Selected</option>
                          <option value="Rejected">Rejected</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Date Applied</label>
                        <input
                          type="date"
                          value={newApp.dateApplied}
                          onChange={(e) => setNewApp({ ...newApp, dateApplied: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="block font-semibold text-slate-700 mb-1">Notes</label>
                        <textarea
                          rows={2}
                          value={newApp.notes}
                          onChange={(e) => setNewApp({ ...newApp, notes: e.target.value })}
                          placeholder="Add any reminders or interview notes..."
                          className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setShowAddAppModal(false)}
                        className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSaveApp}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm"
                      >
                        Save Application
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: AI ANSWER GENERATOR */}
          {activeTab === 'ai_answers' && (
            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Application Question AI Generator</h2>
                    <p className="text-xs text-text-secondary">
                      Craft tailored, truthful answers strictly grounded in your actual qualifications.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Target Role (Optional)</label>
                    <input
                      type="text"
                      value={aiJobTitle}
                      onChange={(e) => setAiJobTitle(e.target.value)}
                      placeholder="e.g. Frontend Developer"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Target Company (Optional)</label>
                    <input
                      type="text"
                      value={aiCompany}
                      onChange={(e) => setAiCompany(e.target.value)}
                      placeholder="e.g. Microsoft"
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Select or Type Question</label>
                    <div className="flex gap-2 mb-2">
                      {[
                        'Why should we hire you?',
                        'Describe your project.',
                        'What are your strengths?',
                        'Explain your internship experience.',
                      ].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setAiQuestion(preset)}
                          className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-md transition-colors"
                        >
                          {preset}
                        </button>
                      ))}
                    </div>

                    <input
                      type="text"
                      value={aiQuestion}
                      onChange={(e) => setAiQuestion(e.target.value)}
                      placeholder="Type custom question..."
                      className="w-full text-xs px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>

                <button
                  onClick={handleGenerateAnswer}
                  disabled={isGeneratingAnswer || !aiQuestion.trim()}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isGeneratingAnswer ? 'Generating Answer...' : 'Generate Grounded Answer'}</span>
                </button>

                {generatedAnswer && (
                  <div className="mt-6 pt-4 border-t border-slate-100">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-900">Generated Answer (Editable):</span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(generatedAnswer);
                          showToast('Copied answer to clipboard!');
                        }}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </button>
                    </div>

                    <textarea
                      rows={5}
                      value={generatedAnswer}
                      onChange={(e) => setGeneratedAnswer(e.target.value)}
                      className="w-full text-xs p-3 bg-slate-50 border border-border rounded-xl focus:outline-none focus:ring-1 focus:ring-primary leading-relaxed"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: FORM LEARNING */}
          {activeTab === 'learning' && (
            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <BrainCircuit className="w-5 h-5 text-primary" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900">Form Learning & Custom Mappings</h2>
                      <p className="text-xs text-text-secondary">
                        Rules learned when you correct a mapping on specific forms or labels
                      </p>
                    </div>
                  </div>
                </div>

                {learnedMappings.length === 0 ? (
                  <div className="py-12 text-center text-xs text-text-secondary bg-slate-50 rounded-xl border border-dashed border-slate-200">
                    <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <div>No custom learned mappings yet. FormPilot automatically learns when you correct mappings.</div>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {learnedMappings.map((rule) => (
                      <div
                        key={rule.id}
                        className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-900">{rule.fieldLabel}</div>
                          <div className="text-[11px] text-text-secondary">
                            Pattern: <span className="font-mono">{rule.normalizedPattern}</span> → Target:{' '}
                            <span className="font-mono text-primary">{rule.targetProperty}</span>
                            {rule.domainScope && <span> (Scope: {rule.domainScope})</span>}
                          </div>
                        </div>

                        <button
                          onClick={async () => {
                            await StorageService.deleteLearnedMapping(rule.id);
                            setLearnedMappings(learnedMappings.filter((r) => r.id !== rule.id));
                            showToast('Learned rule deleted.');
                          }}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & PRIVACY */}
          {activeTab === 'settings' && (
            <div className="flex flex-col gap-6">
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <Settings className="w-5 h-5 text-primary" />
                  <h2 className="text-sm font-bold text-slate-900">AI Configuration & Integrations</h2>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs mb-4">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">AI Provider</label>
                    <select
                      value={aiSettings.provider}
                      onChange={(e) =>
                        setAiSettings({
                          ...aiSettings,
                          provider: e.target.value as any,
                        })
                      }
                      className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg font-semibold"
                    >
                      <option value="rule-based">Built-in Rule-Based (Offline & Private)</option>
                      <option value="gemini">Google Gemini 1.5</option>
                      <option value="openai">OpenAI (GPT-4o Mini)</option>
                    </select>
                  </div>

                  {aiSettings.provider !== 'rule-based' && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">API Key</label>
                      <input
                        type="password"
                        value={aiSettings.apiKey}
                        onChange={(e) => setAiSettings({ ...aiSettings, apiKey: e.target.value })}
                        placeholder="Enter API key..."
                        className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg"
                      />
                    </div>
                  )}
                </div>

                <button
                  onClick={async () => {
                    await StorageService.saveAISettings(aiSettings);
                    showToast('Settings updated.');
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm cursor-pointer"
                >
                  Save Settings
                </button>
              </div>

              {/* Data Export / Import / Reset */}
              <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                  <Shield className="w-5 h-5 text-emerald-600" />
                  <h2 className="text-sm font-bold text-slate-900">Data Management & Backup</h2>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={async () => {
                      const json = await StorageService.exportAllData();
                      const blob = new Blob([json], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `formpilot-backup-${new Date().toISOString().split('T')[0]}.json`;
                      a.click();
                      showToast('Export downloaded successfully.');
                    }}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export All Data (JSON)</span>
                  </button>

                  <label className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Import Data Backup</span>
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={async (e) => {
                        const f = e.target.files?.[0];
                        if (f) {
                          const txt = await f.text();
                          const ok = await StorageService.importAllData(txt);
                          if (ok) {
                            showToast('Backup restored successfully!');
                            loadAllData();
                          } else {
                            showToast('Invalid backup file.');
                          }
                        }
                      }}
                    />
                  </label>

                  <button
                    onClick={async () => {
                      if (confirm('Are you sure you want to delete all saved data? This cannot be undone.')) {
                        await StorageService.clearAllData();
                        loadAllData();
                        showToast('All extension data cleared.');
                      }
                    }}
                    className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer ml-auto"
                  >
                    Clear All Data
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Custom Field Modal */}
      {showCustomFieldModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-border">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Tag className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {editingCustomField ? 'Edit Custom Field' : 'Add Custom Profile Field'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCustomFieldModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg leading-none cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="flex flex-col gap-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Field Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. University Registration Number, NCC Certificate"
                  value={customFieldForm.title}
                  onChange={(e) => setCustomFieldForm({ ...customFieldForm, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Value <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. 2021BCSE042, Grade A"
                  value={customFieldForm.value}
                  onChange={(e) => setCustomFieldForm({ ...customFieldForm, value: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={customFieldForm.category}
                    onChange={(e) =>
                      setCustomFieldForm({
                        ...customFieldForm,
                        category: e.target.value as any,
                      })
                    }
                    className="w-full px-2.5 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-xs"
                  >
                    <option value="Education">Education</option>
                    <option value="Identification">Identification</option>
                    <option value="Certificates">Certificates</option>
                    <option value="Professional">Professional</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Profile</label>
                  <div className="px-2.5 py-2 bg-slate-100 rounded-lg text-slate-600 font-semibold truncate border border-slate-200">
                    {profile?.name || 'Default Profile'}
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">Aliases & Keywords (Optional)</label>
                  <span className="text-[10px] text-slate-400">Comma-separated</span>
                </div>
                <input
                  type="text"
                  placeholder="e.g. reg_no, roll number, urn, univ_reg"
                  value={customFieldForm.aliases}
                  onChange={(e) => setCustomFieldForm({ ...customFieldForm, aliases: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Helps FormPilot automatically map this field even if online form labels use different phrasing.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowCustomFieldModal(false)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCustomField}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                {editingCustomField ? 'Update Field' : 'Save Field'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
