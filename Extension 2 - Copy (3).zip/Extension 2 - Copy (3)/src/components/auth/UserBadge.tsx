import React from 'react';
import { LogOut } from 'lucide-react';
import { User } from '../../auth/types';
import { AuthService } from '../../auth/authService';

interface UserBadgeProps {
  user: User;
  isCompact?: boolean;
  onLogout?: () => void;
}

export const UserBadge: React.FC<UserBadgeProps> = ({ user, isCompact = false, onLogout }) => {
  const handleLogout = async () => {
    await AuthService.signOut();
    if (onLogout) onLogout();
  };

  const initial = user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase();

  if (isCompact) {
    return (
      <div className="flex items-center gap-2">
        <div
          className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded-lg border border-slate-200/80 max-w-[170px]"
          title={`Signed in as ${user.name} (${user.email})`}
        >
          <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
            {initial}
          </div>
          <span className="text-[11px] font-semibold text-slate-800 truncate">{user.name || user.email}</span>
        </div>

        <button
          onClick={handleLogout}
          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
          title="Sign Out"
        >
          <LogOut className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <div
        className="flex items-center gap-2.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl shadow-xs"
        title={`Signed in as ${user.email}`}
      >
        <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
          {initial}
        </div>
        <div className="text-left">
          <div className="text-xs font-bold text-slate-800 leading-none">{user.name}</div>
          <div className="text-[10px] text-slate-500 mt-0.5 leading-none">{user.email}</div>
        </div>
      </div>

      <button
        onClick={handleLogout}
        className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
        title="Sign Out of Account"
      >
        <LogOut className="w-3.5 h-3.5 text-slate-500 hover:text-rose-600" />
        <span>Sign Out</span>
      </button>
    </div>
  );
};
